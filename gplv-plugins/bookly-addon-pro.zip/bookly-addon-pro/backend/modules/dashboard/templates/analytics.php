<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly ?>

<div class="bookly:card">
    <div class="bookly:card-body">
        <?php // Stating the scope up front: the report is a staff × service breakdown, so
              // its revenue is appointment revenue and does not include package, ticket or
              // gift card sales. Without this the total below reads like a broken Revenue. ?>
        <h3 class="bookly:m-0! bookly:mb-3! bookly:text-base bookly:font-semibold">
            <?php esc_html_e( 'Appointments by staff and service', 'bookly' ) ?>
        </h3>

        <div id="bookly-analytics-datatables"></div>

        <?php // Filled in from the analytics payload; stays hidden when the install has no
              // sales outside appointments, in which case there is nothing to reconcile. ?>
        <div id="bookly-analytics-bridge" class="bookly:hidden bookly:mt-4 bookly:pt-3 bookly:border-t bookly:border-border bookly:text-sm">
            <div class="bookly:flex bookly:justify-between bookly:gap-4 bookly:text-muted-foreground">
                <span data-bridge="appointments-label"></span>
                <span data-bridge="appointments-value"></span>
            </div>
            <div class="bookly:flex bookly:justify-between bookly:gap-4 bookly:text-muted-foreground bookly:mt-1">
                <span data-bridge="sales-label"></span>
                <span data-bridge="sales-value"></span>
            </div>
            <div class="bookly:flex bookly:justify-between bookly:gap-4 bookly:font-semibold bookly:mt-2">
                <span data-bridge="grand-label"></span>
                <span data-bridge="grand-value"></span>
            </div>
        </div>

        <small class="bookly:block bookly:mt-2 bookly:text-xs bookly:text-muted-foreground">
            <?php esc_html_e( 'Note: If payment is made for several services, then for each service you will see the entire amount paid as revenue.', 'bookly' ) ?>
        </small>
    </div>
</div>
