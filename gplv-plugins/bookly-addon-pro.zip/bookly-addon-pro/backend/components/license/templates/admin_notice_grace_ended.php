<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly ?>
<?php if ( is_admin() ) : ?>
    <div class="update-nag notice notice-warning inline is-dismissible bookly-js-license-notice">
        <div>
            <span style="font-size: 20px;"><b><?php esc_html_e( 'Bookly Pro - License verification required', 'bookly' ) ?></b></span>
            <p><?php esc_html_e( 'Access to your bookings has been disabled.', 'bookly' ) ?></p>
            <p><?php echo strtr( __( 'To enable access to your bookings, please verify your license by providing a valid purchase code. <a href="{url}">Details</a>', 'bookly' ), $replace_data ) ?></p>
            <button type="button" class="button action bookly-js-deactivate-pro"><?php esc_html_e( 'Deactivate Bookly Pro', 'bookly' ) ?></button>
        </div>
        <button type="button" class="notice-dismiss" data-trigger="temporary-hide"><span class="screen-reader-text"><?php __( 'Dismiss this notice.' ) ?></span></button>
    </div>
<?php else: ?>
    <div class="wrap bookly-css-root bookly-notice-wrap bookly-js-license-notice">
        <div class="bookly:alert bookly:alert-warning">
            <svg class="bookly:alert-icon" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg>
            <div class="bookly:alert-content bookly:space-y-2">
                <div class="bookly:text-base bookly:font-semibold"><?php esc_html_e( 'Bookly Pro - License verification required', 'bookly' ) ?></div>
                <p><?php esc_html_e( 'Access to your bookings has been disabled.', 'bookly' ) ?></p>
                <p><?php echo strtr( __( 'To enable access to your bookings, please verify your license by providing a valid purchase code. <a href="{url}">Details</a>', 'bookly' ), $replace_data ) ?></p>
                <div class="bookly:alert-actions"><button type="button" class="bookly:alert-btn bookly:alert-btn-primary bookly-js-deactivate-pro"><?php esc_html_e( 'Deactivate Bookly Pro', 'bookly' ) ?></button></div>
            </div>
            <button type="button" class="bookly:alert-close" data-dismiss="alert" data-trigger="temporary-hide" aria-label="<?php esc_attr_e( 'Close', 'bookly' ) ?>">
                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
            </button>
        </div>
    </div>
<?php endif ?>
