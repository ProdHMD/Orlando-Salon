<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly
use Bookly\Backend\Components\Settings\Selects;
use Bookly\Backend\Components\Controls\Elements;
use BooklyPro\Lib;
/** @var string $type */
?>
<div class="card bookly-collapse-with-arrow" data-gateway="<?php echo esc_attr( $type ) ?>">
    <div class="card-header d-flex align-items-center">
        <?php Elements::renderReorder() ?>
        <a href="#bookly_pmt_woocommerce" class="ml-2" role="button" data-toggle="bookly-collapse">
            WooCommerce
        </a>
        <img class="ml-auto" src="<?php echo plugins_url( 'frontend/resources/images/woocommerce-logo.svg', Lib\Plugin::getMainFile() ) ?>" alt="WooCommerce"/>
    </div>
    <div id="bookly_pmt_woocommerce" class="bookly-collapse bookly-show">
        <div class="card-body">
            <?php Selects::renderSingle( 'bookly_wc_enabled' ) ?>
        </div>
    </div>
</div>
