<?php

namespace InstagramFeed\Abilities\Abilities;

use InstagramFeed\Abilities\SBI_Ability_Response;
use InstagramFeed\Abilities\Services\SBI_Feed_Settings_Service;
use InstagramFeed\Abilities\Services\SBI_Settings_Schema;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * instagram-feed/update-feed-settings
 *
 * Gated by SBI_Write_Gate, then capability, then a per-key license-tier check:
 * tier-locked keys are not written and come back in `ignored` as
 * `feature_unavailable`.
 *
 * @since INSTA_FEED_PRO_SINCE
 */
class SBI_Update_Feed_Settings extends SBI_Ability
{
	public function slug()
	{
		return 'update-feed-settings';
	}

	public function args()
	{
		$writable = SBI_Settings_Schema::writable(SBI_Settings_Schema::feed_settings());
		$props    = array(
			'feed_id'  => array(
				'type'        => 'integer',
				'minimum'     => 1,
				'description' => 'Feed id from list-feeds.',
			),
			'settings' => array(
				'type'                 => 'object',
				'properties'           => SBI_Settings_Schema::to_json_properties($writable),
				'minProperties'        => 1,
				'additionalProperties' => false,
				'description'          => 'Settings to change. Only the keys you pass are changed; '
					. 'other stored values are re-saved as-is.',
			),
		);

		return array(
			'label'               => __('Update an Instagram Feed', 'instagram-feed'),
			'description'         => __('Changes one or more settings of a feed (layout, columns, post count, header, captions, buttons, colours). Only the keys you pass are changed. The highlight-layout source (highlighttype and its companions) and the custom color palette (colorpalette and its custom*color companions) are read-only here — use set-highlight-source and set-color-palette instead, which validate each coupled set together. Requires AI write access to be enabled in Instagram Feed → Settings → General. Returns updated, ignored and warnings.', 'instagram-feed'), // phpcs:ignore Generic.Files.LineLength.TooLong -- single literal for make-pot
			'input_schema'        => array(
				'type'                 => 'object',
				'properties'           => $props,
				'required'             => array('feed_id', 'settings'),
				'additionalProperties' => false,
			),
			'output_schema'       => $this->write_output_schema(array('feed_id' => array('type' => 'integer'))),
			'execute_callback'    => array($this, 'execute'),
			'permission_callback' => array($this, 'can_write'),
			'meta'                => $this->write_meta(false, true),
		);
	}

	public function execute($input = null)
	{
		$input   = $this->normalize_input($input);
		$feed_id = isset($input['feed_id']) ? (int) $input['feed_id'] : 0;
		if ($feed_id <= 0) {
			return SBI_Ability_Response::invalid_feed_id();
		}
		$settings = isset($input['settings']) ? $this->normalize_input($input['settings']) : array();

		$service = new SBI_Feed_Settings_Service();
		$result  = $service->update_feed($feed_id, $settings, array($this, 'is_feature_available'));

		return $result === null ? SBI_Ability_Response::feed_not_found($feed_id) : $result;
	}

	/**
	 * Same gate the Feed Builder applies: tier feature present AND license not lapsed.
	 *
	 * @param string $feature
	 * @return bool
	 */
	public function is_feature_available($feature)
	{
		return self::tier_check($feature);
	}

	/**
	 * Same gate the Feed Builder applies, reusable by other abilities.
	 *
	 * @param string $feature
	 * @return bool
	 */
	public static function tier_check($feature)
	{
		if (!function_exists('sbi_builder_pro')) {
			return true; // Free build: no tier concept.
		}
		$builder = sbi_builder_pro();
		if (empty($builder->license_tier)) {
			return true;
		}
		$disabled = !empty($builder->license_service) && !empty($builder->license_service->should_disable_pro_features);

		return !$disabled && $builder->license_tier->is_feature_available($feature);
	}
}
