<div id="sbi-support" class="sbi-support">
	<?php
	InstagramFeed\SBI_View::render('sections.header');
	InstagramFeed\SBI_View::render('support.content');

	include_once SBI_BUILDER_DIR . 'templates/sections/popup/license-learn-more.php';
	include_once SBI_BUILDER_DIR . 'templates/sections/popup/why-renew-license-popup.php';
	?>
</div>
