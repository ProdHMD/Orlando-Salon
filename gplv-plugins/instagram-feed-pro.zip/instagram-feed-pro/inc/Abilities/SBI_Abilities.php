<?php

namespace InstagramFeed\Abilities;

use InstagramFeed\Abilities\Abilities\SBI_Ability;
use InstagramFeed\Abilities\Abilities\SBI_Create_Feed;
use InstagramFeed\Abilities\Abilities\SBI_Describe_Settings_Schema;
use InstagramFeed\Abilities\Abilities\SBI_Get_Connect_Url;
use InstagramFeed\Abilities\Abilities\SBI_List_Sources;
use InstagramFeed\Abilities\Abilities\SBI_Request_Feed_Deletion;
use InstagramFeed\Abilities\Abilities\SBI_Set_Color_Palette;
use InstagramFeed\Abilities\Abilities\SBI_Set_Feed_Sources;
use InstagramFeed\Abilities\Abilities\SBI_Set_Highlight_Source;
use InstagramFeed\Abilities\Abilities\SBI_Get_Feed;
use InstagramFeed\Abilities\Abilities\SBI_Get_Global_Settings;
use InstagramFeed\Abilities\Abilities\SBI_List_Feeds;
use InstagramFeed\Abilities\Abilities\SBI_Update_Feed_Settings;
use InstagramFeed\Abilities\Abilities\SBI_Update_Global_Settings;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * WordPress Abilities API integration entry point.
 *
 * Exposes Instagram Feed *settings* to AI agents (MCP clients, WPVibe) through
 * the core Abilities API (WP 6.9+). Silent no-op on older WordPress. Follows the
 * cross-AM pattern established by WPForms: category on
 * `wp_abilities_api_categories_init`, abilities on `wp_abilities_api_init`,
 * capability-checked permission callbacks, writes off by default.
 *
 * @since INSTA_FEED_PRO_SINCE
 */
class SBI_Abilities
{
	public function __construct()
	{
		if (!self::is_available()) {
			return;
		}
		add_action('wp_abilities_api_categories_init', array($this, 'register_category'));
		add_action('wp_abilities_api_init', array($this, 'register_abilities'));

		// Browser-side halves of ability flows (delete confirmation, connect bootstrap).
		if (is_admin()) {
			new SBI_Delete_Confirmation();
			new SBI_Connect_Bootstrap();
		}
	}

	/**
	 * @return bool
	 */
	public static function is_available()
	{
		return function_exists('wp_register_ability') && function_exists('wp_register_ability_category');
	}

	public function register_category()
	{
		wp_register_ability_category(
			SBI_Ability::CATEGORY,
			array(
				'label'       => __('Instagram Feed', 'instagram-feed'),
				'description' => __('Read and update Instagram Feed settings.', 'instagram-feed'),
			)
		);
	}

	public function register_abilities()
	{
		foreach ($this->abilities() as $ability) {
			$ability->register();
		}
	}

	/**
	 * @return SBI_Ability[]
	 */
	protected function abilities()
	{
		$abilities = array(
			new SBI_Get_Global_Settings(),
			new SBI_List_Feeds(),
			new SBI_Get_Feed(),
			new SBI_Describe_Settings_Schema(),
			new SBI_Update_Global_Settings(),
			new SBI_Update_Feed_Settings(),
			new SBI_List_Sources(),
			new SBI_Create_Feed(),
			new SBI_Set_Feed_Sources(),
			new SBI_Set_Highlight_Source(),
			new SBI_Set_Color_Palette(),
			new SBI_Request_Feed_Deletion(),
			new SBI_Get_Connect_Url(),
		);

		/**
		 * Filters the abilities registered by Instagram Feed.
		 *
		 * @param SBI_Ability[] $abilities
		 */
		return apply_filters('sbi_abilities', $abilities);
	}
}
