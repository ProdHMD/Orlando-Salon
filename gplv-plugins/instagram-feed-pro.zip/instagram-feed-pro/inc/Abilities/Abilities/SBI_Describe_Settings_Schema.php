<?php

namespace InstagramFeed\Abilities\Abilities;

use InstagramFeed\Abilities\SBI_Write_Gate;
use InstagramFeed\Abilities\Services\SBI_Settings_Schema;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * instagram-feed/describe-settings-schema
 *
 * Lets an agent discover which keys it may change and their allowed values.
 * Always visible over REST; hidden from MCP discovery while writes are
 * disabled so agents are not shown an editing surface they cannot use
 * (same rationale as WPForms' describe-editing-schema).
 *
 * @since INSTA_FEED_PRO_SINCE
 */
class SBI_Describe_Settings_Schema extends SBI_Ability
{
	public function slug()
	{
		return 'describe-settings-schema';
	}

	public function args()
	{
		return array(
			'label'               => __('Describe editable Instagram Feed settings', 'instagram-feed'),
			'description'         => __(
				'Returns the JSON Schema of the per-feed and global settings that can be read or updated through the Instagram Feed abilities, and whether write access is currently enabled.', // phpcs:ignore Generic.Files.LineLength.TooLong -- single literal for make-pot
				'instagram-feed'
			),
			'output_schema'       => array(
				'type'       => 'object',
				'properties' => array(
					'write_enabled'   => array('type' => 'boolean'),
					'feed_settings'   => array('type' => 'object'),
					'global_settings' => array('type' => 'object'),
				),
			),
			'execute_callback'    => array($this, 'execute'),
			'permission_callback' => array($this, 'can_manage'),
			'meta'                => $this->read_meta(SBI_Write_Gate::is_enabled()),
		);
	}

	public function execute()
	{
		return array(
			'write_enabled'   => SBI_Write_Gate::is_enabled(),
			'feed_settings'   => array(
				'type'       => 'object',
				'properties' => SBI_Settings_Schema::to_json_properties(SBI_Settings_Schema::feed_settings()),
			),
			'global_settings' => array(
				'type'       => 'object',
				'properties' => SBI_Settings_Schema::to_json_properties(SBI_Settings_Schema::global_settings()),
			),
		);
	}
}
