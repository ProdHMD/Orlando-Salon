<?php
namespace BooklyPro\Frontend\Modules\ModernBookingForm\ProxyProviders;

use Bookly\Frontend\Modules\ModernBookingForm\Proxy;
use BooklyPro\Frontend\Modules\ModernBookingForm\Form;

class Shared extends Proxy\Shared
{
    /**
     * @inheritDoc
     */
    public static function getCssVars( array $appearance )
    {
        return Form::getCssVars( $appearance );
    }

    /**
     * @inheritDoc
     */
    public static function getThemeWrapperClasses( array $appearance )
    {
        return Form::getThemeWrapperClasses( $appearance );
    }

    /**
     * @inheritDoc
     */
    public static function enqueueThemeStyles( array $appearance )
    {
        Form::enqueueTheme( $appearance );

        return $appearance;
    }
}
