<?php
namespace BooklyPro\Backend\Modules\Dashboard\ProxyProviders;

use Bookly\Backend\Modules\Dashboard\Proxy;
use Bookly\Lib as BooklyLib;
use BooklyPro\Lib;

class Local extends Proxy\Pro
{
    /**
     * Analytics rows + totals (staff × service breakdown) for the combined dashboard
     * endpoint — the page loads everything in one round-trip. Accepts the RAW filter:
     * empty staff / services mean "all". Returns the datatable-ready payload.
     *
     * @inheritDoc
     */
    public static function getDashboardAnalytics( $range, $based_on, $filter )
    {
        /** @global \wpdb $wpdb */
        global $wpdb;

        $staff_ids = isset( $filter['staff'] ) ? $filter['staff'] : array();
        if ( $staff_ids === 'all' || empty( $staff_ids ) ) {
            $staff_ids = BooklyLib\Entities\Staff::query()->fetchCol( 'id' );
        }

        if ( isset( $filter['services'] ) && ! empty( $filter['services'] ) ) {
            $service_ids = array_map( function ( $id ) { return $id ?: null; }, $filter['services'] );
        } else {
            // All: Custom (NULL service) + every simple service.
            $service_ids = array_merge( array( null ), array_map( 'intval', BooklyLib\Entities\Service::query()->where( 'type', 'simple' )->fetchCol( 'id' ) ) );
        }

        $postfix_archived = sprintf( ' (%s)', __( 'Archived', 'bookly' ) );

        list ( $start, $end ) = explode( ' - ', $range, 2 );
        $end = date( 'Y-m-d', strtotime( '+1 day', strtotime( $end ) ) );
        $date_col = $based_on === 'start_date' ? 'a.start_date' : 'ca.created_at';

        // Everything is aggregated in SQL — no per-appointment rows are fetched into PHP,
        // so both the memory footprint and the payload are bounded by the number of active
        // staff × service pairs, not by the number of appointments. Pairs without activity
        // in the period are not emitted at all.
        $staff_service_filter = function ( $query ) use ( $staff_ids, $service_ids ) {
            $query->whereIn( 'a.staff_id', $staff_ids );
            if ( array_search( null, $service_ids, true ) !== false ) {
                $where_raw = 'a.service_id IS NULL';
                $service_ids_filtered = array_filter( $service_ids );
                if ( ! empty ( $service_ids_filtered ) ) {
                    $where_raw .= sprintf( ' OR a.service_id IN (%s)', implode( ',', $service_ids_filtered ) );
                }
                $query->whereRaw( $where_raw, array() );
            } else {
                $query->whereIn( 'a.service_id', $service_ids );
            }

            return $query;
        };
        $period_filter = function ( $query ) use ( $staff_service_filter, $date_col, $start, $end ) {
            return $staff_service_filter( $query->whereBetween( $date_col, $start, $end ) );
        };

        // Appointment counts per pair and status.
        $status_rows = $period_filter(
            BooklyLib\Entities\CustomerAppointment::query( 'ca' )
                ->select( 'a.staff_id, a.service_id, ca.status, COUNT(1) AS quantity' )
                ->leftJoin( 'Appointment', 'a', 'a.id = ca.appointment_id' )
                ->groupBy( 'a.staff_id, a.service_id, ca.status' )
        )->fetchArray();

        // Distinct customers per pair.
        $customer_rows = $period_filter(
            BooklyLib\Entities\CustomerAppointment::query( 'ca' )
                ->select( 'a.staff_id, a.service_id, COUNT(DISTINCT ca.customer_id) AS customers' )
                ->leftJoin( 'Appointment', 'a', 'a.id = ca.appointment_id' )
                ->groupBy( 'a.staff_id, a.service_id' )
        )->fetchArray();

        // Revenue per pair: a payment is counted once per pair (inner GROUP BY p.id), while
        // a payment covering appointments of several pairs contributes to each of them —
        // that is why the grand total below is computed separately, counting it once.
        //
        // paid + child_paid over parent payments only — the rule the payments list and the
        // dashboard KPI both use. Plain p.paid drops every balance top-up made through the
        // checkout form, since a top-up is a separate payment hanging off the parent.
        $revenue_subquery = $period_filter(
            BooklyLib\Entities\Payment::query( 'p' )
                ->select( 'a.staff_id AS staff_id, a.service_id AS service_id, (p.paid + p.child_paid) AS paid' )
                ->innerJoin( 'CustomerAppointment', 'ca', 'ca.payment_id = p.id' )
                ->leftJoin( 'Appointment', 'a', 'a.id = ca.appointment_id' )
                ->where( 'p.parent_id', null )
                ->groupBy( 'a.staff_id, a.service_id, p.id' )
        );
        $revenue_rows = $wpdb->get_results( 'SELECT staff_id, service_id, SUM(paid) AS revenue FROM (' . $revenue_subquery->composeQuery() . ') t GROUP BY staff_id, service_id', ARRAY_A );

        // Grand totals.
        $total_revenue_subquery = $period_filter(
            BooklyLib\Entities\Payment::query( 'p' )
                ->select( '(p.paid + p.child_paid) AS paid' )
                ->innerJoin( 'CustomerAppointment', 'ca', 'ca.payment_id = p.id' )
                ->leftJoin( 'Appointment', 'a', 'a.id = ca.appointment_id' )
                ->where( 'p.parent_id', null )
                ->groupBy( 'p.id' )
        );
        $total_revenue = (float) $wpdb->get_var( 'SELECT SUM(paid) FROM (' . $total_revenue_subquery->composeQuery() . ') t' );

        $total_customers_row = $period_filter(
            BooklyLib\Entities\CustomerAppointment::query( 'ca' )
                ->select( 'COUNT(DISTINCT ca.customer_id) AS total' )
                ->leftJoin( 'Appointment', 'a', 'a.id = ca.appointment_id' )
        )->fetchArray();
        $total_customers = (int) $total_customers_row[0]['total'];

        // Assemble the cells; created on demand — only pairs present in the aggregates.
        $data = array();
        $ensure_cell = function ( $staff_id, $service_id ) use ( &$data, $postfix_archived ) {
            if ( ! isset ( $data[ $staff_id ][ $service_id ] ) ) {
                $staff = BooklyLib\Entities\Staff::find( $staff_id );
                $data[ $staff_id ][ $service_id ] = array(
                    'staff'   => $staff->getFullName() . ( $staff->getVisibility() == 'archive' ? $postfix_archived : '' ),
                    'service' => $service_id ? BooklyLib\Entities\Service::find( $service_id )->getTitle() : __( 'Custom', 'bookly' ),
                    'appointments' => array(
                        'total' => 0,
                        'pending' => 0,
                        'approved' => 0,
                        'rejected' => 0,
                        'cancelled' => 0,
                        'waitlisted' => 0,
                    ),
                    'customers' => array(
                        'total' => 0,
                    ),
                    'revenue' => array(
                        'total' => 0.0,
                    ),
                );
            }
        };

        $custom_statuses = BooklyLib\Proxy\CustomStatuses::getAll() ?: array();
        foreach ( $status_rows as $row ) {
            $ensure_cell( $row['staff_id'], $row['service_id'] );
            $record = &$data[ $row['staff_id'] ][ $row['service_id'] ];
            $quantity = (int) $row['quantity'];
            switch ( $row['status'] ) {
                case BooklyLib\Entities\CustomerAppointment::STATUS_PENDING:
                    $record['appointments']['pending'] += $quantity;
                    break;
                case BooklyLib\Entities\CustomerAppointment::STATUS_APPROVED:
                case BooklyLib\Entities\CustomerAppointment::STATUS_DONE: // done ≈ approved (optional/automated status)
                    $record['appointments']['approved'] += $quantity;
                    break;
                case BooklyLib\Entities\CustomerAppointment::STATUS_REJECTED:
                    $record['appointments']['rejected'] += $quantity;
                    break;
                case BooklyLib\Entities\CustomerAppointment::STATUS_CANCELLED:
                    $record['appointments']['cancelled'] += $quantity;
                    break;
                case BooklyLib\Entities\CustomerAppointment::STATUS_WAITLISTED:
                    $record['appointments']['waitlisted'] += $quantity;
                    break;
                default:
                    if ( isset ( $custom_statuses[ $row['status'] ] ) ) {
                        if ( $custom_statuses[ $row['status'] ]->getBusy() ) {
                            // Consider as APPROVED.
                            $record['appointments']['approved'] += $quantity;
                        } else {
                            // Consider as CANCELLED.
                            $record['appointments']['cancelled'] += $quantity;
                        }
                    }
            }
            $record['appointments']['total'] += $quantity;
            unset ( $record );
        }
        foreach ( $customer_rows as $row ) {
            $ensure_cell( $row['staff_id'], $row['service_id'] );
            $data[ $row['staff_id'] ][ $row['service_id'] ]['customers']['total'] = (int) $row['customers'];
        }
        foreach ( $revenue_rows as $row ) {
            $ensure_cell( $row['staff_id'], $row['service_id'] );
            $data[ $row['staff_id'] ][ $row['service_id'] ]['revenue']['total'] = (float) $row['revenue'];
        }

        $result = array();
        $total  = array(
            'appointments' => array(
                'total' => 0,
                'pending' => 0,
                'approved' => 0,
                'rejected' => 0,
                'cancelled' => 0,
                'waitlisted' => 0,
            ),
            'customers' => array(
                'total' => $total_customers,
            ),
            'revenue' => array(
                'total' => $total_revenue,
            ),
        );
        foreach ( $data as $staff_data ) {
            foreach ( $staff_data as $record ) {
                $record['revenue']['total_formatted'] = BooklyLib\Utils\Price::format( $record['revenue']['total'] );

                $result[] = $record;

                $total['appointments']['total'] += $record['appointments']['total'];
                $total['appointments']['pending'] += $record['appointments']['pending'];
                $total['appointments']['approved'] += $record['appointments']['approved'];
                $total['appointments']['rejected'] += $record['appointments']['rejected'];
                $total['appointments']['cancelled'] += $record['appointments']['cancelled'];
                $total['appointments']['waitlisted'] += $record['appointments']['waitlisted'];
            }
        }
        $total['revenue']['total_formatted'] = BooklyLib\Utils\Price::format( $total['revenue']['total'] );

        // Sales that this report cannot show: its axis is staff × service, and a gift card
        // has neither while a ticket has no service. Reported alongside the total so the
        // table and the dashboard Revenue visibly add up instead of silently disagreeing.
        // Only when the install can actually sell one of these. The figure counts every
        // payment with no appointment behind it, which on a site without those add-ons
        // could still pick up the odd stray payment — and labelling that "packages,
        // tickets and gift cards" would be a plain lie.
        $sells_extras = BooklyLib\Config::eventsActive() || BooklyLib\Config::packagesActive() || BooklyLib\Config::giftCardsActive();
        // The RAW filter, not $staff_ids: that one has already been expanded to "every
        // staff member" when no filter is set, and handing it over would look like an
        // active filter and drop tickets and gift cards from the figure.
        $sales_revenue = $sells_extras
            ? \Bookly\Backend\Components\Dashboard\Appointments\Ajax::standaloneSalesRevenue(
                $start . ' 00:00:00',
                $end . ' 00:00:00',
                isset( $filter['staff'] ) ? $filter['staff'] : array(),
                isset( $filter['services'] ) ? $filter['services'] : array()
            )
            : 0.0;
        $total['sales_revenue'] = array(
            'total' => $sales_revenue,
            'total_formatted' => BooklyLib\Utils\Price::format( $sales_revenue ),
        );
        $total['grand_revenue'] = array(
            'total' => $total['revenue']['total'] + $sales_revenue,
            'total_formatted' => BooklyLib\Utils\Price::format( $total['revenue']['total'] + $sales_revenue ),
        );

        return array(
            'data' => $result,
            'recordsTotal' => count( $result ),
            'recordsFiltered' => count( $result ),
            'total' => $total,
        );
    }

    /**
     * @inheritDoc
     */
    public static function renderAnalytics()
    {
        self::enqueueScripts( array(
            'module' => array( 'js/dashboard-pro.js' => array( 'bookly-backend-globals' ), ),
        ) );
        $datatables = BooklyLib\Utils\Tables::getSettings( 'analytics' );

        // Flatten the categorised staff / service drop-down data into flat option
        // lists for the in-datatable checkboxGroup filters.
        $dropdown_data = array(
            'service' => BooklyLib\Utils\Common::getServiceDataForDropDown( 's.type = "simple"' ),
            'staff'   => Lib\ProxyProviders\Local::getStaffDataForDropDown()
        );
        $staff_options = array();
        foreach ( $dropdown_data['staff'] as $category ) {
            foreach ( $category['items'] as $st ) {
                $staff_options[] = array( 'value' => (int) $st['id'], 'label' => $st['full_name'] );
            }
        }
        $service_options = array( array( 'value' => 0, 'label' => __( 'Custom', 'bookly' ) ) );
        foreach ( $dropdown_data['service'] as $category ) {
            foreach ( $category['items'] as $sv ) {
                $service_options[] = array( 'value' => (int) $sv['id'], 'label' => $sv['title'] );
            }
        }

        wp_localize_script( 'bookly-dashboard-pro.js', 'BooklyAnalyticsL10n', array(
            'datatables' => $datatables,
            'zeroRecords' => __( 'No appointments for selected period.', 'bookly' ),
            'emptyTable' => __( 'No appointments for selected period.', 'bookly' ),
            'search' => __( 'Search', 'bookly' ) . '…',
            'total' => __( 'Total', 'bookly' ),
            'staffLabel' => BooklyLib\Utils\Common::getTranslatedOption( 'bookly_l10n_label_employee' ),
            'serviceLabel' => BooklyLib\Utils\Common::getTranslatedOption( 'bookly_l10n_label_service' ),
            'staffOptions' => $staff_options,
            'serviceOptions' => $service_options,
            'exportCsv' => __( 'Export to CSV', 'bookly' ) . '…',
            'print' => __( 'Print', 'bookly' ) . '…',
            // Reconciliation line under the table: this report covers appointments only,
            // so its total is short of the dashboard Revenue by exactly the sales that
            // have no staff and no service to be listed under.
            'appointmentsRevenue' => __( 'Appointments revenue', 'bookly' ),
            'otherSales' => __( 'Packages, tickets and gift cards', 'bookly' ),
            'grandRevenue' => __( 'Revenue for the period', 'bookly' ),
            'filter' => $datatables['analytics']['settings']['filter'],
        ) );

        self::renderTemplate( 'analytics' );
    }
}
