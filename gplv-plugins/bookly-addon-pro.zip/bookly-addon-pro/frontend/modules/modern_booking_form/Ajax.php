<?php
namespace BooklyPro\Frontend\Modules\ModernBookingForm;

use Bookly\Lib as BooklyLib;
use BooklyPro\Lib as ProLib;
use Bookly\Lib\Entities;
use Bookly\Lib\Base\Gateway;
use BooklyPro\Frontend\Modules\ModernBookingForm\Lib\Request;
use BooklyPro\Lib\Utils\Common;

class Ajax extends BooklyLib\Base\Ajax
{
    /**
     * @inheritDoc
     */
    protected static function permissions()
    {
        return array( '_default' => 'anonymous' );
    }

    public static function modernBookingFormGetServices()
    {
        $list = array();
        $filters = self::parameter( 'filters' );
        $date = date_create( self::parameter( 'date' ) );
        if ( ! isset( $filters['locations'] ) ) {
            $filters['locations'] = array( 0 );
        }
        foreach ( $filters['services'] as $service_id ) {
            $service = BooklyLib\Entities\Service::find( $service_id );
            // When staff member selection is disallowed for collaborative services,
            // such a service is represented by a single 'Any staff' card
            // (regardless of show_services_mode and the number of staff members,
            // otherwise it cannot be booked at all),
            // and personal staff cards are not created for it.
            $any_staff_only = $service
                && $service->isCollaborative()
                && get_option( 'bookly_collaborative_hide_staff' );
            // The single pass pays off when per-staff cards are listed; in 'only_any'
            // mode with several staff members the old path makes a single probe anyway.
            // Besides simple services it also covers compound/collaborative ones without
            // the same-staff requirement: their per-staff probes restrict the staff
            // member to the first stage only (later stages take any provider), which is
            // exactly what the winner slots of a pooled search carry. A duplicated stage
            // is the exception: the staff lists of the stages are cached by service, so
            // an individual probe restricts every duplicate to the staff member.
            $pooled_subs = false;
            if ( $service && $service->withSubServices() && ! $service->getSameStaffForSubservices() ) {
                $sub_ids = array();
                foreach ( $service->getSubServices() as $sub_service ) {
                    $sub_ids[] = $sub_service->getId();
                }
                $pooled_subs = count( $sub_ids ) === count( array_unique( $sub_ids ) );
            }
            $single_pass = $service
                && ( $service->getType() == BooklyLib\Entities\Service::TYPE_SIMPLE || $pooled_subs )
                && ( self::parameter( 'show_services_mode' ) !== 'only_any' || count( $filters['staff'] ) === 1 );
            foreach ( $filters['locations'] as $location_id ) {
                if ( $any_staff_only ) {
                    if ( self::hasSlots( $date, $service_id, $location_id, $filters['staff'] ) ) {
                        $list[] = array( 'service_id' => $service_id, 'staff_id' => $filters['staff'], 'location_id' => $location_id );
                    }
                    continue;
                }
                if ( $single_pass ) {
                    // Simple service: one search per capacity group yields both the 'Any staff'
                    // answer and the set of bookable staff members (winner slots carry the full
                    // chain of alternative staff), instead of a separate full search per staff.
                    list( $any_has_slots, $available ) = self::availabilityViaSinglePass( $date, $service, $location_id, $filters['staff'] );
                } else {
                    $any_has_slots = null;
                    $available = null;
                }
                $any_index = null;
                $staff_count = 0;
                $show_any = in_array( self::parameter( 'show_services_mode' ), array( 'all', 'only_any' ) ) && count( $filters['staff'] ) > 1;
                $any_slots_found = $show_any && ( $single_pass
                    ? $any_has_slots
                    : self::hasSlots( $date, $service_id, $location_id, $filters['staff'] ) );
                if ( $any_slots_found ) {
                    $list[] = array( 'service_id' => $service_id, 'staff_id' => $filters['staff'], 'location_id' => $location_id );
                    $any_index = count( $list ) - 1;
                }
                if ( self::parameter( 'show_services_mode' ) !== 'only_any' || count( $filters['staff'] ) === 1 ) {
                    if ( $available === null ) {
                        // Compound/collaborative service with the same-staff requirement:
                        // a pooled search would mix staff across the stages, so the staff
                        // members are probed one by one - but sharing one prepared
                        // scheduler per capacity group instead of repeating the database
                        // work of a separate scheduler per probe.
                        $available = $service ? self::availabilityViaProbes( $date, $service, $location_id, $filters['staff'] ) : array();
                    }
                    foreach ( $filters['staff'] as $staff_id ) {
                        if ( isset( $available[ $staff_id ] ) ) {
                            $list[] = compact( 'service_id', 'staff_id', 'location_id' );
                            $staff_count++;
                        }
                    }
                }
                if ( in_array( self::parameter( 'show_services_mode' ), array( 'all', 'only_any' ) ) && count( $filters['staff'] ) > 1 && $staff_count === 1 && $any_index !== null ) {
                    array_splice( $list, $any_index, 1 );
                }
            }
        }

        wp_send_json_success( $list );
    }

    protected static function hasSlots( $date, $service_id, $location_id, $staff_ids )
    {
        $service = BooklyLib\Entities\Service::find( $service_id );
        if ( $service ) {
            $nop = 1;
            if ( BooklyLib\Config::groupBookingActive() ) {
                if ( count( $staff_ids ) > 1 ) {
                    $staff_nop = Entities\StaffService::query()
                        ->whereIn( 'staff_id', $staff_ids )
                        ->where( 'service_id', $service_id )
                        ->fetchVar( 'MIN(capacity_min)' );
                    $nop = $staff_nop ? (int) $staff_nop : $service->getCapacityMin();
                } elseif ( count( $staff_ids ) == 1 ) {
                    $staff_service = new Entities\StaffService();
                    if ( $staff_service->loadBy( array( 'service_id' => $service_id, 'staff_id' => $staff_ids[0], 'location_id' => null ) ) ) {
                        $nop = $staff_service->getCapacityMin();
                    }
                }
            }
            $chain_item = new BooklyLib\ChainItem();
            $chain_item
                ->setStaffIds( $staff_ids )
                ->setServiceId( $service_id )
                ->setNumberOfPersons( $nop )
                ->setQuantity( 1 )
                ->setLocationId( $location_id )
                ->setUnits( $service->getUnitsMin() )
                ->setExtras( array() );

            $chain = new BooklyLib\Chain();
            $chain->add( $chain_item );
            $params = array( 'every' => 1, 'full_day' => true );
            if ( BooklyLib\Config::useClientTimeZone() ) {
                $params['time_zone'] = self::parameter( 'time_zone' ) ?: null;
                $params['time_zone_offset'] = self::parameter( 'time_zone_offset' ) ?: null;
            }
            if ( self::parameter( 'show_blocked_slots' ) ) {
                $params['show_blocked_slots'] = true;
            }
            $scheduler = new BooklyLib\Scheduler( $chain, $date->format( 'Y-m-d 00:00' ), $date->format( 'Y-m-d' ), 'daily', $params, array(), BooklyLib\Config::waitingListActive() );
            // Only the fact of availability matters here: without the options the search
            // stops at the first bookable slot instead of building the data of every
            // slot of the day, and the yes/no answer is the same.
            $schedule = $scheduler->scheduleForFrontend();
            if ( isset( $schedule[0]['options'] ) && count( $schedule[0]['options'] ) ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Collect availability of a simple service for the 'Any staff' card and every staff
     * member in one search per capacity group, instead of a separate full search per
     * staff member. The per-staff searches would run with the number of persons equal
     * to the staff capacity_min, so staff members are grouped by that value and one
     * search is run per distinct value; a winner slot carries the full chain of
     * alternative staff members for its time, which yields the same set of bookable
     * staff as the individual probes.
     *
     * @param \DateTime $date
     * @param BooklyLib\Entities\Service $service
     * @param int $location_id
     * @param array $staff_ids
     * @return array [ bool $any_has_slots, array $available staff_id => true ]
     */
    protected static function availabilityViaSinglePass( $date, $service, $location_id, array $staff_ids )
    {
        $service_id = $service->getId();
        list( $groups, $any_nop ) = self::staffNopGroups( $service, $staff_ids );

        $any_has_slots = null;
        $available = array();
        foreach ( $groups as $nop => $group_staff_ids ) {
            list( $has_slots, $bookable_staff ) = self::runAvailabilityPass( $date, $service, $location_id, $group_staff_ids, $nop );
            foreach ( $bookable_staff as $staff_id ) {
                $available[ $staff_id ] = true;
            }
            if ( $nop === $any_nop ) {
                $any_has_slots = $has_slots;
            }
        }
        if ( $any_has_slots === null ) {
            // No capacity group matches the 'Any staff' number of persons - answer it
            // with the plain probe.
            $any_has_slots = self::hasSlots( $date, $service_id, $location_id, $staff_ids );
        }

        // The alternatives chain of a time keeps only the best availability tier: when
        // the waiting list is active, a staff member whose only slots have a started
        // waiting list is hidden by colleagues with free slots at the same times. Such
        // staff members are re-checked individually - only those who provide the
        // service and were not found by the passes; on a regular day there are few of
        // them, and without the waiting list the tiers cannot mask each other.
        if ( BooklyLib\Config::waitingListActive() ) {
            // For a service with sub-services the individual probe restricts the staff
            // member to the first stage, so that stage defines who can be bookable.
            $provider_service_id = $service_id;
            if ( $service->withSubServices() ) {
                $sub_services = $service->getSubServices();
                if ( ! empty( $sub_services ) ) {
                    $provider_service_id = $sub_services[0]->getId();
                }
            }
            $providers = array_flip( array_map( 'intval', Entities\StaffService::query()
                ->whereIn( 'staff_id', $staff_ids )
                ->where( 'service_id', $provider_service_id )
                ->fetchCol( 'staff_id' ) ) );
            foreach ( $staff_ids as $staff_id ) {
                if ( isset( $providers[ $staff_id ] ) && ! isset( $available[ $staff_id ] ) && self::hasSlots( $date, $service_id, $location_id, array( $staff_id ) ) ) {
                    $available[ $staff_id ] = true;
                }
            }
        }

        return array( $any_has_slots, $available );
    }

    /**
     * Run one availability search for a set of staff members and collect which of them
     * have at least one bookable slot on the requested day. The scheduler is built with
     * the same parameters as in hasSlots, so the date window, client timezone and
     * blocked-slots handling stay identical to the individual probes.
     *
     * @param \DateTime $date
     * @param BooklyLib\Entities\Service $service
     * @param int $location_id
     * @param array $staff_ids
     * @param int $nop
     * @return array [ bool $has_slots, int[] $bookable_staff ]
     */
    protected static function runAvailabilityPass( $date, $service, $location_id, array $staff_ids, $nop )
    {
        $scheduler = self::buildAvailabilityScheduler( $date, $service, $location_id, $staff_ids, $nop );
        // No options needed: the availability flag follows from the found slot alone,
        // and staffWithSlots() reads the loaded slots of the finder directly.
        $schedule = $scheduler->scheduleForFrontend();
        $has_slots = isset( $schedule[0]['options'] ) && count( $schedule[0]['options'] ) > 0;

        return array( $has_slots, $scheduler->staffWithSlots() );
    }

    /**
     * Collect availability of a compound or collaborative service for every staff
     * member. A pooled pass cannot be used here: a personal card means the staff
     * member serves the whole chain of stages, while a pooled search mixes staff
     * across the stages. Instead the probes share one prepared scheduler per
     * capacity group and reload only the search itself for every staff member,
     * which skips the repeated database work of a separate scheduler per probe.
     *
     * @param \DateTime $date
     * @param BooklyLib\Entities\Service $service
     * @param int $location_id
     * @param array $staff_ids
     * @return array $available staff_id => true
     */
    protected static function availabilityViaProbes( $date, $service, $location_id, array $staff_ids )
    {
        list( $groups ) = self::staffNopGroups( $service, $staff_ids );

        $available = array();
        foreach ( $groups as $nop => $group_staff_ids ) {
            $scheduler = self::buildAvailabilityScheduler( $date, $service, $location_id, $group_staff_ids, $nop );
            foreach ( $group_staff_ids as $staff_id ) {
                if ( $scheduler->staffProbe( array( (int) $staff_id ) ) ) {
                    $available[ $staff_id ] = true;
                }
            }
        }

        return $available;
    }

    /**
     * Group staff by the number of persons their availability must be checked with:
     * the same values the per-staff probes would use (capacity_min of the staff
     * service record without a location, 1 when there is no record or group booking
     * is inactive). Also resolve the number of persons of the 'Any staff' probe:
     * MIN(capacity_min) of the staff service records (with or without a location),
     * or service capacity_min as a fallback.
     *
     * @param BooklyLib\Entities\Service $service
     * @param array $staff_ids
     * @return array [ array $groups nop => staff_ids, int $any_nop ]
     */
    protected static function staffNopGroups( $service, array $staff_ids )
    {
        $groups = array();
        $any_nop = 1;
        if ( BooklyLib\Config::groupBookingActive() ) {
            $capacity = array();
            $rows = Entities\StaffService::query()
                ->select( 'staff_id, capacity_min' )
                ->whereIn( 'staff_id', $staff_ids )
                ->where( 'service_id', $service->getId() )
                ->whereRaw( 'location_id IS NULL', array() )
                ->fetchArray();
            foreach ( $rows as $row ) {
                $capacity[ $row['staff_id'] ] = (int) $row['capacity_min'];
            }
            foreach ( $staff_ids as $staff_id ) {
                $nop = isset( $capacity[ $staff_id ] ) ? $capacity[ $staff_id ] : 1;
                $groups[ $nop ][] = $staff_id;
            }
            $staff_nop = Entities\StaffService::query()
                ->whereIn( 'staff_id', $staff_ids )
                ->where( 'service_id', $service->getId() )
                ->fetchVar( 'MIN(capacity_min)' );
            $any_nop = $staff_nop ? (int) $staff_nop : $service->getCapacityMin();
        } else {
            $groups[1] = $staff_ids;
        }

        return array( $groups, $any_nop );
    }

    /**
     * Build a scheduler for an availability check with the same parameters as in
     * hasSlots, so the date window, client timezone and blocked-slots handling stay
     * identical to the individual probes.
     *
     * @param \DateTime $date
     * @param BooklyLib\Entities\Service $service
     * @param int $location_id
     * @param array $staff_ids
     * @param int $nop
     * @return BooklyLib\Scheduler
     */
    protected static function buildAvailabilityScheduler( $date, $service, $location_id, array $staff_ids, $nop )
    {
        $chain_item = new BooklyLib\ChainItem();
        $chain_item
            ->setStaffIds( $staff_ids )
            ->setServiceId( $service->getId() )
            ->setNumberOfPersons( $nop )
            ->setQuantity( 1 )
            ->setLocationId( $location_id )
            ->setUnits( $service->getUnitsMin() )
            ->setExtras( array() );

        $chain = new BooklyLib\Chain();
        $chain->add( $chain_item );
        $params = array( 'every' => 1, 'full_day' => true );
        if ( BooklyLib\Config::useClientTimeZone() ) {
            $params['time_zone'] = self::parameter( 'time_zone' ) ?: null;
            $params['time_zone_offset'] = self::parameter( 'time_zone_offset' ) ?: null;
        }
        if ( self::parameter( 'show_blocked_slots' ) ) {
            $params['show_blocked_slots'] = true;
        }

        return new BooklyLib\Scheduler( $chain, $date->format( 'Y-m-d 00:00' ), $date->format( 'Y-m-d' ), 'daily', $params, array(), BooklyLib\Config::waitingListActive() );
    }

    public static function modernBookingFormGetSlots()
    {
        $staff_ids = array();
        $location_ids = array();
        $date = self::parameter( 'date' );
        $max_quantity = (int) get_option( 'bookly_multiply_appointments_quantity_max', 10 );
        $chain = new BooklyLib\Chain();
        foreach ( self::parameter( 'chain' ) as $item ) {
            $service_id = $item['service_id'];
            if ( is_array( $item['staff_id'] ) ) {
                $chain_staffs = $item['staff_id'];
                foreach ( $item['staff_id'] as $staff ) {
                    $staff_ids[] = $staff;
                }
            } else {
                $chain_staffs = array( $item['staff_id'] );
                $staff_ids[] = $item['staff_id'];
            }
            $location_id = $item['location_id'];
            if ( ! in_array( $location_id, $location_ids, true ) ) {
                $location_ids[] = $location_id;
            }
            $nop = isset( $item['nop'] ) ? $item['nop'] : 1;
            $units = isset( $item['units'] ) ? $item['units'] : 1;
            $quantity = isset( $item['quantity'] ) ? max( 1, min( (int) $item['quantity'], $max_quantity ) ) : 1;
            $extras = isset( $item['extras'] ) ? $item['extras'] : array();
            foreach ( array_keys( $extras, 0, false ) as $key ) {
                unset( $extras[ $key ] );
            }

            $chain_item = new BooklyLib\ChainItem();
            $chain_item
                ->setStaffIds( $chain_staffs )
                ->setServiceId( $service_id )
                ->setNumberOfPersons( $nop )
                ->setQuantity( $quantity )
                ->setLocationId( $location_id )
                ->setUnits( $units )
                ->setExtras( $extras );

            $chain->add( $chain_item );
        }

        $params = array(
            'every' => 1,
            'with_nop' => true,
            'full_day' => true
        );

        $customer = self::parameter( 'customer' );
        $use_time_zone = false;
        if ( array_key_exists( 'time_zone', $customer ) && array_key_exists( 'time_zone_offset', $customer ) && ! $customer['time_zone_offset'] && $customer['time_zone'] ) {
            $time_zone = $customer['time_zone'];
            $time_zone_offset = null;
            if ( preg_match( '/^UTC[+-]/', $time_zone ) ) {
                $offset = preg_replace( '/UTC\+?/', '', $time_zone );
                $time_zone = null;
                $time_zone_offset = -$offset * 60;
            }
            $use_time_zone = true;
            $params['time_zone'] = $time_zone;
            $params['time_zone_offset'] = $time_zone_offset;
        } elseif ( BooklyLib\Config::useClientTimeZone() && ( isset( $customer['time_zone_offset'] ) || isset( $customer['time_zone'] ) ) ) {
            $time_zone_offset = isset( $customer['time_zone_offset'] ) && $customer['time_zone_offset'] !== '' ? $customer['time_zone_offset'] : null;
            $time_zone = isset( $customer['time_zone'] ) ? $customer['time_zone'] : null;
            $use_time_zone = true;
            $params['time_zone'] = $time_zone;
            $params['time_zone_offset'] = $time_zone_offset;
        }

        $request = new Request();
        $userData = $request->getUserData();
        $params['userData'] = $userData;

        if ( self::parameter( 'recurring_schedule' ) ) {
            $type = self::parameter( 'recurring_type' );
            switch ( $type ) {
                case 'daily':
                    $params['every'] = self::parameter( 'recurring_interval' );
                    break;
                case 'weekly':
                case 'biweekly':
                    $params['on'] = self::parameter( 'recurring_week_days' );
                    break;
                case 'monthly':
                    $on = self::parameter( 'recurring_month_type' );
                    $params['on'] = $on;
                    if ( $on === 'day' ) {
                        $params['day'] = self::parameter( 'recurring_month_days' );
                    } else {
                        $params['weekday'] = self::parameter( 'recurring_month_week' );
                    }
                    break;
            }
            if ( isset( $time_zone ) ) {
                $datetime = BooklyLib\Slots\DatePoint::fromStrInTz( $date . ' ' . self::parameter( 'recurring_time' ), $time_zone )->toWpTz()->format( 'Y-m-d H:i:s' );
            } else {
                $datetime = $date . ' ' . self::parameter( 'recurring_time' );
            }
            $params['full_day'] = false;
            $scheduler = new BooklyLib\Scheduler( $chain, $datetime, date_create( self::parameter( 'recurring_until' ) )->format( 'Y-m-d' ), $type, $params, array(), false );
            $schedule = $scheduler->scheduleForFrontend();
        } else {
            if ( self::parameter( 'show_blocked_slots' ) ) {
                $params['show_blocked_slots'] = true;
            }
            $scheduler = new BooklyLib\Scheduler( $chain, date_create( $date )->format( 'Y-m-d 00:00' ), date_create( $date )->format( 'Y-m-d' ), 'daily', $params, array(), ( ! self::hasParameter( 'waiting_list' ) || self::parameter( 'waiting_list' ) ) && BooklyLib\Config::waitingListActive() );
            $schedule = $scheduler->scheduleForFrontend( 1 );
            if ( count( $schedule ) > 1 ) {
                foreach ( array_keys( $schedule ) as $key ) {
                    if ( $schedule[ $key ]['date'] !== $date ) {
                        unset( $schedule[ $key ] );
                    }
                }
                $schedule = array_values( $schedule );
            }
        }

        foreach ( $schedule as &$_schedule ) {
            if ( isset( $_schedule['options'] ) ) {
                foreach ( $_schedule['options'] as &$option ) {
                    $slots = json_decode( $option['value'], false );
                    $option['slots'] = array();
                    $slot_index = 0;
                    foreach ( self::parameter( 'chain' ) as $item ) {
                        $service_id = $item['service_id'];
                        $service = Entities\Service::find( $service_id );
                        $quantity = isset( $item['quantity'] ) ? max( 1, min( (int) $item['quantity'], $max_quantity ) ) : 1;
                        $services_count = $service->withSubServices() ? count( $service->getSubServices() ) : 1;
                        for ( $q = 0; $q < $quantity; $q++ ) {
                            $slots_list = array();
                            for ( $i = 0; $i < $services_count; $i++ ) {
                                $slots_list[] = $slots[ $slot_index + $i ];
                            }
                            $slot = $slots_list[0];

                            if ( $service->withSubServices() && get_option( 'bookly_combined_price_method' ) !== 'nested' ) {
                                $price = $service->getPrice();
                            } else {
                                $price = 0;
                                foreach ( $slots_list as $_slot ) {
                                    list( $service_id, $staff_id, $date, $location_id ) = $_slot;
                                    $time = substr( $date, 11 );
                                    $staff_service = new Entities\StaffService();
                                    $location_id = BooklyLib\Proxy\Locations::prepareStaffLocationId( $location_id, $staff_id ) ?: null;
                                    $staff_service->loadBy( compact( 'staff_id', 'service_id', 'location_id' ) );
                                    $price += BooklyLib\Proxy\SpecialHours::adjustPrice( $staff_service->getPrice(), $staff_id, $service_id, $location_id, $time, date( 'w', strtotime( $date ) ) + 1 );
                                }
                            }

                            $option['slots'][] = array(
                                'price' => $price,
                                'datetime' => isset( $_schedule['all_day_service_time'] ) ? BooklyLib\Utils\DateTime::formatDate( $slot[2] ) . ' ' . $_schedule['all_day_service_time'] : ( $use_time_zone ? BooklyLib\Utils\DateTime::formatDateTime( BooklyLib\Utils\DateTime::applyTimeZone( $slot[2], $time_zone, $time_zone_offset ) ) : BooklyLib\Utils\DateTime::formatDateTime( $slot[2] ) ),
                                'slot' => $slots_list
                            );
                            $slot_index += $services_count;
                        }
                    }
                }
            }
        }
        unset ( $_schedule, $_day );
        $result = array( 'schedule' => $schedule );
        if ( ! self::parameter( 'recurring_schedule' ) && BooklyLib\Config::recurringAppointmentsActive() ) {
            $days = array();
            $staff_timezones = array();
            foreach ( Entities\Staff::query( 'st' )->select( 'id, time_zone' )->whereIn( 'id', $staff_ids )->fetchArray() as $staff ) {
                $staff_timezones[ $staff['id'] ] = $staff['time_zone'];
            }
            foreach ( self::_staffWeeklySchedule( $staff_ids, $staff_timezones ) as $_day => $_schedule ) {
                $start = $_schedule['start_time']->toClientTz();
                $end = $_schedule['end_time']->toClientTz();
                if ( $start->value() < 0 ) {
                    // Previous day
                    $_day = $_day === 1 ? 7 : $_day - 1;
                    $days[ $_day ] = $_day;
                }
                if ( $start->value() < HOUR_IN_SECONDS * 24 && $end->value() > 0 ) {
                    // Current day
                    $days[ $_day ] = $_day;
                }
                if ( $end->value() > HOUR_IN_SECONDS * 24 ) {
                    // Next day
                    $_day = $_day === 7 ? 1 : $_day + 1;
                    $days[ $_day ] = $_day;
                }
            }

            /** @var \WP_Locale $wp_locale */
            global $wp_locale;

            $weekdays = self::_getWeekDays();
            $weekday_abbrev = array_values( $wp_locale->weekday_abbrev );
            $result['days'] = array();
            foreach ( $weekdays as $day_index => $day ) {
                if ( in_array( $day_index + 1, $days, true ) ) {
                    $result['days'][] = array(
                        'value' => $day,
                        'label' => $weekday_abbrev[ $day_index ],
                    );
                }
            }
            $result['weekdays'] = $weekdays;
        }

        wp_send_json_success( $result );
    }

    public static function modernBookingFormSave()
    {
        $request = new Lib\Request();
        if ( $request->isValid() ) {
            try {
                wp_send_json_success( $request->processPayment() );
            } catch ( \Exception $e ) {
            }
        }

        wp_send_json_error( $request->getError() );
    }

    /**
     * When payment window closed by client
     * @return void
     */
    public static function retrieveOrderStatus()
    {
        wp_send_json_success( self::retrieveOrderResult() );
    }

    /**
     * Endpoint for payment systems window.
     *
     * @return void
     */
    public static function checkoutResponse()
    {
        $request = \Bookly\Frontend\Modules\Payment\Request::getInstance();
        try {
            $gateway = $request->getGateway();
            if ( $gateway instanceof BooklyLib\Payment\NullGateway ) {
                // Get here after closing payment modal window
                // NullGateway means that until then the webhook
                // that caused $gateway->failed() worked and there is no trace of the payment system left
                // hence we send status = Gateway::STATUS_FAILED
                $status = Gateway::STATUS_FAILED;
                $data = array(
                    'status' => $status,
                    'data' => Lib\PaymentFlow::getBookingResultFromOrder( $status, $request->get( 'bookly_order' ) ),
                );
            } else {
                $data = self::retrieveOrderResult();
            }
        } catch ( \Exception $e ) {
            $data = array(
                'status' => Gateway::STATUS_FAILED,
                'data' => array(
                    'bookly_order' => $request->get( 'bookly_order' ),
                    'info' => $e->getMessage(),
                ),
            );
        }
        if ( $request->getGateway()->getPayment()->getParentId() ) {
            print '<script>window.opener.BooklyCheckoutForm.setBookingResult( \'' . $data['status'] . '\', ' . json_encode( $data['data'] ) . ' );</script>';
        } else {
            print '<script>window.opener.BooklyModernBookingForm.setBookingResult( \'' . $data['status'] . '\', ' . json_encode( $data['data'] ) . ' );</script>';
        }
        exit;
    }

    /**
     * Get staff schedule for modern form calendar
     *
     * @return void
     */
    public static function modernBookingFormGetCalendarSchedule()
    {
        $holidays = array();
        $parsed_month = array();
        $filters = self::parameter( 'filters' );

        $month = (int) self::parameter( 'month' );
        $year = (int) self::parameter( 'year' );


        $last_date = date_create()->modify( ( BooklyLib\Config::getMaximumAvailableDaysForBooking() - 1 ) . ' days' );
        $last_month = $last_date->format( 'n' ) - 1;
        $last_year = (int) $last_date->format( 'Y' );

        $service_ids = isset( $filters['services'] ) ? $filters['services'] : array();
        $staff_ids = isset( $filters['staff'] ) ? $filters['staff'] : array();

        // Minimum time prior booking
        $min_time_prior_booking = null;
        if ( $service_ids ) {
            foreach ( $service_ids as $service_id ) {
                $service_min_time = ProLib\Config::getMinimumTimePriorBooking( $service_id );
                $min_time_prior_booking = $min_time_prior_booking === null ? $service_min_time : min( $min_time_prior_booking, $service_min_time );
            }
        } else {
            $min_time_prior_booking = ProLib\Config::getMinimumTimePriorBooking();
        }

        $first_month = $month;
        $first_year = $year;
        do {
            $parsed_month[] = ( $month - 1 ) . '-' . $year;

            $has_schedule = self::_getSchedule( $month, $year, $min_time_prior_booking, $staff_ids, $service_ids, $holidays );

            $year += $month > 11 ? 1 : 0;
            $month = ( $month % 12 ) + 1;
        } while ( ! $has_schedule && ( $year < $last_year || ( $year === $last_year && $month <= $last_month ) ) );

        // Add holidays to min time prior booking days
        if ( $min_time_prior_booking ) {
            $start_date = date_create( $first_year . '-' . ( $first_month - 1 ) . '-1' )->modify( '-7 days' );
            $end_date = date_create( $year . '-' . ( $month - 1 ) . '-1' )->modify( '1 month 7 days' )->modify( $min_time_prior_booking . ' seconds' );

            $min_date = BooklyLib\Slots\DatePoint::now()->toTz( 'UTC' )->modify( $min_time_prior_booking )->modify( 'midnight' )->value();
            do {
                if ( $start_date < $min_date ) {
                    $formatted_date = $start_date->format( 'Y-m-d' );
                    if ( ! in_array( $formatted_date, $holidays, true ) ) {
                        $holidays[] = $formatted_date;
                    }
                }
                $start_date->modify( '1 day' );
            } while ( $start_date < $end_date );
        }

        wp_send_json_success( array( 'parsed_months' => $parsed_month, 'holidays' => $holidays ) );
    }

    private static function _getSchedule( $month, $year, $min_time_prior_booking, $staff_ids, $service_ids, &$holidays )
    {
        $staff_holidays = array();
        $service_holidays = array();

        $start_date = date_create( $year . '-' . $month . '-1' )->modify( '-7 days' );
        $end_date = date_create( $year . '-' . $month . '-1' )->modify( '1 month 8 days' );

        if ( $min_time_prior_booking ) {
            $end_date->modify( $min_time_prior_booking . ' seconds' );
        }

        if ( self::parameter( 'available_dates' ) === 'with_slots' ) {
            $current_date = clone( $start_date );
            do {
                $service_holidays[] = $current_date->format( 'Y-m-d' );
                $current_date->modify( '1 day' );
            } while ( $current_date < $end_date );
            // A day is free of the holidays list as soon as ANY service has a slot on
            // it, so every scan only shrinks the list and the order of the scans does
            // not change the result. For services shorter than a day the days when no
            // staff member works and the days in the past cannot be freed by any scan:
            // once only such days remain, the sub-day services left cannot change the
            // result and their scans are skipped. On typical setups the first wide
            // services cover all working days and the tail of the scans is dropped
            // entirely. Services lasting a day or longer are exempt: their day-grained
            // slots are keyed by the start day of the booking, which the schedule
            // arithmetic cannot predict (a multi-day booking may start in the past) -
            // they are cheap day-level searches and run unconditionally, first.
            $unreachable_days = self::staffClosedDays( $staff_ids, $start_date, $end_date );
            $today = BooklyLib\Slots\DatePoint::now()->toClientTz()->format( 'Y-m-d' );
            $sub_day_service_ids = array();
            $day_service_ids = array();
            foreach ( $service_ids as $service_id ) {
                $service = BooklyLib\Entities\Service::find( $service_id );
                $day_or_longer = $service && $service->getDuration() >= DAY_IN_SECONDS;
                if ( $service && ! $day_or_longer && $service->withSubServices() ) {
                    foreach ( $service->getSubServices() as $sub_service ) {
                        if ( $sub_service->getDuration() >= DAY_IN_SECONDS ) {
                            $day_or_longer = true;
                            break;
                        }
                    }
                }
                if ( $day_or_longer ) {
                    $day_service_ids[] = $service_id;
                } else {
                    $sub_day_service_ids[] = $service_id;
                }
            }
            foreach ( array_merge( $day_service_ids, $sub_day_service_ids ) as $service_id ) {
                if ( ! in_array( $service_id, $day_service_ids ) ) {
                    $reachable = false;
                    foreach ( $service_holidays as $day ) {
                        if ( $day >= $today && ! isset( $unreachable_days[ $day ] ) ) {
                            $reachable = true;
                            break;
                        }
                    }
                    if ( ! $reachable ) {
                        break;
                    }
                }
                $service = BooklyLib\Entities\Service::find( $service_id );
                $nop = 1;
                if ( BooklyLib\Config::groupBookingActive() ) {
                    if ( count( $staff_ids ) > 1 ) {
                        $nop = $service->getCapacityMin();
                    } elseif ( count( $staff_ids ) == 1 ) {
                        $staff_service = new Entities\StaffService();
                        if ( $staff_service->loadBy( array( 'service_id' => $service_id, 'staff_id' => $staff_ids[0], 'location_id' => null ) ) ) {
                            $nop = $staff_service->getCapacityMin();
                        }
                    }
                }

                $chain_item = new BooklyLib\ChainItem();
                $chain_item
                    ->setStaffIds( $staff_ids )
                    ->setServiceId( $service_id )
                    ->setNumberOfPersons( $nop )
                    ->setQuantity( 1 )
                    ->setLocationId( null )
                    ->setUnits( $service->getUnitsMin() )
                    ->setExtras( array() );

                $chain = new BooklyLib\Chain();
                $chain->add( $chain_item );

                $userData = new BooklyLib\UserBookingData( null );
                if ( BooklyLib\Config::useClientTimeZone() ) {
                    $userData
                        ->setTimeZone( self::parameter( 'time_zone' ) ?: null )
                        ->setTimeZoneOffset( self::parameter( 'time_zone_offset' ) ?: null )
                        ->applyTimeZone();
                }
                $userData->resetChain();
                $userData->chain = $chain;
                $userData->setDays( array( 1, 2, 3, 4, 5, 6, 7 ) );
                $finder_end_date = new BooklyLib\Slots\DatePoint( $end_date );
                // Only the group keys (the days that have slots) are used below, so one
                // slot per day is enough - no need to collect every slot of the period.
                $finder = new BooklyLib\Slots\Finder( $userData, null, function( BooklyLib\Slots\DatePoint $client_dp, $groups_count, $slots_count ) use ( $finder_end_date ) {
                    return (int) $client_dp->gte( $finder_end_date );
                }, null, array(), false, true );
                $finder->prepare();
                $finder->client_start_dp = new BooklyLib\Slots\DatePoint( $start_date );
                $finder->client_end_dp = $finder_end_date;
                $finder->load();
                $service_holidays = array_diff( $service_holidays, array_keys( $finder->getSlots() ), array( $end_date->format( 'Y-m-d' ) ) );
            }
        } else {
            if ( $staff_ids ) {
                // Holidays
                $query = Entities\Holiday::query( 'h' )
                    ->select( 'DISTINCT(DATE_FORMAT(h.date, "%%m-%%d")) AS short_date' )
                    ->whereIn( 'h.staff_id', $staff_ids )
                    ->whereRaw( 'h.repeat_event = 1 OR (h.date >= %s AND h.date <= %s)', array( $start_date->format( 'Y-m-d' ), $end_date->format( 'Y-m-d' ) ) )
                    ->groupBy( 'short_date' )
                    ->havingRaw( 'COUNT(DISTINCT(staff_id)) >= %d', array( count( $staff_ids ) ) );
                $staff_holidays = $query->fetchArray();

                $staff_holidays = array_map( function( $h ) { return $h['short_date']; }, $staff_holidays );

                $staff_timezones = array();
                foreach ( Entities\Staff::query( 'st' )->select( 'id, time_zone' )->whereIn( 'id', $staff_ids )->fetchArray() as $staff ) {
                    $staff_timezones[ $staff['id'] ] = $staff['time_zone'];
                }

                $wp_tz_offset = get_option( 'gmt_offset' ) * HOUR_IN_SECONDS;

                // Calculate weekly schedule
                $weekly_schedule = self::_staffWeeklySchedule( $staff_ids, $staff_timezones );

                // Special days
                $special_days = array();
                foreach ( BooklyLib\Proxy\SpecialDays::getSchedule( $staff_ids, $start_date, $end_date ) ?: array() as $special_day ) {
                    $start = BooklyLib\Slots\TimePoint::fromStr( $special_day['start_time'] );
                    $end = BooklyLib\Slots\TimePoint::fromStr( $special_day['end_time'] );
                    if ( isset( $staff_timezones[ $special_day['staff_id'] ] ) ) {
                        $staff_tz_offset = BooklyLib\Utils\DateTime::timeZoneOffset( $staff_timezones[ $special_day['staff_id'] ] );
                        $start = $start->toTz( $staff_tz_offset, $wp_tz_offset );
                        $end = $end->toTz( $staff_tz_offset, $wp_tz_offset );
                    }
                    if ( ! isset( $special_days[ $special_day['date'] ]['start_time'] ) || $start->lt( $special_days[ $special_day['date'] ]['start_time'] ) ) {
                        $special_days[ $special_day['date'] ]['start_time'] = $start;
                    }
                    if ( ! isset( $special_days[ $special_day['date'] ]['end_time'] ) || $end->gt( $special_days[ $special_day['date'] ]['end_time'] ) ) {
                        $special_days[ $special_day['date'] ]['end_time'] = $end;
                    }
                }

                $current_date = clone( $start_date );
                $working_days = array();
                do {
                    $month_day = $current_date->format( 'm-d' );
                    $day = $current_date->format( 'Y-m-d' );
                    if ( ! in_array( $month_day, $staff_holidays, true ) ) {
                        $weekday = 1 + (int) $current_date->format( 'w' );
                        if ( isset( $weekly_schedule[ $weekday ] ) ) {
                            $working_days = array_merge( $working_days, self::_prepareDates( $current_date, $weekly_schedule[ $weekday ]['start_time'], $weekly_schedule[ $weekday ]['end_time'] ) );
                        }
                    }
                    if ( isset( $special_days[ $day ] ) ) {
                        $working_days = array_merge( $working_days, self::_prepareDates( $current_date, $special_days[ $day ]['start_time'], $special_days[ $day ]['end_time'] ) );
                    }
                    $current_date->modify( '1 day' );
                } while ( $current_date < $end_date );

                $current_date = clone( $start_date );
                do {
                    $formatted_date = $current_date->format( 'Y-m-d' );
                    if ( ! in_array( $formatted_date, $working_days, true ) ) {
                        $staff_holidays[] = $formatted_date;
                    }
                    $current_date->modify( '1 day' );
                } while ( $current_date < $end_date );
            }

            if ( $service_ids && BooklyLib\Config::serviceScheduleActive() ) {
                // Calculate weekly schedule
                $weekly_schedule = BooklyLib\Proxy\ServiceSchedule::getWeeklySchedule( $service_ids );

                // Special days
                $special_days = array();
                foreach ( BooklyLib\Proxy\SpecialDays::getServiceSchedule( $service_ids, $start_date, $end_date ) ?: array() as $special_day ) {
                    $start = BooklyLib\Slots\TimePoint::fromStr( $special_day['start_time'] );
                    $end = BooklyLib\Slots\TimePoint::fromStr( $special_day['end_time'] );
                    if ( ! isset( $special_days[ $special_day['date'] ]['start_time'] ) || $start->lt( $special_days[ $special_day['date'] ]['start_time'] ) ) {
                        $special_days[ $special_day['date'] ]['start_time'] = $start;
                    }
                    if ( ! isset( $special_days[ $special_day['date'] ]['end_time'] ) || $end->gt( $special_days[ $special_day['date'] ]['end_time'] ) ) {
                        $special_days[ $special_day['date'] ]['end_time'] = $end;
                    }
                }

                $current_date = clone( $start_date );
                $working_days = array();
                do {
                    $month_day = $current_date->format( 'm-d' );
                    $day = $current_date->format( 'Y-m-d' );
                    if ( ! in_array( $month_day, $service_holidays, true ) ) {
                        $weekday = 1 + (int) $current_date->format( 'w' );
                        if ( isset( $weekly_schedule[ $weekday ] ) ) {
                            $working_days = array_merge( $working_days, self::_prepareDates( $current_date, $weekly_schedule[ $weekday ]['start_time'], $weekly_schedule[ $weekday ]['end_time'] ) );
                        }
                    }
                    if ( isset( $special_days[ $day ] ) ) {
                        $working_days = array_merge( $working_days, self::_prepareDates( $current_date, $special_days[ $day ]['start_time'], $special_days[ $day ]['end_time'] ) );
                    }
                    $current_date->modify( '1 day' );
                } while ( $current_date < $end_date );

                $current_date = clone( $start_date );
                do {
                    $formatted_date = $current_date->format( 'Y-m-d' );
                    if ( ! in_array( $formatted_date, $working_days, true ) ) {
                        $service_holidays[] = $formatted_date;
                    }
                    $current_date->modify( '1 day' );
                } while ( $current_date < $end_date );
            }
        }

        $holidays = array_merge( $holidays, $staff_holidays, $service_holidays );

        // Check if schedules has working day
        $current_date = max( date_create( $year . '-' . $month . '-1' ), date_create()->modify( $min_time_prior_booking . ' seconds' )->modify( 'midnight' ) );
        $end_month_date = date_create( $year . '-' . $month . '-1' )->modify( 'last day of this month' );
        if ( $current_date < $end_month_date ) {
            do {
                $formatted_date = $current_date->format( 'Y-m-d' );
                if ( ! in_array( $formatted_date, $staff_holidays, true ) && ! in_array( $formatted_date, $service_holidays, true ) ) {
                    return true;
                }
                $current_date->modify( '1 day' );
            } while ( $current_date < $end_month_date );
        }

        return false;
    }

    /**
     * Get the days of the period when no staff member works according to the
     * schedules: all-staff holidays, weekly schedule and special days. On such days
     * no service can have a slot. Mirrors the schedule arithmetic of the branch
     * that shows all working dates; _prepareDates takes care of the schedules
     * crossing midnight and of the client timezone shifts.
     *
     * @param array $staff_ids
     * @param \DateTime $start_date
     * @param \DateTime $end_date
     * @return array 'Y-m-d' => true
     */
    protected static function staffClosedDays( array $staff_ids, $start_date, $end_date )
    {
        if ( ! $staff_ids ) {
            return array();
        }

        $staff_holidays = Entities\Holiday::query( 'h' )
            ->select( 'DISTINCT(DATE_FORMAT(h.date, "%%m-%%d")) AS short_date' )
            ->whereIn( 'h.staff_id', $staff_ids )
            ->whereRaw( 'h.repeat_event = 1 OR (h.date >= %s AND h.date <= %s)', array( $start_date->format( 'Y-m-d' ), $end_date->format( 'Y-m-d' ) ) )
            ->groupBy( 'short_date' )
            ->havingRaw( 'COUNT(DISTINCT(staff_id)) >= %d', array( count( $staff_ids ) ) )
            ->fetchArray();
        $staff_holidays = array_map( function( $h ) { return $h['short_date']; }, $staff_holidays );

        $staff_timezones = array();
        foreach ( Entities\Staff::query( 'st' )->select( 'id, time_zone' )->whereIn( 'id', $staff_ids )->fetchArray() as $staff ) {
            $staff_timezones[ $staff['id'] ] = $staff['time_zone'];
        }
        $weekly_schedule = self::_staffWeeklySchedule( $staff_ids, $staff_timezones );

        $wp_tz_offset = get_option( 'gmt_offset' ) * HOUR_IN_SECONDS;
        $special_days = array();
        foreach ( BooklyLib\Proxy\SpecialDays::getSchedule( $staff_ids, $start_date, $end_date ) ?: array() as $special_day ) {
            $start = BooklyLib\Slots\TimePoint::fromStr( $special_day['start_time'] );
            $end = BooklyLib\Slots\TimePoint::fromStr( $special_day['end_time'] );
            if ( isset( $staff_timezones[ $special_day['staff_id'] ] ) ) {
                $staff_tz_offset = BooklyLib\Utils\DateTime::timeZoneOffset( $staff_timezones[ $special_day['staff_id'] ] );
                $start = $start->toTz( $staff_tz_offset, $wp_tz_offset );
                $end = $end->toTz( $staff_tz_offset, $wp_tz_offset );
            }
            if ( ! isset( $special_days[ $special_day['date'] ]['start_time'] ) || $start->lt( $special_days[ $special_day['date'] ]['start_time'] ) ) {
                $special_days[ $special_day['date'] ]['start_time'] = $start;
            }
            if ( ! isset( $special_days[ $special_day['date'] ]['end_time'] ) || $end->gt( $special_days[ $special_day['date'] ]['end_time'] ) ) {
                $special_days[ $special_day['date'] ]['end_time'] = $end;
            }
        }

        $working_days = array();
        $current_date = clone( $start_date );
        do {
            $month_day = $current_date->format( 'm-d' );
            $day = $current_date->format( 'Y-m-d' );
            if ( ! in_array( $month_day, $staff_holidays, true ) ) {
                $weekday = 1 + (int) $current_date->format( 'w' );
                if ( isset( $weekly_schedule[ $weekday ] ) ) {
                    $working_days = array_merge( $working_days, self::_prepareDates( $current_date, $weekly_schedule[ $weekday ]['start_time'], $weekly_schedule[ $weekday ]['end_time'] ) );
                }
            }
            if ( isset( $special_days[ $day ] ) ) {
                $working_days = array_merge( $working_days, self::_prepareDates( $current_date, $special_days[ $day ]['start_time'], $special_days[ $day ]['end_time'] ) );
            }
            $current_date->modify( '1 day' );
        } while ( $current_date < $end_date );

        $closed = array();
        $working_days = array_flip( $working_days );
        $current_date = clone( $start_date );
        do {
            $day = $current_date->format( 'Y-m-d' );
            if ( ! isset( $working_days[ $day ] ) ) {
                $closed[ $day ] = true;
            }
            $current_date->modify( '1 day' );
        } while ( $current_date < $end_date );

        return $closed;
    }

    private static function _staffWeeklySchedule( $staff_ids, $staff_timezones = array() )
    {
        $weekly_schedule = array();
        $res = Entities\StaffScheduleItem::query()
            ->select( 'r.day_index, r.start_time, r.end_time, r.staff_id' )
            ->whereIn( 'r.staff_id', $staff_ids )
            ->whereNot( 'r.start_time', null )
            ->groupBy( 'r.staff_id' )
            ->groupBy( 'day_index' )
            ->fetchArray();

        $wp_tz_offset = get_option( 'gmt_offset' ) * HOUR_IN_SECONDS;

        foreach ( $res as $row ) {
            $start = BooklyLib\Slots\TimePoint::fromStr( $row['start_time'] );
            $end = BooklyLib\Slots\TimePoint::fromStr( $row['end_time'] );
            if ( isset( $staff_timezones[ $row['staff_id'] ] ) ) {
                $staff_tz_offset = BooklyLib\Utils\DateTime::timeZoneOffset( $staff_timezones[ $row['staff_id'] ] );
                $start = $start->toTz( $staff_tz_offset, $wp_tz_offset );
                $end = $end->toTz( $staff_tz_offset, $wp_tz_offset );
            }
            if ( ! isset( $weekly_schedule[ $row['day_index'] ]['start_time'] ) || $start->lt( $weekly_schedule[ $row['day_index'] ]['start_time'] ) ) {
                $weekly_schedule[ $row['day_index'] ]['start_time'] = $start;
            }
            if ( ! isset( $weekly_schedule[ $row['day_index'] ]['end_time'] ) || $end->gt( $weekly_schedule[ $row['day_index'] ]['end_time'] ) ) {
                $weekly_schedule[ $row['day_index'] ]['end_time'] = $end;
            }
        }

        return $weekly_schedule;
    }

    /**
     * @param \DateTime $date
     * @param BooklyLib\Slots\TimePoint $start_time
     * @param BooklyLib\Slots\TimePoint $end_time
     * @return array
     */
    protected static function _prepareDates( $date, $start_time, $end_time )
    {
        // Convert to client time zone.
        $start = $start_time->toClientTz();
        $end = $end_time->toClientTz();

        $result = array();
        if ( $start->value() < 0 ) {
            $clone_date = clone( $date );
            $result[] = $clone_date->modify( '-1 day' )->format( 'Y-m-d' );
        }
        if ( $start->value() < HOUR_IN_SECONDS * 24 && $end->value() > 0 ) {
            $result[] = $date->format( 'Y-m-d' );
        }
        if ( $end->value() > HOUR_IN_SECONDS * 24 ) {
            $clone_date = clone( $date );
            $result[] = $clone_date->modify( '1 day' )->format( 'Y-m-d' );
        }

        return $result;
    }

    /**
     * @return string[]
     */
    public static function _getWeekDays()
    {
        $start_of_week = get_option( 'start_of_week' );
        $weekdays = array( 'sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat' );

        // Sort days considering start_of_week;
        uksort( $weekdays, function( $a, $b ) use ( $start_of_week ) {
            $a -= $start_of_week;
            $b -= $start_of_week;
            if ( $a < 0 ) {
                $a += 7;
            }
            if ( $b < 0 ) {
                $b += 7;
            }

            return $a - $b;
        } );

        return $weekdays;
    }

    /**
     * @return array
     */
    protected static function retrieveOrderResult()
    {
        $request = \Bookly\Frontend\Modules\Payment\Request::getInstance();
        $gateway = $request->getGateway();
        if ( $request->get( 'bookly_event' ) === Gateway::EVENT_CANCEL ) {
            $status = Gateway::STATUS_FAILED;
            $gateway->fail();
        } else {
            $status = $gateway->retrieve();
        }

        return array(
            'status' => $status,
            'data' => Lib\PaymentFlow::getBookingResultFromOrder( $status, $request->get( 'bookly_order' ) ),
        );
    }

    /**
     * Override parent method to exclude actions from CSRF token verification.
     *
     * @param string $action
     * @return bool
     */
    protected static function csrfTokenValid( $action = null )
    {
        return true;
    }
}