<?php

namespace InstagramFeed\Abilities;

use WP_Error;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * WP_Error factories shared by every Instagram Feed ability.
 *
 * Every error carries an HTTP status in `data.status` so the core Abilities
 * REST controller and the MCP adapter surface the right code.
 *
 * @since INSTA_FEED_PRO_SINCE
 */
class SBI_Ability_Response
{
	public static function forbidden()
	{
		return new WP_Error(
			'sbi_forbidden',
			__('You do not have permission to manage Instagram Feed settings.', 'instagram-feed'),
			array('status' => 403)
		);
	}

	public static function writes_disabled()
	{
		return new WP_Error(
			'sbi_writes_disabled',
			__(
				'AI write access is disabled. Enable "MCP Write Access" under Instagram Feed → Settings → General.', // phpcs:ignore Generic.Files.LineLength.TooLong -- single literal for make-pot
				'instagram-feed'
			),
			array('status' => 403)
		);
	}

	public static function invalid_feed_id()
	{
		return new WP_Error(
			'sbi_invalid_feed_id',
			__('A valid feed_id is required.', 'instagram-feed'),
			array('status' => 400)
		);
	}

	public static function feed_not_found($feed_id)
	{
		return new WP_Error(
			'sbi_feed_not_found',
			sprintf(
				/* translators: %d: feed id */
				__('Feed %d was not found.', 'instagram-feed'),
				(int) $feed_id
			),
			array('status' => 404)
		);
	}
}
