<?php

defined( 'ABSPATH' ) || exit;

require_once dirname( __FILE__ ) . '/mts-overrides.php';
