/**
 * Swipe View — Reels Viewer (SMASH-1851)
 *
 * Hardened build of the "Quick Scroll" spike (`.pitch/quickscroll-reels-viewer/SPIKE.md`)
 * against the normative Swipe View experience spec:
 *   docs/technical-designs/swipe-view-experience-spec.md (AgDR-0087)
 *
 * A TikTok-style full-viewport vertical Reels viewer that opens on top of the
 * existing feed instead of the standard Lightbox2 modal. Gated by the
 * "Enable Swipe View for Reels" global setting (Pro-only, default ON —
 * see sbi_quickscroll_enqueue() in inc/if-functions.php).
 *
 * Spec sections implemented here:
 *   §3   Interaction model (nav thresholds, cooldowns, reduced-motion)
 *   §4   Playback (muted autoplay, mute persistence, loop, autoplay-blocked fallback)
 *   §5   Dead-media fallback chain (native video -> IG Reel embed -> poster+link)
 *   §6   Chrome (counter, close, mute, play/pause, progress, caption/attribution)
 *   §7   Accessibility (dialog semantics, focus trap+restore, live counter, scroll lock)
 *   §8   Analytics event contract (swipeview_* — thin seam, see emitAnalytics())
 *   §12  Security (text-not-markup, identifier validation, scheme checks)
 *
 * Explicitly NOT implemented here (see SMASH-1851 report for the full list):
 *   - §4.4 exactly-three-slot windowing / neighbour preload policy — this build
 *     keeps the spike's "render every eligible post, animate the track" model and
 *     only lazily instantiates a slide's media on first activation. Off-screen
 *     slides are paused, never destroyed, which satisfies that half of §4.4, but
 *     the fixed 3-slot recycling model itself is a bigger re-architecture than
 *     this ticket's four blockers + spec-parity list called for.
 *   - §6.1 loading affordance while a slide hasn't reported `playing` — the spec's
 *     own conformance table (§11) marks this "not implemented in the reference
 *     either; first implementation is MM 1", so it is deferred, not skipped.
 *   - The `swipeview_*` analytics events are emitted through emitAnalytics() but
 *     have no real transport yet (SMASH-1852 owns the endpoint).
 */
(function ($) {
	'use strict';

	// ── State ───────────────────────────────────────────────────────────────
	var $body, $container, $track, $gestures, $frameChrome, $top, $flash, $playState, $live,
		$navPrev, $navNext, $muteBtn, $muteLabel, $viewPill, $progressBar, $progressFill, $coach;
	// The rail is SESSION-LEVEL — ONE column built once, not one per slide. See
	// buildRail() for why, and updateRail() for what changes on a slide change.
	// Held as four handles rather than re-queried, because updateRail() runs on
	// every navigation and these nodes never change identity.
	var $railCol, $railLike, $railComment, $railView;
	// The pause glyph's dissolve is driven by a class the CSS reads for exactly
	// one 100ms window after unpausing, so the timer that removes it is state.
	var flashOffTimer = null;
	// Rule 1.7's "Tap to unmute" label: two timers per slide (show at +350ms,
	// retract at 4500ms), replayed on each activation while still in the
	// refused-muted state.
	var soundHintInTimer = null;
	var soundHintOutTimer = null;
	// Rule 1.9's first-run coach overlay: one arm timer (dismiss listeners go
	// live 350ms after open) and one auto-dismiss timer.
	var coachArmTimer = null;
	var coachOffTimer = null;
	var coachArmed = false;
	var posts = [];       // Normalised, eligible posts for the current open() session.
	var slides = [];       // Parallel array: { post, $article, $stage, tier, inst, watchdog, playingSeen, terminalReported }
	var currentIndex = 0;
	var transitioning = false;
	var navLocked = false;
	// §4.2 revision (SMASH-1851, mirrors SMASH-1853 "sound-on-open"): records
	// the user's last EXPLICIT choice, defaulting to "attempt unmuted" since
	// open() and every swipe are gesture contexts where the browser permits
	// it. The ONLY writer of `true` is an explicit mute action (toggleMute /
	// the mute button) — a rejected attemptPlay() retry NEVER writes here
	// (see attemptPlay()), so the next activation always retries unmuted.
	var userMuted = false;
	// Task B: armed by a rejected UNMUTED attemptPlay() (see
	// handleAdapterEvent's autoplay_blocked branch). Rendered ANDed with the
	// active slide's REAL muted state (and its mute capability) in
	// updateMuteChrome() — see that function's docblock for why the flag
	// alone is not sufficient.
	var unmuteSucceeded = false;
	var openerEl = null;          // Explicit focus-restoration target (§7.1) — never inferred from document.activeElement.
	var touchStartY = null;
	var touchStartTime = 0;
	// ── Thumb-follow drag state (SMASH-1978) ────────────────────────────────
	// `dragging` only becomes true once the finger clears DRAG_START_PX, so a
	// tap (which reports a stray 1-2px touchmove on real hardware) never starts
	// a drag and never calls preventDefault — that is what keeps
	// tap-to-play/pause working on this same layer.
	var dragging = false;
	// The live TRACK offset in px, sign-aligned with the FINGER: positive means
	// the finger moved down and the track moved down with it. Note this is the
	// OPPOSITE sign to the legacy flick's `dy` (which is up-positive, see
	// onTouchEnd) — the two are deliberately named differently because mixing
	// them up is a silent direction inversion.
	var dragDeltaPx = 0;
	// The index the drag started from. Held separately from currentIndex so the
	// base offset the delta composes over cannot move under the drag.
	var dragBaseIndex = 0;
	// ── Tap suppression (2026-08-27, mirrors SMASH-1853's suppressTapRef) ────
	// A gesture that MOVED is not a tap. The gesture layer carries a real click
	// handler for tap-to-play/pause, and a touch sequence can still synthesise a
	// click after a drag — engines disagree about whether preventDefault() on
	// touchmove suppresses it — so without this every swipe would also toggle
	// playback.
	//
	// Written by resetDrag() and ONLY there, which is the point: four paths end a
	// gesture here (a release, a cancel, a second finger aborting a pinch, and
	// close() disarming a gesture still in flight), and SMASH-1853 shipped this
	// exact defect by capturing the flag at the call sites and missing the
	// pinch-abort. Making the capture part of ENDING a drag is what stops a fifth
	// path from reintroducing it.
	//
	// It tracks `dragging` — "the finger cleared the deadzone" — rather than "a
	// gesture ended", and that is load-bearing in the other direction too:
	// onGestureClick() is the only reader and it clears the flag, so arming it
	// for a contact that never became a drag would leave it set with no click
	// coming, and swallow the visitor's NEXT genuine tap instead.
	var suppressTap = false;
	// ── Rule 1.7's one seam ─────────────────────────────────────────────────
	// TRUE once this session has had an unmuted play() genuinely REFUSED by the
	// browser. It is the whole gate on the "Tap to unmute" label: the design's
	// affordance exists because Aman's build opens muted unconditionally, we keep
	// §4.1's unmuted attempt (Asmita's ratified 2026-08-14 call), so the label
	// becomes the FAILURE arm rather than the happy path.
	//
	// Distinct from `userMuted` on purpose. Three states have to be told apart:
	//   refused-muted  -> paint white AND slide the label out, per slide
	//   chosen-muted   -> paint white, NO label (respect the choice)
	//   unmuted        -> paint dark, no label, and never label again
	// A single boolean cannot express that, and conflating the first two is how a
	// visitor who deliberately muted gets nagged on every swipe.
	var autoplayRefused = false;
	// Last string handed to the play-state live region, so an unchanged value is
	// never re-written. See announcePlayState() — this is not a micro-optimisation.
	var lastPlayStateText = null;
	// Rule 1.16's wheel tuning, ported from the reference: an ACCUMULATOR plus a
	// gesture-end gap, not a per-event threshold. See onWheel().
	var wheelAcc = 0;
	var wheelLastAt = 0;
	var wheelFiredAt = 0;
	var wheelLock = false;
	var pollTimer = null;
	var slidesViewed = null;      // Set of indices visited this session, for swipeview_closed's slides_viewed.
	var suppressEmbedTier = false; // Set per-open() when the feed is GDPR-flagged and consent isn't provable (see openFromFeed()).
	var lastAnalyticsAt = {};      // event name -> timestamp, for the §8 "one event per 250ms per type" throttle.

	// ── Constants (values are normative — see the experience spec, not tuned here) ──
	var TRANSITION_MS = 320;        // §3.2
	// ── Wheel tuning (rule 1.16 — adopted from the reference) ───────────────
	// The old shape fired on any single event whose |deltaY| cleared 25, then
	// locked for 550ms. That reads a trackpad's inertia tail as fresh intent: one
	// flick emits a long decaying burst of events, several of which clear any
	// per-event threshold, so a flick could skip slides once the lock expired
	// mid-tail.
	//
	// The replacement is the reference's, and the three numbers work together:
	// deltas ACCUMULATE, the accumulator RESETS when the gap between events
	// exceeds WHEEL_GAP_MS (that gap is what "the gesture ended" actually looks
	// like), one slide fires when the accumulator clears WHEEL_THRESHOLD, and
	// after firing nothing else fires until BOTH a real gap has been seen AND
	// WHEEL_MIN_INTERVAL_MS has passed. So a single flick moves exactly one
	// slide however long its tail is, and a deliberate second scroll still moves
	// immediately once the finger lifts and returns.
	var WHEEL_THRESHOLD = 40;
	var WHEEL_GAP_MS = 160;
	var WHEEL_MIN_INTERVAL_MS = 450;
	var SWIPE_THRESHOLD_PX = 60;    // §3.1 (provisional) — now the FLICK accelerator's distance, see onTouchEnd.
	var SWIPE_MAX_DURATION_MS = 600; // Not spec-mandated; kept from the spike as a slow-drag-vs-swipe filter.
	// SMASH-1978: the finger must travel this far before the track starts
	// following. Small enough to feel immediate, large enough that a tap's
	// hardware jitter never registers as a drag (and so never preventDefaults
	// the tap-to-play/pause gesture bound to this same layer).
	var DRAG_START_PX = 6;
	// SMASH-1978 area rule: on release, advance only if the incoming slide holds
	// the MAJORITY of the viewport, i.e. the track moved more than half a slide.
	// Expressed as a fraction so the rule reads as the area statement it is
	// rather than as a pixel threshold.
	var DRAG_SNAP_AREA_FRACTION = 0.5;
	var NAV_COOLDOWN_MS = 420;      // §3.1 (provisional) — applies across ALL input sources, separate from TRANSITION_MS.
	var START_TIMEOUT_MS = 4000;    // §5.2 start watchdog.
	var CHROME_POLL_MS = 250;       // §6.1 "refreshed at least every 250ms".
	var ANALYTICS_THROTTLE_MS = 250; // §8.
	// ── Pause glyph (rule 1.10) ─────────────────────────────────────────────
	// The glyph is now shown for AS LONG AS the slide is paused, so there is no
	// lifetime timer for the visible state — only for the dissolve. MUST match
	// the sbiQsFlashOut keyframe duration in css/sbi-quickscroll.css: the
	// animation paints the dissolve and this timer removes the class that runs
	// it, so a mismatch either clips the dissolve or leaves a transparent glyph
	// parked over the frame. A test reads both values and asserts they agree.
	var FLASH_OUT_MS = 100;
	// Glyph render size inside the 84px disc: 84 minus 2 x 22px of padding.
	// Stated here because the flash builder needs it and the padding lives in
	// CSS; a test derives one from the other rather than trusting the pair.
	var FLASH_GLYPH_PX = 40;

	// ── "Tap to unmute" label timing (rule 1.6, measured from the reference) ──
	var MUTE_HINT_IN_MS = 350;
	var MUTE_HINT_OUT_MS = 4500;

	// ── First-run swipe coach (rule 1.9) ────────────────────────────────────
	// Dismiss listeners are armed 350ms AFTER open so the very tap that opened
	// the viewer cannot dismiss the overlay before it has been read; it
	// auto-dismisses at 3200ms regardless.
	var COACH_ARM_MS = 350;
	var COACH_AUTO_MS = 3200;
	// Namespaced per plugin (rule 1.9) — the reference's bare `sc-hint-swipe`
	// would collide with any sibling viewer sharing an origin, and a visitor who
	// has seen TikTok's coach has not seen this one.
	var COACH_STORAGE_KEY = 'sbi-qs-coach-swipe';

	// ── Pull-to-close (rule 1.16) ───────────────────────────────────────────
	// Only from slide 0, only at rest, only downward, and only on release. The
	// reference's measured behaviour is 130px no / 145px yes, i.e. a strict
	// greater-than against 140.
	var PULL_CLOSE_PX = 140;
	// How much of the finger's downward travel the track follows at slide 0. See
	// clampDragDelta() for why this is damped rather than 1:1.
	var PULL_FOLLOW_RATIO = 0.35;

	// ── Sound on open — THE ONE FLAG (rule 1.7) ─────────────────────────────
	// false = §4.1 as ratified 2026-08-14: attempt UNMUTED on activation, and
	// the design's "Tap to unmute" label is the refusal arm.
	// true  = the reference's model: open muted unconditionally, and the label
	// becomes the happy-path affordance it was designed as.
	//
	// This is deliberately a single flag rather than two code paths, because
	// which one is right is an open question for Asmita (log § 5 item 1, Q1 to
	// Aman) and the answer must be one edit. Everything downstream — the initial
	// attempt, the label gate, and whether `swipeview_autoplay_blocked` can fire
	// at all — reads it from here.
	var MUTED_FIRST = false;

	var NO_CAPS = { mute: false, playPause: false, progress: false };
	var FULL_CAPS = { mute: true, playPause: true, progress: true };

	// ── Small helpers ───────────────────────────────────────────────────────
	// Read TRUTHILY, and specifically not `=== false`, which is what shipped and
	// what made this log always-on for every visitor on every customer site.
	//
	// The flag arrives through wp_localize_script (sbi_quickscroll_enqueue() in
	// inc/if-functions.php), and WP_Scripts::localize() casts every scalar to a
	// string before encoding it:
	//
	//     $l10n[$key] = html_entity_decode((string) $value, ENT_QUOTES, 'UTF-8');
	//
	// so PHP `false` becomes "" and PHP `true` becomes "1". The real payload is
	// {"enabled":"1","debug":""} — never a boolean. `"" === false` is false, so
	// the guard never returned and every open, swipe and close wrote console
	// lines on production sites with WP_DEBUG off.
	//
	// A strict comparison against a value the transport cannot deliver fails in
	// the worst direction available: the ONE configuration it was written for
	// (WP_DEBUG off) is the one it never catches, and the symptom only shows up
	// where nobody looks — a visitor's console, not a developer's. `enabled` two
	// hundred lines below has always been read truthily against the same
	// transport, which is why it works; this now matches it.
	//
	// One deliberate consequence: with sbiQuickScroll absent entirely — the
	// body-class activation path, where nothing localizes anything — logging is
	// now silent rather than on. Default-silent is the correct direction for code
	// running on visitors' machines, and a developer on that path can still opt in
	// with `window.sbiQuickScroll = { debug: true }`.
	function log() {
		if (!(window.sbiQuickScroll && window.sbiQuickScroll.debug)) return;
		try { console.log.apply(console, ['[SBI Swipe View]'].concat([].slice.call(arguments))); } catch (e) {}
	}

	function prefersReducedMotion() {
		return !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
	}

	// ── Input-capability probe (unchanged mechanism, new consumers) ─────────
	// `(hover: hover) and (pointer: fine)` — a capability query, NOT a width
	// query. Width is the wrong signal twice over: a narrow desktop window still
	// has a mouse and a keyboard, and a large tablet still has neither. This pair
	// is the standard "there is a mouse-or-trackpad-class pointer here" probe.
	//
	// It used to gate the intro card's copy variant. That card is gone (rule 1.9
	// — Aman's minimalism principle: "I know I added four instructions, so I'm
	// just kind of trying to minimize what we tell them"), and the probe now
	// gates the one hint that survives: the first-run swipe coach shows ONLY on
	// touch, because desktop has visible chevrons and a cursor and needs no swipe
	// instruction. The CSS makes the same distinction with the same query, which
	// is what keeps the JS-resolved coach and the CSS-resolved layout from ever
	// disagreeing about which device they are on.
	function hasKeyboardAffordance() {
		// No matchMedia at all (a very old browser): answer TRUE, i.e. treat it as
		// a pointer device. That is the safe direction for both consumers — the
		// coach overlay is suppressed rather than shown to someone who may have no
		// touchscreen, and the CSS falls back to its own base (touch) layout
		// independently, so a wrong guess here degrades one hint rather than the
		// whole viewer.
		if (!window.matchMedia) return true;
		return !!window.matchMedia('(hover: hover) and (pointer: fine)').matches;
	}

	// ── Intrinsic media size — rule 1.14's fit decision ───────────────────────
	// This function is what survives the letterbox-anchoring subsystem the intro
	// card needed (that whole mechanism went with the card, rule 1.9): where it
	// once measured the black band under contained media so a hint could sit on
	// the painted frame instead of in the letterbox, it now answers the one
	// question rule 1.14 asks — is this source wider or taller than the frame?
	//
	// Threshold is the reference's: strictly wider than 9/16 x 1.04 letterboxes
	// with `contain` over a blurred poster backdrop; anything at or below it
	// (including true 9:16, within the 4% tolerance) fills with `cover` and is
	// cropped. The tolerance is what stops a 1080x1920 clip that reports
	// 1080x1919 from being treated as landscape.
	var FIT_CONTAIN_RATIO = (9 / 16) * 1.04;

	function mediaIntrinsic(node) {
		if (!node) return null;
		var w = node.videoWidth || node.naturalWidth || 0;
		var h = node.videoHeight || node.naturalHeight || 0;
		return (w > 0 && h > 0) ? { w: w, h: h } : null;
	}

	// The `object-fit: contain` bottom band, in px. Reproduces the contain fit
	// exactly: scale to the tighter axis, then the leftover height splits evenly
	// above and below (object-position is left at its 50% 50% default, and the
	// stylesheet never overrides it).

	// Writes the fit decision onto the FRAME as a data attribute, which the
	// stylesheet reads. Two reasons it is an attribute rather than inline style:
	// the value is a discrete state rather than a measurement, and putting it on
	// the frame lets one attribute drive both the media's object-fit and whether
	// the blurred backdrop paints.
	//
	// Re-run rather than computed once, because intrinsic dimensions are not
	// readable until `loadedmetadata` (video) or `load` (poster) — before that
	// mediaIntrinsic() returns nothing and the honest answer is "not yet known",
	// which is `cover`: the common case, and the one that never shows a black
	// band it will later remove.
	function applyFit(slide) {
		if (!slide || !slide.frame) return;
		var node = slide.stage && slide.stage.querySelector('.sbi-qs-video, .sbi-qs-poster');
		var dims = mediaIntrinsic(node);
		if (!dims) { slide.frame.removeAttribute('data-fit'); return; }
		var wider = (dims.w / dims.h) > FIT_CONTAIN_RATIO;
		if (wider) {
			slide.frame.setAttribute('data-fit', 'contain');
		} else {
			slide.frame.removeAttribute('data-fit');
		}
		// The backdrop only earns its compositor pass when it is actually
		// visible, and it is only visible behind contained media.
		if (slide.backdrop) slide.backdrop.style.display = wider ? '' : 'none';
	}

	function isHttpUrl(u) {
		return typeof u === 'string' && /^https?:\/\//i.test(u);
	}

	// Slightly more permissive variant for <video>/<img> src: same-origin relative
	// paths are allowed (mirrors the shared reference implementation's safeMedia()),
	// but any other scheme (javascript:, data:, blob:, etc.) is rejected outright.
	function safeMediaSrc(u) {
		if (typeof u !== 'string' || !u) return '';
		if (/^https?:\/\//i.test(u)) return u;
		return /^[a-z][a-z0-9+.\-]*:/i.test(u) ? '' : u;
	}

	// ── CSS-url guard (rule 1.14's blurred backdrop) ────────────────────────
	// The blurred letterbox backdrop is the one place in this viewer where a
	// post-derived string reaches CSS rather than the DOM, and CSS has its own
	// injection surface: `url(...)` is terminated by a bare `)`, so a poster URL
	// containing one could close the function and append arbitrary declarations
	// to the inline style attribute.
	//
	// safeMediaSrc() is not sufficient by itself — it decides SCHEME, and a
	// perfectly ordinary `https://` URL can still carry `)`, `"`, `'`, a
	// backslash or whitespace. So this is a second, narrower gate applied on top
	// of it, and it REJECTS rather than escapes: a poster is decoration, the
	// fallback (a plain black frame) is already the common Instagram case
	// because most cached rows carry no poster at all, and a rejected URL costs
	// nothing a visitor can see. Escaping would mean trusting our own escaper on
	// every future browser's url() parser.
	//
	// Control characters are excluded too — a newline inside an inline style is
	// its own declaration separator.
	function safeCssUrl(u) {
		var src = safeMediaSrc(u);
		if (!src) return '';
		/* eslint-disable-next-line no-control-regex */
		if (/["'()\\\s]|[\x00-\x1f]/.test(src)) return '';
		return src;
	}

	// Instagram profile URL for a handle. Built from the handle rather than taken
	// from the feed, because the feed emits no profile link — and built with a
	// STRICT allowlist rather than by escaping, for the same reason safeCssUrl()
	// rejects: Instagram handles are [A-Za-z0-9._] and at most 30 characters, so
	// anything else is not a handle and there is nothing to salvage. This URL is
	// the href of two controls the design adds (the @handle link and the Follow
	// pill), so it is attacker-influenceable input on a path that used to have
	// none.
	var IG_HANDLE_RE = /^[A-Za-z0-9._]{1,30}$/;
	function profileUrlForHandle(handle) {
		if (typeof handle !== 'string' || !IG_HANDLE_RE.test(handle)) return '';
		return 'https://www.instagram.com/' + handle + '/';
	}

	// Stable hue for the fallback avatar's gradient (rule IG-4). The reference
	// carries an `owner.hue` in its fixture; the feed gives us no such field, so
	// it is derived from the handle. Deterministic is the requirement, not
	// distribution: the same account must get the same disc on every slide and
	// every page load, or the avatar appears to change colour as the visitor
	// swipes through one creator's reels.
	function hueForHandle(handle) {
		var str = typeof handle === 'string' ? handle : '';
		var h = 0;
		for (var i = 0; i < str.length; i++) {
			h = ((h << 5) - h + str.charCodeAt(i)) | 0;
		}
		return Math.abs(h) % 360;
	}

	// Rex review (SMASH-1851): the classic lightbox's caption renderer
	// (js/sb-instagram.js's encodeHTML(), around line 4650) unescapes a
	// caption's literal `<br>`/`<br/>` line-break markers back into a real
	// `<br>` tag for its own innerHTML render. This viewer never uses
	// innerHTML for post-derived text (§12) — captionEl.textContent below
	// would otherwise print the literal characters "<br>" instead of a line
	// break. The safe equivalent: translate the same markers to a real `\n`
	// character. `\n` inside a text NODE is inert — it can't be interpreted
	// as markup — and .sbi-qs-caption's `white-space: pre-line` is what
	// turns it into a visible line break.
	function formatCaptionText(raw) {
		if (typeof raw !== 'string') return '';
		return raw.replace(/<br\s*\/?\s*>/gi, '\n');
	}

	// ── §6.1 interaction counts (SMASH-1851) ─────────────────────────────────
	// The whole point of these two helpers is that "no data" and "zero" are
	// DIFFERENT. Instagram returns no like/comment counts at all for personal
	// (basic-display) connections, and the template emits an empty attribute in
	// that case; rendering it as "0 likes" would misstate a post that may have
	// thousands. parseCount() therefore yields null for anything that isn't a
	// real number, and only a real number — including 0 — renders.
	function parseCount(raw) {
		if (raw === undefined || raw === null || raw === '') return null;
		var n = parseInt(raw, 10);
		return isNaN(n) || n < 0 ? null : n;
	}

	// Platform-convention abbreviation for display; the accessible name uses
	// the exact figure instead (a screen reader gains nothing from "1.2K").
	function formatCount(n) {
		if (n < 1000) return String(n);
		// 999,500 — not 1,000,000, and not 999,950 either (Rex review,
		// 2026-08-24): the K branch rounds for k >= 100, so the SMALLEST n whose
		// K form rounds up to 1000 (and would print "1000K") is 999,500.
		if (n < 999500) {
			var k = n / 1000;
			return (k >= 100 ? Math.round(k) : Math.round(k * 10) / 10) + 'K';
		}
		var m = n / 1000000;
		return (m >= 100 ? Math.round(m) : Math.round(m * 10) / 10) + 'M';
	}

	function countNoun(kind, n) {
		if (kind === 'likes') return n === 1 ? 'like' : 'likes';
		return n === 1 ? 'comment' : 'comments';
	}

	function exactCount(n) {
		// Grouped with the visitor's locale, matching how the rest of the
		// plugin renders counts in the feed itself.
		try {
			return n.toLocaleString();
		} catch (e) {
			return String(n);
		}
	}

	// §12: "Any identifier interpolated into an embed URL MUST be validated
	// against an expected shape before use, not concatenated raw." Instagram
	// permalinks look like https://www.instagram.com/reel/<shortcode>/ (also
	// /p/ and the deprecated /tv/ alias) — validate the whole shape, not just
	// the scheme, before it becomes part of an embed src.
	var IG_PERMALINK_RE = /^https:\/\/(?:www\.)?instagram\.com\/(?:reel|tv|p)\/[A-Za-z0-9_-]+\/?$/i;

	function isValidInstagramPermalink(u) {
		return typeof u === 'string' && IG_PERMALINK_RE.test(u);
	}

	function embedUrlForPermalink(permalink) {
		if (!isValidInstagramPermalink(permalink)) return '';
		var withSlash = permalink.charAt(permalink.length - 1) === '/' ? permalink : permalink + '/';
		return withSlash + 'embed/';
	}

	function el(tag, className, attrs) {
		var node = document.createElement(tag);
		if (className) node.className = className;
		if (attrs) {
			Object.keys(attrs).forEach(function (k) { node.setAttribute(k, attrs[k]); });
		}
		return node;
	}

	// §8 analytics seam. No transport exists yet — SMASH-1852 owns the shared
	// swipeview_* endpoint. This function is the ONE place that call will be
	// added; everything else in this file only ever calls emitAnalytics().
	// Implements the §8 throttle (>= 250ms between emits of the SAME event name)
	// so a future transport can't be retry-stormed by fast navigation.
	function emitAnalytics(name, payload) {
		var now = Date.now();
		if (lastAnalyticsAt[name] && (now - lastAnalyticsAt[name]) < ANALYTICS_THROTTLE_MS) return;
		lastAnalyticsAt[name] = now;
		// TODO(SMASH-1852): POST { name, payload, schema_version } to the shared
		// swipeview analytics route once it exists. Until then this is a no-op
		// transport with a debug log, matching §8's "a failed send is dropped
		// silently and MUST NOT retry-storm" requirement trivially (there is no
		// send to fail).
		log('analytics:', name, payload);
		try { $(document).trigger('sbi_swipeview:' + name, [payload]); } catch (e) {}
	}

	// ── Mixed-feed eligibility + dispatch guards (§2.2, §2.4) ──────────────

	// A post is Reels-eligible per §2.1; the plugin's own get_media_video_type()
	// resolution (media_product_type field, permalink /reel//tv/ fallback) is
	// already baked into data-media-type server-side, so this is just a read.
	function isReelAnchor($a) {
		return ($a.attr('data-media-type') || '').toLowerCase() === 'reels';
	}

	// §2.4 lightbox-disabled suppression. `disablelightbox` has THREE
	// divergent readers in this plugin (see the experience spec §2.4's
	// table), so this file does NOT re-implement any part of that value-set
	// logic. The server computes the canonical (boolean-aware, union)
	// reading exactly once, via sbi_swipe_lightbox_disabled() in
	// inc/if-functions.php, and rides the same data-sbi-flags channel the
	// gdpr / overrideBlockCDN flags below already use (see
	// feedSuppressesEmbedTier()) rather than a second channel.
	//
	// This is additive to, not a replacement for, the `.sbi_disable_lightbox`
	// class check below: that class is emitted by a narrower reader
	// (class-sbi-display-elements-pro.php:29, which accepts 'on' / 'true' /
	// boolean true but not '1' / 1) and, where it does fire, already hides
	// the anchor via CSS (display:none) before this file's click listener
	// ever sees it. This flag exists to close the gap for the spellings that
	// reader misses.
	function feedHasLightboxDisabled($feed) {
		var flags = (($feed.attr('data-sbi-flags') || '')).split(',');
		return flags.indexOf('lightboxdisabled') !== -1;
	}

	// §2.4 / mixed-feed guards. All of these mirror an EXISTING signal the
	// classic lightbox / shoppable / moderation code already relies on, so the
	// viewer degrades exactly the same way the lightbox does for the same post:
	//   - .sbi_link.sbi_disable_lightbox  -> "disable lightbox" setting OR an
	//     active shoppable feed (js/sb-instagram.js adds this same class when
	//     captionlinks/shoppable is on — see the shoppable feed link rewrite).
	//   - .sbi_link.sbi_link_customizer   -> customizer preview context.
	//   - .sbi.sbi_moderation_mode        -> moderation mode / customizer
	//     moderation preview for the whole feed.
	//   - feedHasLightboxDisabled($feed)  -> the canonical union reading of
	//     the same "disable lightbox" setting (see above); catches the
	//     spellings the sbi_disable_lightbox class's reader misses.
	function isDispatchSuppressed($a, $feed) {
		var $link = $a.closest('.sbi_link');
		if ($link.hasClass('sbi_disable_lightbox')) return true;
		if ($link.hasClass('sbi_link_customizer')) return true;
		if ($feed.hasClass('sbi_moderation_mode')) return true;
		if (feedHasLightboxDisabled($feed)) return true;
		return false;
	}

	// §2.4 GDPR/consent. The plugin already strips media_url server-side when
	// blocking_cdn() is true and consent hasn't been recorded at render time
	// (SB_Instagram_GDPR_Integrations), so a post with an empty data-video on a
	// GDPR-flagged feed is the observable signature of "not consented yet" from
	// this file's vantage point. We do NOT have cheap read access to the live,
	// cookie-driven `consentGiven` flag tracked inside js/sb-instagram.js's
	// per-feed closures, so this is a conservative proxy, not a live read:
	//   - the feed's own data-sbi-flags attribute (set once, server-side, from
	//     SB_Instagram_GDPR_Integrations::doing_gdpr()/blocking_cdn()) tells us
	//     whether this feed is GDPR-gated at all;
	//   - when it is, we refuse the embed tier outright for that feed's Reels,
	//     because a permalink-built Instagram embed loads third-party content
	//     regardless of whether media_url survived, and permalinks are never
	//     stripped by blocking_cdn() (they're a link out, not a CDN asset).
	// This means a user who already consented this session sees a slightly
	// more conservative fallback (poster+link instead of the embed tier) than
	// is strictly necessary — an accepted, safe-direction trade documented in
	// the SMASH-1851 report rather than a live consentGiven correlation, which
	// would require coupling into sb-instagram.js internals this file doesn't
	// otherwise depend on.
	function feedSuppressesEmbedTier($feed) {
		var flags = (($feed.attr('data-sbi-flags') || '')).split(',');
		return flags.indexOf('gdpr') !== -1 && flags.indexOf('overrideBlockCDN') === -1;
	}

	function collectReelsFromFeed($feed) {
		var items = [];
		$feed.find('a.sbi_link_area[data-lightbox-sbi]').each(function () {
			var $a = $(this);
			if (!isReelAnchor($a)) return;
			if (isDispatchSuppressed($a, $feed)) return;
			items.push({
				id: $a.attr('data-id') || '',
				permalink: $a.attr('data-url') || '',
				videoSrc: $a.attr('data-video') || '',
				poster: $a.attr('href') || '',
				caption: $a.attr('data-title') || '',
				username: $a.attr('data-user') || '',
				avatar: $a.attr('data-avatar') || '',
				// §6.1 counts — null when the feed emits no data for that
				// metric, so "missing" never renders as 0 (see parseCount).
				likes: parseCount($a.attr('data-likes')),
				comments: parseCount($a.attr('data-comments'))
			});
		});
		return items;
	}

	// ── DOM construction (§12: text, never markup, for anything post-derived) ──

	// ── Glyph provenance after the 2026-09-08 restyle ─────────────────────────
	// THE RULE CHANGED, and it changed by explicit decision rather than drift.
	//
	// This file's standing rule was "glyphs are copied verbatim, never redrawn":
	// Material Symbols geometry (Apache-2.0) for the play/pause/close class, and
	// hand-authored speaker shapes matched to the Reels player. That rule exists
	// because a path reproduced from memory is subtly wrong in ways only a render
	// reveals.
	//
	// The reference build ships its OWN hand-drawn set — a lighter 1.8-stroke
	// outline family for Instagram, drawn to sit together as one family rather
	// than assembled from a licensed set. Asmita's directive ("these are the
	// final designs and should be implemented as the design") and log rule IG-2
	// both put that set in charge, so the design's paths REPLACE ours.
	//
	// The verbatim rule is not weakened, it is re-pointed: the paths below are
	// transcribed character-for-character from Appendix A of the measured spec
	// (local-notes/swipe-view-launch/aman-reference-final-spec-2026-09-08.md),
	// which took them from his source rather than from a render. Nothing here is
	// redrawn, rescaled or re-cut, and a test asserts each string appears exactly
	// once in this file. Do not "improve" a path; change it in the design and
	// re-transcribe.
	//
	// SIDE EFFECT WORTH RECORDING: this removes the last inline Material Icons
	// path data from the viewer, which closes the open release-path licensing
	// question the survey carried (Apache-2.0 path data inside a GPL plugin
	// distribution). The whole glyph set is now the design's own work.
	//
	// One consequence for the licensing note above: the pause bars are gone
	// entirely. Rule 1.10 replaces the play/pause tap-flash with a play triangle
	// shown while paused, so there is no paused-state glyph to draw.

	// Rail glyphs (Appendix A.2). Wrapper paint is shared: `fill: none`,
	// `stroke: currentColor`, `stroke-width: 1.8`, round caps and joins.
	var RAIL_ICON_PATHS = {
		likes: ['M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8z'],
		comments: ['M12 3a9 9 0 0 0-7.6 13.8L3 21l4.4-1.3A9 9 0 1 0 12 3z'],
		// Paper plane — two paths, one stroked line plus the closed body.
		share: ['M22 2L11 13', 'M22 2l-7 20-4-9-9-4z'],
		// The Instagram mark. Not a <path>: it is a rect plus two circles, so it
		// is built by buildRailIcon()'s shape branch rather than declared here.
		view: []
	};
	var RAIL_ICON_PAINT = {
		fill: 'none', stroke: 'currentColor', 'stroke-width': '1.8',
		'stroke-linecap': 'round', 'stroke-linejoin': 'round'
	};

	// The Instagram mark (Appendix A.2, `stroke-width: 2`). Declared as SHAPES
	// rather than path data because that is what the design's source is — a
	// rounded rect, the lens circle, and a filled flash dot. Transcribing it into
	// a single path would be exactly the re-cutting the rule above forbids.
	var IG_MARK_SHAPES = [
		{ tag: 'rect', attrs: { x: '3', y: '3', width: '18', height: '18', rx: '5' } },
		{ tag: 'circle', attrs: { cx: '12', cy: '12', r: '4' } },
		{ tag: 'circle', attrs: { cx: '17.4', cy: '6.6', r: '1.2', fill: 'currentColor', stroke: 'none' } }
	];
	var IG_MARK_PAINT = {
		fill: 'none', stroke: 'currentColor', 'stroke-width': '2',
		'stroke-linecap': 'round', 'stroke-linejoin': 'round'
	};

	function svgRoot(size, viewBox) {
		var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
		svg.setAttribute('viewBox', viewBox || '0 0 24 24');
		svg.setAttribute('width', String(size));
		svg.setAttribute('height', String(size));
		// Presentation only. Every control carries its own aria-label, so the
		// glyph must stay out of the accessibility tree entirely — otherwise the
		// control is named twice, once by the label and once by whatever the SVG
		// contributes.
		svg.setAttribute('aria-hidden', 'true');
		svg.setAttribute('focusable', 'false');
		return svg;
	}

	function svgShape(tag, attrs, paint) {
		var node = document.createElementNS('http://www.w3.org/2000/svg', tag);
		Object.keys(paint || {}).forEach(function (k) { node.setAttribute(k, paint[k]); });
		Object.keys(attrs || {}).forEach(function (k) { node.setAttribute(k, attrs[k]); });
		return node;
	}

	// `size` is the RENDER box; the 24-unit viewBox never changes, which is what
	// makes 26px desktop / 28px mobile / 16px in the CTA pill the same ink at
	// three scales rather than three re-cut shapes.
	function buildRailIcon(kind, size) {
		var svg = svgRoot(size || 26);
		if (kind === 'view') {
			IG_MARK_SHAPES.forEach(function (shape) {
				svg.appendChild(svgShape(shape.tag, shape.attrs, IG_MARK_PAINT));
			});
			return svg;
		}
		(RAIL_ICON_PATHS[kind] || []).forEach(function (d) {
			svg.appendChild(svgShape('path', { d: d }, RAIL_ICON_PAINT));
		});
		return svg;
	}

	// ── Verified badge (Appendix A.2) ─────────────────────────────────────────
	// PROCEDURAL in the design's source, and procedural here for the same reason
	// it is there: it is a 24-point star built from two alternating radii, and a
	// literal 24-point polygon transcribed by hand is 48 numbers with no way to
	// spot a typo by reading. Generating it from the same three constants the
	// design uses (r = 10 / 8.4, 24 points, centre 12,12) makes the shape
	// checkable — a test regenerates it and compares against the measured,
	// resolved point list from the spec's appendix.
	function verifiedPoints() {
		var pts = [];
		for (var i = 0; i < 24; i++) {
			var r = (i % 2) ? 8.4 : 10;
			var a = i * Math.PI / 12;
			pts.push((12 + r * Math.cos(a)).toFixed(2) + ',' + (12 + r * Math.sin(a)).toFixed(2));
		}
		return pts.join(' ');
	}

	function buildVerifiedIcon() {
		var svg = svgRoot(14);
		svg.setAttribute('class', 'sbi-qs-verified');
		// role="img" + a name, because "verified" is information rather than
		// decoration: it is the one glyph in this file that a screen-reader user
		// would otherwise have no way to learn.
		svg.setAttribute('aria-hidden', 'false');
		svg.setAttribute('role', 'img');
		svg.setAttribute('aria-label', 'Verified');
		svg.appendChild(svgShape('polygon', { points: verifiedPoints(), fill: '#0095f6' }, {}));
		svg.appendChild(svgShape('path', {
			d: 'M7.8 12.4l2.7 2.6 5.7-5.8', fill: 'none', stroke: '#fff',
			'stroke-width': '2.2', 'stroke-linecap': 'round', 'stroke-linejoin': 'round'
		}, {}));
		return svg;
	}

	// ── Control glyphs (Appendix A.1 + A.2) ───────────────────────────────────
	// THE TABLE IS THE REVIEW SURFACE, unchanged as a principle: Aman reviews the
	// glyph set, so a swap has to be a one-line edit here. Nothing outside this
	// object may hard-code a path, and no call site may special-case an icon.
	// Adding an icon means adding a key; changing one means changing its `d`.
	//
	// Each entry is an array so a glyph can be several paths with independent
	// paint — the crossed speaker is a filled cone plus two stroked slashes —
	// which is why these cannot collapse into the flat string map RAIL_ICON_PATHS
	// uses.
	//
	// The viewBox stays FIXED at 24x24 whatever the render size, which is what
	// makes the scaling uniform, and it is why every entry has to be authored on
	// the same 24-unit grid.
	//
	// WHAT CHANGED IN THE RESTYLE, per glyph:
	//   close     — was Material's 24-unit X path, filled; now the design's
	//               2-unit STROKED cross at stroke-width 2.4 with round caps,
	//               rendered 22px in a 40px disc (rule 1.4). The 2026-08-28
	//               16px-render decision is reversed with it: that round was
	//               tuning a bare glyph against a transparent disc, and rule 1.4
	//               gives close a painted disc again.
	//   chevrons  — was hand-authored on the 24 grid with the ink box re-derived
	//               so each centred on (12,12); now the design's own
	//               `M6 15l6-6 6 6` pair at stroke-width 2.2. The centring
	//               DEFECT CLASS the old comment documented is still real and
	//               still worth knowing (a round cap paints strokeWidth/2 past
	//               the polyline on all four sides, and a mirrored pair spends
	//               the error in opposite directions so the pair reads closer
	//               together than their discs) — the reference's coordinates
	//               happen to be symmetric about (12,12) already: ink y runs
	//               8..16 for both, x runs 4.9..19.1 for both. A test
	//               re-derives both boxes from the path data rather than
	//               trusting this sentence.
	//   play      — was Material's `M8 5v14l11-7z`; now the design's
	//               `M8.5 5.5v13l10.5-6.5z` with a round join, which is what
	//               gives rule 1.10's 84px glyph its softened corners.
	//   pause     — GONE. Rule 1.10 shows a play triangle while paused rather
	//               than echoing the tap, so no pause glyph is rendered anywhere.
	//   volume*   — was hand-authored to the Reels player's filled speaker; now
	//               the design's lighter stroked speaker, and the MUTED state is
	//               a crossed-out X rather than a slash (Appendix A.2's
	//               `ig-ic-off`). TikTok's uses a slash — the two differ ON
	//               PURPOSE, per platform idiom, and must not be unified.
	//   swipeHand — new (rule 1.9's coach overlay), on its own 44x64 grid.
	var CONTROL_ICON_PATHS = {
		close: [
			{ d: 'M6 6l12 12M18 6L6 18', fill: 'none', stroke: 'currentColor', 'stroke-width': '2.4', 'stroke-linecap': 'round' }
		],
		chevronUp: [
			{ d: 'M6 15l6-6 6 6', fill: 'none', stroke: 'currentColor', 'stroke-width': '2.2', 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }
		],
		chevronDown: [
			{ d: 'M6 9l6 6 6-6', fill: 'none', stroke: 'currentColor', 'stroke-width': '2.2', 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }
		],
		play: [
			{ d: 'M8.5 5.5v13l10.5-6.5z', fill: 'currentColor', stroke: 'currentColor', 'stroke-width': '2.5', 'stroke-linejoin': 'round' }
		],
		volumeOn: [
			{ d: 'M11 5L6 9H2v6h4l5 4V5z', fill: 'none', stroke: 'currentColor', 'stroke-width': '1.8', 'stroke-linecap': 'round', 'stroke-linejoin': 'round' },
			{ d: 'M15.5 8.5a5 5 0 0 1 0 7M18.7 5.3a9.5 9.5 0 0 1 0 13.4', fill: 'none', stroke: 'currentColor', 'stroke-width': '1.8', 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }
		],
		volumeOff: [
			{ d: 'M11 5L6 9H2v6h4l5 4V5z', fill: 'none', stroke: 'currentColor', 'stroke-width': '1.8', 'stroke-linecap': 'round', 'stroke-linejoin': 'round' },
			{ d: 'M22 9l-6 6M16 9l6 6', fill: 'none', stroke: 'currentColor', 'stroke-width': '1.8', 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }
		]
	};

	// The coach overlay's hand (Appendix A.1). Its own 44x64 grid, and a circle
	// rather than only paths, so it gets its own builder for the same reason the
	// Instagram mark does: rescaling the design's coordinates onto the 24 grid
	// would mean rewriting the exported geometry.
	var SWIPE_HAND_SHAPES = [
		{ tag: 'path', attrs: { d: 'M22 6v30' } },
		{ tag: 'path', attrs: { d: 'M12 16l10-10 10 10' } },
		{ tag: 'circle', attrs: { cx: '22', cy: '52', r: '6', fill: '#fff', stroke: 'none' } }
	];

	function buildSwipeHand() {
		var svg = svgRoot(0, '0 0 44 64');
		svg.removeAttribute('width');
		svg.removeAttribute('height');
		svg.setAttribute('class', 'sbi-qs-coach-hand');
		SWIPE_HAND_SHAPES.forEach(function (shape) {
			svg.appendChild(svgShape(shape.tag, shape.attrs, {
				fill: 'none', stroke: '#fff', 'stroke-width': '2.4',
				'stroke-linecap': 'round', 'stroke-linejoin': 'round'
			}));
		});
		return svg;
	}

	// `size` is optional and defaults to the 22px close renders at, so a caller
	// that does not care about scale gets the chrome default.
	function buildControlIcon(name, size) {
		var specs = CONTROL_ICON_PATHS[name] || [];
		var svg = svgRoot(size || 22);
		specs.forEach(function (spec) {
			var path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
			// Filled by default (the historical majority case); a spec that wants
			// stroking says so explicitly. Keys are written straight through, so
			// a new paint attribute needs no change here.
			path.setAttribute('fill', 'currentColor');
			Object.keys(spec).forEach(function (k) { path.setAttribute(k, spec[k]); });
			svg.appendChild(path);
		});
		return svg;
	}

	// Swaps a control's glyph in place. Clears via removeChild rather than
	// innerHTML — §12 applies to our own markup too, and it keeps this file's
	// "no innerHTML anywhere near a control" property greppable. Replaces the
	// `$btn.text(glyph)` calls that used to live inline in the chrome updaters.
	// Swaps a control's glyph in place, preserving anything else the button
	// contains. `size` is threaded through because the mute button renders its
	// glyph at 20px (rule 1.6) while close renders at 22px, and the swap must not
	// silently resize the glyph it replaces.
	//
	// Clears the SVG children specifically rather than emptying the node, and
	// that is a behavioural requirement rather than tidiness: the mute button now
	// holds a `.sbi-qs-mute-label` sibling of its glyph (rule 1.6's expanding
	// label lives INSIDE the button), and a blanket clear would delete it on
	// every state change — taking the label, its transition and its accessible
	// treatment with it.
	//
	// Removes via removeChild rather than innerHTML — §12 applies to our own
	// markup too, and it keeps this file's "no innerHTML anywhere near a control"
	// property greppable.
	function setControlIcon($btn, name, size) {
		var node = $btn && $btn[0];
		if (!node) return;
		var svgs = node.querySelectorAll('svg');
		for (var i = 0; i < svgs.length; i++) node.removeChild(svgs[i]);
		// Prepended, so the glyph stays LEFT of the label whatever order the
		// children were in before the swap.
		node.insertBefore(buildControlIcon(name, size), node.firstChild);
	}

	function buildContainer() {
		if ($container && $container.length) return;

		// §7.1 — advertise the shortcuts AT users cannot otherwise find.
		// Carried on the dialog root, which is tabindex="-1", so this adds no
		// Tab stop.
		//
		// Scope rule: announce a shortcut only where the action has NO reliably
		// AT-reachable control. Deliberately narrower than onKeydown's full
		// binding set, because a list AT reads out on every open has a cost:
		//   Space  — togglePlay() has no focusable control AT ALL, by design
		//            (the tap IS the control). This is the gap being closed.
		//   Arrows — the chevrons are the only AT-reachable navigation, and
		//            .sbi-qs-nav is display:none outside
		//            `(hover: hover) and (pointer: fine)`, so focusables()'
		//            offsetParent filter drops them wholesale on touch.
		// Excluded — each action is already reachable, or is not a command:
		//   PageUp/PageDown, J, K — exact aliases of the arrows (rule 1.17 adds
		//            them as a superset); doubling what AT reads adds no
		//            capability. `aria-keyshortcuts` names the CANONICAL key for
		//            an action, not every alias bound to it.
		//   M      — updateMuteChrome() disables .sbi-qs-mute exactly when
		//            !caps.mute, so a labelled, enabled button is present
		//            whenever the action is meaningful at all.
		//   Escape — .sbi-qs-close is unconditionally in focusables(), and
		//            Escape-dismisses is a role="dialog"/aria-modal convention
		//            AT already conveys.
		//   Tab    — the §7.1 focus trap, not a command.
		// "Space" is the ARIA spelling of onKeydown's `case ' '` — the attribute
		// is itself a space-delimited list, so the literal key value can't be
		// used (WAI-ARIA 1.2 § aria-keyshortcuts). Every other token is its
		// `e.key` verbatim; tests/js/swipe-key-shortcuts.test.js pins the whole
		// value against onKeydown's real source so a token can never outlive its
		// binding.
		$container = $(el('div', 'sbi-qs-overlay', {
			role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Reels viewer',
			'aria-keyshortcuts': 'Space ArrowUp ArrowDown',
			tabindex: '-1', 'data-muted': 'true', 'data-paused': 'false'
		}));

		// ── Window-anchored close, TOP-LEFT (rule 1.4) ──────────────────────
		// The tooltip is one of exactly three in the design (close + both
		// chevrons, rule 1.9) and is CSS-only: a `::after` reading the
		// attribute, gated on pointer capability. Deliberately not an ARIA
		// mechanism — the accessible name already says "Close", and a
		// description repeating the shortcut that aria-keyshortcuts covers would
		// be read twice.
		var closeBtn = el('button', 'sbi-qs-close', {
			type: 'button', 'aria-label': 'Close reels viewer',
			'data-sbi-qs-tip': 'Close  Esc'
		});
		closeBtn.appendChild(buildControlIcon('close', 22));

		var viewport = el('div', 'sbi-qs-viewport');
		var track = el('div', 'sbi-qs-track');
		viewport.appendChild(track);

		// §7.1 "input layer" — the gesture-capture surface is a distinct element
		// so it can be hidden from assistive tech, instead of binding
		// wheel/touch/click handling to the dialog root itself (which DOES need
		// to stay in the accessibility tree). Sits above the media, below the
		// chrome (z-index).
		//
		// Carries NO tabindex, deliberately. It used to have tabindex="-1" to
		// keep it "out of the tab order", which was backwards: a <div> is not
		// focusable to begin with, so the attribute did not remove sequential
		// focusability (there was none) — it ADDED click and programmatic
		// focusability, which is the one thing an aria-hidden element must not
		// have. Chrome then refused the aria-hidden outright on any click
		// landing here: "Blocked aria-hidden on an element because its
		// descendant retained focus". That is not a console nit — the element is
		// un-hidden from AT for as long as it holds focus, so the layer AT is
		// supposed to never see becomes visible to it.
		//
		// `inert`, which the Chrome warning suggests, is the wrong tool for THIS
		// element: it removes pointer interaction along with AT exposure, and
		// pointer interaction is the element's entire purpose.
		var gestures = el('div', 'sbi-qs-gesture', { 'aria-hidden': 'true' });

		// ── Session-level frame chrome (rule 1.5, 1.10, 1.12) ───────────────
		// One overlay-level box carrying the frame's exact geometry, holding the
		// chrome that is session-scoped rather than per-post. See its stylesheet
		// comment for why the split exists (one mute button, one focus stop, one
		// capability-driven disabled state) and what it costs (the frame formula
		// is stated twice, and a test asserts the two agree).
		var frameChrome = el('div', 'sbi-qs-framechrome');

		var top = el('div', 'sbi-qs-top');

		// ── Mute (rule 1.6 / spec §2.4) ─────────────────────────────────────
		// The label is a CHILD of the button, not a sibling, and that is the
		// whole mechanism: the design's 34 -> 136 transition is one box growing
		// around a label sliding out of it, not two elements appearing next to
		// each other. It is aria-hidden because the button's own aria-label
		// already names the ACTION ("Unmute" / "Mute") — a label reading "Tap to
		// unmute" inside a button named "Unmute" would be announced twice, and
		// "Tap" is wrong on a keyboard anyway.
		var muteBtn = el('button', 'sbi-qs-mute', {
			type: 'button', 'data-act': 'mute', 'aria-label': 'Unmute', 'data-state': 'off'
		});
		muteBtn.appendChild(buildControlIcon('volumeOff', 20));
		var muteLabel = el('span', 'sbi-qs-mute-label', { 'aria-hidden': 'true' });
		muteLabel.textContent = 'Tap to unmute'; // text node — never markup (§12).
		muteBtn.appendChild(muteLabel);

		// ── CTA pill (rule IG-6) ────────────────────────────────────────────
		// Session-level with a per-slide href, for the same reason the mute
		// button is: there is one active post, and updateChrome() already
		// refreshes every other session control on slide change. §6f's "the CTA
		// is permanent chrome and MUST NOT be re-rendered or relocated as the
		// chain escalates" is satisfied structurally here — this element is
		// built once, outside the track, and no tier change can touch it.
		var viewPill = el('a', 'sbi-qs-view-on-ig', { target: '_blank', rel: 'noopener noreferrer' });
		viewPill.appendChild(buildRailIcon('view', 16));
		var pillLabel = document.createElement('span');
		pillLabel.textContent = 'View on Instagram'; // text node — never markup (§12).
		viewPill.appendChild(pillLabel);

		top.appendChild(muteBtn);
		top.appendChild(viewPill);

		var progress = el('div', 'sbi-qs-progress', {
			role: 'progressbar', 'aria-label': 'Playback progress',
			'aria-valuemin': '0', 'aria-valuemax': '100', 'aria-valuenow': '0'
		});
		var progressFill = el('i', 'sbi-qs-progress-fill');
		progress.appendChild(progressFill);

		// ── Pause glyph (rule 1.10) ─────────────────────────────────────────
		// Shown for as long as the slide is paused, driven by the root's
		// `data-paused` attribute rather than by a class this code adds and
		// removes: syncPlayState() already samples the REAL player state every
		// 250ms, so hanging the glyph off that one attribute means the glyph
		// cannot disagree with the state the live region announces. A separate
		// class would be a second source of truth for "is it paused".
		//
		// aria-hidden because the sr-only play-state region below is what AT
		// consumes; a visible glyph and a live region both reporting the same
		// fact would double it up.
		var flash = el('div', 'sbi-qs-flash', { 'aria-hidden': 'true' });
		flash.appendChild(buildControlIcon('play', FLASH_GLYPH_PX));

		frameChrome.appendChild(top);
		frameChrome.appendChild(flash);
		frameChrome.appendChild(progress);

		// ── Desktop chevrons (rule 1.11) ────────────────────────────────────
		// Both directions are built unconditionally and DISABLED at the ends of
		// the track (updateChrome()), rather than being added and removed: a
		// control that vanishes at the last slide moves its sibling, and a
		// disabled button keeps the cluster's geometry stable while staying
		// honest about what it can do (§6.2).
		//
		// Tooltip copy names the arrow AND the new alias (rule 1.17's j/k), so
		// the superset is discoverable to the visitors who can use it without
		// putting a second token in aria-keyshortcuts for AT to read out.
		var nav = el('div', 'sbi-qs-nav', { 'aria-hidden': 'false' });
		var navPrev = el('button', 'sbi-qs-nav-prev', {
			type: 'button', 'data-nav': 'prev', 'aria-label': 'Previous reel',
			'data-sbi-qs-tip': 'Previous  ↑ / K'
		});
		navPrev.appendChild(buildControlIcon('chevronUp', 24));
		var navNext = el('button', 'sbi-qs-nav-next', {
			type: 'button', 'data-nav': 'next', 'aria-label': 'Next reel',
			'data-sbi-qs-tip': 'Next  ↓ / J'
		});
		navNext.appendChild(buildControlIcon('chevronDown', 24));
		nav.appendChild(navPrev);
		nav.appendChild(navNext);

		// ── The rail, ONE per session (rule 1.3, SMASH-1851) ────────────────
		// An overlay-level sibling, exactly like the chevron cluster it shares
		// a column with — not a child of `.sbi-qs-framechrome`, which would be
		// the tidier-looking home and is not available: framechrome carries
		// `overflow: hidden` so the 2px progress bar can sit flush on the
		// frame's rounded bottom edge, and on desktop the rail sits OUTSIDE the
		// frame, so it would be clipped away entirely.
		//
		// The resting geometry is unchanged by the move, and that is checkable
		// rather than hopeful: `.sbi-qs-post` is `height: 100vh/100dvh` and
		// `.sbi-qs-overlay` is `position: fixed; inset: 0`, so the old and new
		// containing blocks are the same box, and the column's own insets
		// (`right`, `bottom`) resolve identically against either. Measured at
		// both viewports before and after — see the change log.
		var railCol = buildRail();

		// ── Position live region (rule 1.8) ─────────────────────────────────
		// The visible slide counter is GONE — the design has none on any
		// platform or viewport, and the frame's top-left is deliberately blank
		// (Aman removed the wordmark and never added a counter there). §6.1's
		// visible-counter row is therefore an open spec amendment, not something
		// to reinstate here.
		//
		// §7.1's POSITION ANNOUNCEMENT is not optional though, and it is
		// invisible, so it survives in AT-only form: a visually-hidden polite
		// live region announcing "<n> of <total>" on slide change. Same
		// information, zero visual cost, and it preserves the blank corner the
		// design chose twice.
		var live = el('div', 'sbi-screenreader sbi-qs-live', {
			role: 'status', 'aria-live': 'polite', 'aria-atomic': 'true'
		});

		// §6.1 "play/pause reflects actual player state" is BEHAVIOUR and stays
		// normative however the control is rendered. Fed from the SAME
		// 250ms-sampled real state the pause glyph reflects visually, so sighted
		// and AT users learn the same fact through different channels. Silent
		// when the active tier has no playPause capability (§6.2) rather than
		// announcing a state that isn't real.
		var playState = el('div', 'sbi-screenreader sbi-qs-playstate', {
			role: 'status', 'aria-live': 'polite', 'aria-atomic': 'true'
		});

		// ── First-run swipe coach (rule 1.9) ────────────────────────────────
		// Built once and reused; shown by maybeShowCoach() only on touch and only
		// on a visitor's first ever open. aria-hidden: the swipe it teaches has
		// keyboard and chevron equivalents that are already announced, and a
		// screen-reader user is not the audience for "swipe up".
		var coach = el('div', 'sbi-qs-coach', { 'aria-hidden': 'true' });
		var coachInner = el('div', 'sbi-qs-coach-inner');
		var coachText = document.createElement('span');
		coachText.textContent = 'Swipe up for next'; // text node — never markup (§12).
		coachInner.appendChild(coachText);
		coachInner.appendChild(buildSwipeHand());
		coach.appendChild(coachInner);

		// DOM order is the tab order (focusables() collects via jQuery .find(),
		// which returns document order — not selector order), so this sequence
		// is what decides the Tab cycle: mute -> CTA pill -> chevrons -> close,
		// then the active slide's own controls. open() focuses close, so Tab from
		// there lands on the first control in document order.
		// Appended after `nav` because the two are one visual column; the paint
		// order does not depend on it (the rail declares its own z-index) and
		// neither does the Tab cycle (focusables() composes an explicit order).
		$container.append(viewport, gestures, frameChrome, nav, railCol, live, playState, coach, closeBtn);
		$body.append($container);

		$track = $container.find('.sbi-qs-track');
		$gestures = $container.find('.sbi-qs-gesture');
		$frameChrome = $container.find('.sbi-qs-framechrome');
		$top = $container.find('.sbi-qs-top');
		$flash = $container.find('.sbi-qs-flash');
		$playState = $container.find('.sbi-qs-playstate');
		$live = $container.find('.sbi-qs-live');
		$navPrev = $container.find('[data-nav="prev"]');
		$navNext = $container.find('[data-nav="next"]');
		$muteBtn = $container.find('[data-act="mute"]');
		$muteLabel = $container.find('.sbi-qs-mute-label');
		$viewPill = $container.find('.sbi-qs-view-on-ig');
		$progressBar = $container.find('.sbi-qs-progress');
		$progressFill = $container.find('.sbi-qs-progress-fill');
		$coach = $container.find('.sbi-qs-coach');
		$railCol = $container.find('.sbi-qs-railcol');

		$container.on('click', '.sbi-qs-close', close);
		$muteBtn.on('click', toggleMute);
		// ONE handler for both chevrons, reading the direction off `data-nav`. It
		// routes through navigate() — the same function ArrowUp/ArrowDown call —
		// rather than reimplementing the step, so the cooldown, the §2.3 end
		// clamp, the one-slide-per-gesture rule, the stale-hint clears and the
		// prev/next analytics are identical to the keyboard path BY CONSTRUCTION
		// rather than by two code paths being kept in agreement.
		$navPrev.on('click', onNavClick);
		$navNext.on('click', onNavClick);


		// Wheel binds directly (needs passive:false to preventDefault).
		$gestures[0].addEventListener('wheel', onWheel, { passive: false });
		$gestures[0].addEventListener('touchstart', onTouchStart, { passive: true });
		// touchmove is NON-PASSIVE (SMASH-1978) — the same trap class as wheel
		// above. A passive listener's preventDefault() is ignored (with a console
		// warning), so the page would scroll under the viewer during a drag. The
		// handler only preventDefaults once a real drag is underway, so taps are
		// unaffected.
		$gestures[0].addEventListener('touchmove', onTouchMove, { passive: false });
		$gestures[0].addEventListener('touchend', onTouchEnd, { passive: true });
		$gestures[0].addEventListener('touchcancel', onTouchCancel, { passive: true });
		// §3.1: activating the video area toggles play/pause (NOT mute — mute is
		// its own explicit control, M key or the mute button). This is the ONLY
		// pointer path to play/pause: there is no persistent button, so the tap
		// IS the control rather than a convenience on top of one.
		//
		// Routed through onGestureClick(), not togglePlay() directly. A touch
		// sequence can still synthesise a click after a drag — engines disagree
		// about whether preventDefault() on touchmove suppresses it — so binding
		// togglePlay() here would make every swipe toggle playback.
		$gestures.on('click', onGestureClick);
	}

	// ── Rail (rules IG-2, IG-3) ──────────────────────────────────────────────
	// Three items on desktop (like, comment, share) plus a fourth on touch
	// (view). Each has DIFFERENT semantics and a different element type, and the
	// differences are the point rather than an inconsistency:
	//
	//   like    — a READOUT. There is no logged-in visitor inside an embedded
	//             feed, so we cannot like on their behalf; a heart styled like
	//             Instagram's tappable heart would promise something the UI
	//             cannot keep. `<div role="img">` with an exact-figure label,
	//             `cursor: default`, hover transform suppressed in CSS.
	//   comment — a LINK to the post, where commenting genuinely works.
	//   share   — a real <button>: the only genuine in-page action here.
	//   view    — a LINK, and the touch counterpart of the top-row CTA pill.
	//
	// ABSENCE IS NOT ZERO, and this is where that rule is enforced: Instagram
	// returns no like/comment counts at all for personal (basic-display)
	// connections, so parseCount() yields null and the count is OMITTED. Rule
	// IG-3 then splits the two cases, because a missing count means different
	// things for the two items: a like readout with no figure is meaningless, so
	// the whole item is dropped; a comment glyph with no figure is still a
	// working link-out, so it stays.
	//
	// Instagram exposes NO SHARE COUNT at any tier, so the share glyph never
	// carries one (rule IG-3). TikTok's does — the two rails differ on purpose.
	function buildRailItem(spec) {
		var node = el(spec.tag, 'sbi-qs-act' + (spec.modifier ? ' ' + spec.modifier : ''), spec.attrs || {});
		if (spec.tag === 'button') node.type = 'button';
		// ── target/rel at BUILD time; href at UPDATE time ────────────────────
		// The rail is built once per session, so an anchor's href now arrives
		// later (updateRail(), per slide) while target and rel can only be set
		// here. They used to be written together inside `if (spec.href)`, which
		// was right while every item was built with its post's URL already in
		// hand — and became a silent security regression the moment an href was
		// assigned afterwards: the link would open in the SAME TAB with no
		// `noopener`, handing `window.opener` to instagram.com.
		//
		// An <a> with no href is neither a link nor focusable, so a slide with
		// no usable permalink HIDES the item outright (updateRail) rather than
		// leaving a bare anchor sitting in the rail.
		if (spec.tag === 'a') {
			node.target = '_blank';
			node.rel = 'noopener noreferrer';
		}
		if (spec.href) node.href = spec.href;
		node.appendChild(buildRailIcon(spec.icon, 28));
		// ── The count row is ALWAYS rendered, even when empty ────────────────
		// Measured against the reference: his like, comment and share items are
		// all 43px tall on desktop, despite share carrying no figure — so the
		// count row's 12px is reserved rather than collapsed, and the three
		// glyphs stay evenly pitched. Rule IG-3's "share glyph without a count"
		// is about the FIGURE, not about the space; collapsing the row would
		// pull the share glyph 17px up toward its neighbour and break the rail's
		// rhythm.
		//
		// The element keeps its height via a min-height in CSS, because an empty
		// inline element generates no line box of its own.
		if (spec.label) {
			var label = el('span', 'sbi-qs-act-label', { 'aria-hidden': 'true' });
			label.textContent = spec.label; // text node — never markup (§12).
			node.appendChild(label);
		} else {
			var count = el('b', 'sbi-qs-act-count', { 'aria-hidden': 'true' });
			if (spec.count !== null && spec.count !== undefined) {
				count.textContent = formatCount(spec.count); // text node — never markup (§12).
			}
			node.appendChild(count);
		}
		return node;
	}

	// ── ONE rail, not one per slide (SMASH-1851, Asmita 2026-09-10) ──────────
	// Builds the column's SHELL and all three of its items once, with no post
	// data at all. updateRail() then re-points them on every slide change, the
	// same way updateChrome() has always re-pointed the top-row CTA pill.
	//
	// WHY IT MOVED OUT OF THE TRACK. The rail used to be a child of each
	// `.sbi-qs-post`, which is how it got its travel for free: the track's own
	// transform carried it. Measured on the 6.13.0.6 demo, that made the active
	// rail sweep the FULL SLIDE HEIGHT on every navigation — 900px at 1440x900,
	// 844px at 390x844 — while the top row and the chevrons held still at 0px.
	// The counts rode up the column with the outgoing reel and the next post's
	// arrived from below. Asmita's call: "keep them in place and update them
	// without them going up and down with the video (we do this with TikTok)."
	//
	// TikTok is the reference and its contract is precise, so it is worth
	// stating rather than approximating (SwipeView.jsx, `chromeTravelStyle`):
	//   - ONE rail element, a sibling of the track in the chrome layer.
	//   - It follows a FINGER DRAG by the live, end-clamped drag delta — the
	//     drag is direct manipulation, and a rail pinned during a drag is what
	//     put reel N's stats over reel N+1's incoming video (the SMASH-1978
	//     "the rail travels with the reel" call, 2026-08-27, which this does
	//     NOT reverse).
	//   - On a COMMIT it "lands at rest in the same paint that swaps its
	//     content" while the track animates the rest of the distance. So a
	//     wheel, key, chevron or drag-commit navigation moves it not at all.
	// That split is the whole change here: the drag-follow is preserved, the
	// commit-travel is removed. See setRailTravel() for the mechanism.
	//
	// Every item exists for the whole session and is shown or hidden per slide,
	// rather than being created and destroyed. That is what makes the four
	// contracts this rail already carried survive the move by CONSTRUCTION
	// rather than by re-derivation: one stable set of 44px hit rings, one
	// bounding box for the dead-space carve-out, one focus stop per control
	// instead of N, and no post captured in a closure anywhere — every href and
	// figure is read from `slides[currentIndex]` at update time.
	//
	// The ITEM SET still varies per post, because rule IG-3's "absence is not
	// zero" is unchanged: Instagram returns no counts at all for a personal
	// (basic-display) connection. The rail is bottom-anchored
	// (`justify-content: flex-end`), so losing an item shortens the column
	// upward and moves nothing that is left — the property
	// swipe-chrome-hit-test.test.js already derives 122px/193px from.
	//
	//   like    — a READOUT. There is no logged-in visitor inside an embedded
	//             feed, so we cannot like on their behalf; a heart styled like
	//             Instagram's tappable heart would promise something the UI
	//             cannot keep. `<div role="img">` with an exact-figure label,
	//             `cursor: default`, hover transform suppressed in CSS.
	//   comment — a LINK to the post, where commenting genuinely works.
	//   view    — a LINK, and the touch counterpart of the top-row CTA pill.
	//             `display: none` on desktop, where the pill takes over.
	//
	// ── NO SHARE ITEM — Asmita's call, 2026-09-08 ───────────────────────────
	// This overrides decision-log rule IG-3, which specified a share button
	// wired to Web Share. Her rule for the rail is PARITY with what the plugin
	// already shows elsewhere: "do not miss interaction counters displayed on
	// other layouts on the Swipe layout", and conversely do not invent one the
	// plugin does not have.
	//
	// The audit (see the change log's parity table) is unambiguous. Nothing in
	// Instagram Feed Pro renders a share COUNT anywhere — not the hover overlay
	// (hover-likes.php / hover-comments.php are the only two count templates),
	// not the lightbox, not any other template — because the Instagram Graph
	// API returns no share count for media. The lightbox does have an
	// `sbi_share` action, but it is a SOCIAL SHARING MENU (Facebook / X /
	// LinkedIn / Pinterest / email) with no number attached, so it is not a
	// counter and not this rail's business. A share glyph here was the one rail
	// item with no counterpart anywhere else in the plugin, and the only one
	// that could never carry a figure. It goes.
	//
	// Instagram exposes NO SHARE COUNT at any tier (rule IG-3). TikTok's does —
	// the two rails differ on purpose.
	function buildRail() {
		var col = el('div', 'sbi-qs-railcol');
		var rail = el('div', 'sbi-qs-rail');

		// The aria-labels here are PLACEHOLDERS that updateRail() overwrites
		// before the column is ever shown, and the like readout's is empty on
		// purpose: a stale figure is worse than none, and this node is hidden
		// until a post with a figure makes it visible.
		$railLike = $(buildRailItem({
			tag: 'div', icon: 'likes', count: null,
			modifier: 'sbi-qs-act-like',
			attrs: { role: 'img', 'aria-label': '' }
		}));
		$railComment = $(buildRailItem({
			tag: 'a', icon: 'comments', count: null,
			attrs: { 'aria-label': 'View comments on Instagram' }
		}));
		$railView = $(buildRailItem({
			tag: 'a', icon: 'view', count: null, label: 'View',
			modifier: 'sbi-qs-act-view',
			attrs: { 'aria-label': 'View on Instagram' }
		}));

		// Document order IS the rail's visual order (a flex column), and it is
		// the reference's anatomy: like -> comment -> view.
		rail.appendChild($railLike[0]);
		rail.appendChild($railComment[0]);
		rail.appendChild($railView[0]);
		col.appendChild(rail);
		// HIDDEN until a post makes them visible, so the invariant "the rail
		// never shows an item with no figure and no href" is a property of this
		// function rather than a consequence of open()'s call order. open() does
		// reach updateRail() (via goToIndex) before the overlay fades in, so
		// nothing would flash today — but that is one reordering away from a
		// rail of empty glyphs appearing for a frame.
		$railLike[0].hidden = true;
		$railComment[0].hidden = true;
		$railView[0].hidden = true;
		col.hidden = true;
		return col;
	}

	// ── The rail's per-slide content (rules IG-2, IG-3) ──────────────────────
	// Called from updateChrome(), which is the ONE function that means "the
	// active post changed" — the same call that re-points the top-row CTA pill.
	// That is deliberately the commit moment and not a moment during the
	// transition: TikTok swaps its counts in the paint the commit lands in, and
	// a mid-transition swap would show the incoming post's figures over the
	// outgoing post's video.
	//
	// Everything is read from the `post` handed in, so no item can ever hold a
	// stale identity: there is no closure over a post anywhere in the rail, and
	// an href is only ever the ACTIVE post's permalink. This is what keeps a
	// future analytics emission honest too — §8's seam has no rail event yet
	// (SMASH-1852 owns the transport), and when one lands it reads
	// `currentIndex` like every other emission in this file rather than a value
	// captured when the rail was built.
	function updateRail(post) {
		if (!$railCol || !$railCol.length) return;

		var safeHref = (post && isHttpUrl(post.permalink)) ? post.permalink : '';
		var likes = post ? post.likes : null;
		var comments = post ? post.comments : null;

		// Rule IG-3, half one: a like readout with no figure is meaningless, so
		// the whole item goes. `absence is not zero` — a non-business account
		// reports no metrics at all, and rendering "0 likes" would misstate it.
		var hasLikes = likes !== null && likes !== undefined;
		setRailItem($railLike, hasLikes, {
			count: hasLikes ? formatCount(likes) : '',
			// Singular/plural for the spoken form only — "1 likes" read aloud
			// is sloppy. The glyph and the abbreviated figure are decorative
			// duplicates of this label, so both are aria-hidden.
			label: hasLikes ? exactCount(likes) + ' ' + countNoun('likes', likes) : ''
		});

		// Rule IG-3, half two: the comment item is gated on the HREF, not on
		// the count — a comment glyph with no figure is still a working
		// link-out to where commenting genuinely happens.
		var hasComments = comments !== null && comments !== undefined;
		setRailItem($railComment, !!safeHref, {
			href: safeHref,
			count: hasComments ? formatCount(comments) : '',
			label: hasComments
				? exactCount(comments) + ' ' + countNoun('comments', comments) + ' — view on Instagram'
				: 'View comments on Instagram'
		});

		// Touch only — CSS hides it under the pointer-capability query, where
		// the top-row pill takes over. Rule IG-6, and Aman states the migration
		// explicitly: "the view button on mobile moves at the bottom, the mute
		// stays up top".
		setRailItem($railView, !!safeHref, { href: safeHref, label: 'View on Instagram' });

		// ── An all-empty rail hides the COLUMN, not just its items ───────────
		// This is the session-level successor to buildRail()'s old
		// `if (!rail.firstChild) return null`, and it has to hide the column
		// rather than merely empty it. The column's own 18px of bottom padding
		// is dead space for BOTH the dismiss and the tap-to-pause carve-outs
		// (pointIsInControlDeadSpace), so an empty-but-laid-out column would
		// keep carving a live region out of the backdrop for a post that has no
		// rail at all. A `hidden` column reports a 0x0 rect, which rectHasArea()
		// rejects — so the carve-out self-disables exactly where the rail does,
		// which is what swipe-backdrop-close.test.js's empty-column case pins.
		var anyVisible = !$railLike[0].hidden || !$railComment[0].hidden || !$railView[0].hidden;
		$railCol[0].hidden = !anyVisible;
	}

	// One item's per-slide state. `hidden` is the right primitive for the DATA
	// condition (this post has no figure / no permalink) and CSS owns the
	// VIEWPORT condition (`.sbi-qs-act-view` is display:none on desktop) — the
	// two are independent and must not be folded into one mechanism.
	//
	// The stylesheet carries an explicit `.sbi-qs-act[hidden] { display: none }`
	// because `hidden`'s UA rule is the weakest possible `display: none` and
	// `.sbi-qs-act` sets `display: flex`: an AUTHOR declaration beats it, so the
	// attribute alone would hide nothing at all. That is a genuinely
	// easy-to-miss trap, which is why the rule and this comment both exist.
	function setRailItem($item, visible, spec) {
		var node = $item && $item[0];
		if (!node) return;
		node.hidden = !visible;
		if (spec.href !== undefined) {
			// Only ever the ACTIVE post's permalink, and only on a visible item
			// — the item is hidden whenever there is no safe href, so an anchor
			// is never left holding a previous slide's URL. Removing it (rather
			// than writing '') is what keeps a hidden anchor a non-link.
			if (spec.href) node.href = spec.href;
			else node.removeAttribute('href');
		}
		if (spec.label !== undefined) node.setAttribute('aria-label', spec.label);
		if (spec.count !== undefined) {
			var countNode = node.querySelector('.sbi-qs-act-count');
			// text node — never markup (§12).
			if (countNode) countNode.textContent = spec.count;
		}
	}

	// ── The rail's drag-follow (SMASH-1851 / SMASH-1978) ─────────────────────
	// The rail mirrors the track's live drag delta and nothing else. `pxDelta`
	// is `dragDeltaPx` verbatim — the SAME already-end-clamped value the track
	// composes, deliberately shared rather than recomputed, because a second
	// derivation is how the two would eventually disagree about a clamp and
	// drift apart by a few pixels at the ends of the track.
	//
	// The delta alone is the correct mirror, not the track's whole transform.
	// The track sits at `-index * 100vh + dragDeltaPx`; its active slide
	// therefore sits at `dragDeltaPx` relative to the frame, and that is what
	// this rail — which describes exactly that one slide — has to match.
	//
	// `animate` is true for exactly one caller: settleBack(), the animated
	// return after a drag that did NOT commit. It is false during the drag (any
	// transition would make the rail lag the finger) and false on a commit (the
	// rail lands at rest in the same paint updateRail() swaps its content in).
	// Under reduced motion the FOLLOW stays and only the snap goes instant —
	// §3.2 is about motion the visitor did not ask for, and dragging is direct
	// manipulation they are performing themselves.
	function setRailTravel(pxDelta, animate) {
		var node = $railCol && $railCol[0];
		if (!node) return;
		// A LOCAL, not module state. The offset is write-only from this
		// function's point of view and nothing else in the file reads it — the
		// carve-out measures the rail's real rect instead
		// (pointIsInControlDeadSpace), which already reflects the transform and
		// cannot drift from it the way a cached number could.
		var px = pxDelta || 0;
		var instant = !animate || prefersReducedMotion();
		node.style.transitionDuration = instant ? '0ms' : TRANSITION_MS + 'ms';
		// Cleared to '' rather than to `translateY(0px)` so a rail at rest
		// carries no transform at all, and therefore establishes no containing
		// block and no stacking context it does not need.
		node.style.transform = px ? 'translateY(' + px + 'px)' : '';
	}

	// ── Caption (rules IG-4, IG-5) ───────────────────────────────────────────
	// Hashtags are tokenised out of the caption so they can take the design's
	// colour, and they are built as INERT SPANS rather than links. That is a
	// deliberate, escalated conflict rather than an oversight — see the
	// stylesheet's .sbi-qs-tag comment: rule IG-5 asks for both "caption text
	// never tappable" and "hashtags, hover underline", and spec §6.1's expander
	// contract (which encodes a defect that shipped three times) settles it
	// toward the first.
	//
	// Tokenising is done over the already-plain caption STRING and emits text
	// nodes and elements — at no point does post-derived text pass through
	// innerHTML (§12).
	var CAPTION_TOKEN_RE = /#[\wÀ-ɏЀ-ӿ]+/g;
	function appendCaptionText(target, raw) {
		var text = formatCaptionText(raw);
		var last = 0;
		var m;
		CAPTION_TOKEN_RE.lastIndex = 0;
		while ((m = CAPTION_TOKEN_RE.exec(text)) !== null) {
			if (m.index > last) target.appendChild(document.createTextNode(text.slice(last, m.index)));
			var tag = el('span', 'sbi-qs-tag');
			tag.textContent = m[0]; // text node — never markup (§12).
			target.appendChild(tag);
			last = m.index + m[0].length;
		}
		if (last < text.length) target.appendChild(document.createTextNode(text.slice(last)));
	}

	// Builds everything that lives INSIDE the painted frame for one slide, plus
	// the rail beside it. The media element itself is not built here — it arrives
	// later, per tier, into the media host (see instantiateTier(), which clears
	// only that host so this chrome survives every escalation).
	function buildSlideChrome(post, frame) {
		// The blurred letterbox backdrop (rule 1.14). Built only when a poster
		// URL survives BOTH the scheme check and the CSS-url guard, and hidden
		// until applyFit() decides the media is actually wider than the frame.
		// Instagram posters are absent on most cached rows, so the plain black
		// frame is the common IG case.
		var posterUrl = safeCssUrl(post.poster);
		var backdrop = null;
		if (posterUrl) {
			backdrop = el('div', 'sbi-qs-backdrop', { 'aria-hidden': 'true' });
			backdrop.style.backgroundImage = 'url("' + posterUrl + '")';
			backdrop.style.display = 'none';
			frame.appendChild(backdrop);
		}

		// The tier's own element goes in here. Separate from the frame so
		// instantiateTier()'s teardown cannot take the chrome with it — the old
		// structure had the media and the frame as one element, which is why the
		// chrome had to live outside and hug it.
		var host = el('div', 'sbi-qs-mediahost');
		frame.appendChild(host);

		// §6.1's loading affordance: never a blank frame for an activated slide
		// that is not yet playing (rule 1.19).
		frame.appendChild(el('div', 'sbi-qs-spinner', { 'aria-hidden': 'true' }));

		// Terminal tier (rule 1.19). Present on every slide but only displayed
		// when the frame carries data-tier="terminal", so escalating to it is an
		// attribute write rather than a DOM build — which is what keeps §6f's
		// "the CTA MUST NOT be re-rendered as the chain escalates" true by
		// construction.
		var fail = el('div', 'sbi-qs-fail');
		var failText = el('span', 'sbi-qs-fail-text');
		failText.textContent = 'Video unavailable'; // text node — never markup (§12).
		fail.appendChild(failText);
		var failHref = isHttpUrl(post.permalink) ? post.permalink : '';
		if (failHref) {
			// Styled exactly like the top-row CTA pill (rule 1.19), but on its
			// OWN class — the stylesheet lists the two selectors in one rule, so
			// there is still a single source of truth for the paint.
			//
			// Deliberately NOT reusing .sbi-qs-view-on-ig, and the reason is a
			// footgun rather than a preference: this element is per-slide and
			// display:none until its tier is reached, while the CTA is
			// session-level and always present. Sharing the class means a
			// document-order `querySelector('.sbi-qs-view-on-ig')` returns
			// whichever comes first in the DOM — which is this one, inside the
			// track — so any future code (or test, or measurement probe) that
			// reaches for "the CTA pill" by class silently gets a zero-box
			// element instead. Caught by the browser measurement pass.
			var failLink = el('a', 'sbi-qs-fail-link', {
				target: '_blank', rel: 'noopener noreferrer'
			});
			failLink.href = failHref;
			failLink.appendChild(buildRailIcon('view', 16));
			var failLabel = document.createElement('span');
			failLabel.textContent = 'Open on Instagram'; // text node — never markup (§12).
			failLink.appendChild(failLabel);
			fail.appendChild(failLink);
		}
		frame.appendChild(fail);

		frame.appendChild(el('div', 'sbi-qs-scrim', { 'aria-hidden': 'true' }));

		// ── Bottom row (rule IG-4) ──────────────────────────────────────────
		var bottom = el('div', 'sbi-qs-bottom');
		var profileUrl = profileUrlForHandle(post.username);

		if (post.username || post.avatar) {
			var row = el('div', 'sbi-qs-authorrow');

			// The @handle is a LINK to the profile (rule IG-4) — new
			// attacker-influenceable href surface, which is why
			// profileUrlForHandle() allowlists rather than escapes. With no safe
			// handle the row degrades to a plain <div>: the avatar and handle
			// still render, they simply do not link anywhere.
			var author = el(profileUrl ? 'a' : 'div', 'sbi-qs-author');
			if (profileUrl) {
				author.href = profileUrl;
				author.target = '_blank';
				author.rel = 'noopener noreferrer';
				author.setAttribute('aria-label', '@' + post.username + ' on Instagram');
			}

			var safeAvatar = safeMediaSrc(post.avatar);
			if (safeAvatar) {
				var avatarImg = el('img', 'sbi-qs-avatar', { alt: '' });
				avatarImg.src = safeAvatar; // property assignment, not string concat into markup.
				// A dead avatar URL must not leave a grey box where the design
				// has a disc: swap in the same initial-letter fallback the
				// no-URL case uses.
				avatarImg.addEventListener('error', function () {
					var repl = buildAvatarFallback(post.username);
					if (avatarImg.parentNode) avatarImg.parentNode.replaceChild(repl, avatarImg);
				});
				author.appendChild(avatarImg);
			} else {
				author.appendChild(buildAvatarFallback(post.username));
			}

			if (post.username) {
				var handle = el('span', 'sbi-qs-handle');
				var handleText = el('span', 'sbi-qs-handle-text');
				handleText.textContent = '@' + post.username; // text node — never markup (§12).
				handle.appendChild(handleText);
				// ── Verified badge: rule IG-4's "when known", and it is NEVER
				// known on this feed ─────────────────────────────────────────
				// The design shows a verified tick beside the handle. The
				// Instagram feed payload carries no verified flag at all
				// (templates/elements/item/hover-item.php emits data-user,
				// data-avatar, data-url, data-likes, data-comments and nothing
				// else), and neither does the cached row it is built from — so
				// this branch cannot fire today. It is written, tested and left
				// in place rather than dropped, because "when known" is the
				// rule and the day the field exists this is one emitter away
				// from working. Recorded in the change log as a gap, not a
				// silent omission.
				if (post.verified) handle.appendChild(buildVerifiedIcon());
				author.appendChild(handle);
			}
			row.appendChild(author);

			// Follow (rule IG-4). Aman's stated rationale is CTA density — "our
			// users might appreciate having CTA almost everywhere" — which is
			// why this stacks up to three outbound CTAs per slide on desktop
			// alongside the top pill and the rail's comment link. That is
			// deliberate; do not thin it out without his sign-off.
			if (profileUrl) {
				var follow = el('a', 'sbi-qs-follow', {
					target: '_blank', rel: 'noopener noreferrer',
					'aria-label': 'Follow @' + post.username + ' on Instagram'
				});
				follow.href = profileUrl;
				follow.textContent = 'Follow'; // text node — never markup (§12).
				row.appendChild(follow);
			}
			bottom.appendChild(row);
		}

		if (post.caption) {
			var caption = el('p', 'sbi-qs-caption');
			var captionText = el('span', 'sbi-qs-caption-text');
			appendCaptionText(captionText, post.caption);
			caption.appendChild(captionText);
			// The ONLY interactive piece (§6.1, rule IG-5). Revealed by
			// syncCaptionExpansion() on MEASURED overflow, because the one-line
			// clamp's geometry depends on viewport and font — the same reasoning
			// §6.3 applies to collision.
			var moreBtn = el('button', 'sbi-qs-caption-more', { type: 'button', 'aria-expanded': 'false' });
			moreBtn.textContent = 'more'; // text node — never markup (§12).
			moreBtn.addEventListener('click', function () {
				var expanded = caption.classList.toggle('sbi-qs-caption-expanded');
				moreBtn.setAttribute('aria-expanded', expanded ? 'true' : 'false');
				moreBtn.textContent = expanded ? 'less' : 'more';
				if (!expanded) captionText.scrollTop = 0;
			});
			caption.appendChild(moreBtn);
			bottom.appendChild(caption);
		}

		frame.appendChild(bottom);

		// No `rail` any more — it is session-level and built once by
		// buildContainer(). See buildRail().
		return { host: host, backdrop: backdrop };
	}

	// The initial-letter gradient disc (rule IG-4). Hue is derived from the
	// handle so one creator's disc is the same colour on every slide.
	function buildAvatarFallback(username) {
		var node = el('span', 'sbi-qs-avatar sbi-qs-avatar-fallback', { 'aria-hidden': 'true' });
		var name = typeof username === 'string' ? username : '';
		node.style.setProperty('--sbi-qs-avatar-hue', String(hueForHandle(name)));
		node.textContent = name ? name.charAt(0) : ''; // text node — never markup (§12).
		return node;
	}

	function renderPosts() {
		$track.empty();
		slides = [];

		posts.forEach(function (post, i) {
			var article = el('article', 'sbi-qs-post', {
				'data-index': String(i),
				'aria-roledescription': 'reel',
				'aria-label': 'Reel ' + (i + 1) + ' of ' + posts.length
			});
			// The PAINTED FRAME (rule 1.1). All per-slide chrome now lives inside
			// it — the old structure had the chrome hugging the stage from
			// outside, which is what made the meta row read wider than the
			// video column (the mixed-anchoring advisory the survey carried and
			// Aman flagged for the design pass). Everything in the frame is
			// frame-anchored now; only close is window-anchored.
			var frame = el('div', 'sbi-qs-media');
			article.appendChild(frame);
			var built = buildSlideChrome(post, frame);
			// NO RAIL HERE (SMASH-1851). It used to be appended to the article,
			// which is what made it travel the full slide height on every
			// navigation; it is now one session-level column outside the track,
			// re-pointed by updateRail(). Anything inside the track inherits
			// the track's transform, so a slide is the one place the rail
			// cannot live if it is to stay put.
			$track[0].appendChild(article);

			slides.push({
				post: post,
				article: article,
				// `stage` is the MEDIA HOST, not the frame: instantiateTier()
				// clears it on every escalation, and the chrome must survive
				// that. `frame` is the painted box the chrome and the fit /
				// buffering / tier attributes hang off.
				stage: built.host,
				frame: frame,
				backdrop: built.backdrop,
				tier: -1,          // Not yet instantiated (lazy — see ensureSlideMedia()).
				inst: null,
				caps: NO_CAPS,
				watchdog: null,
				playingSeen: false,
				terminalReported: false,
				// SMASH-1979 (§4.4 adjacent pre-warm): true only while this slide's
				// instance exists BECAUSE pre-warm created it and activation has not
				// yet taken over. It is the single discriminator for three rules that
				// all key off "this media exists speculatively": emissions are
				// discarded (§9.1 interim contract), activation re-evaluates the chain
				// from tier 1 rather than inheriting the element (§4.4 rule 2), and
				// leaving the ±1 window releases it (§4.4's lifecycle half).
				// Cleared the instant activation claims the slide, so an ACTIVATED
				// slide is never touched by any of the three.
				warm: false
			});
		});
	}

	// ── Fallback chain (§5) ─────────────────────────────────────────────────
	// Tier 0: native <video> on the cached media_url.
	// Tier 1: Instagram Reel embed iframe (only offered with a validated permalink
	//         AND when the feed isn't GDPR-suppressed for embeds — see
	//         feedSuppressesEmbedTier()).
	// Tier 2 (terminal): poster image in the stage + the always-present "View on
	//         Instagram" CTA already built into the slide's chrome.

	function tierCanPlay(tierIndex, post) {
		if (tierIndex === 0) return !!safeMediaSrc(post.videoSrc);
		if (tierIndex === 1) return !suppressEmbedTier && !!embedUrlForPermalink(post.permalink);
		return true; // terminal tier always accepts.
	}

	function nextChainIndex(fromIndex, post) {
		for (var i = fromIndex; i <= 2; i++) {
			if (tierCanPlay(i, post)) return i;
		}
		return 2; // Unreachable in practice — terminal always accepts — but stay safe.
	}

	function clearWatchdog(slide) {
		if (slide.watchdog) { clearTimeout(slide.watchdog); slide.watchdog = null; }
	}

	function armWatchdog(slide, index) {
		clearWatchdog(slide);
		if (slide.playingSeen) return;
		slide.watchdog = setTimeout(function () {
			if (index !== currentIndex || slide.playingSeen) return;
			var terminal = slide.tier >= 2;
			emitAnalytics('swipeview_playback_stalled', { index: index, adapter: tierName(slide.tier), terminal: terminal });
			if (!terminal) {
				handleAdapterEvent(slide, index, 'error', { reason: 'no-start' });
			}
		}, START_TIMEOUT_MS);
	}

	function tierName(tierIndex) {
		return tierIndex === 0 ? 'native-video' : (tierIndex === 1 ? 'ig-reel-embed' : 'poster-link');
	}

	// Tears down whatever is currently in a slide's stage and instantiates the
	// next viable tier starting at `fromTier`. Mirrors the shared reference
	// shell's _instantiate(): destroy before clearing the stage so a <video>
	// doesn't keep buffering in a detached node.
	function instantiateTier(slide, index, fromTier) {
		clearWatchdog(slide);
		slide.playingSeen = false;
		if (slide.inst && slide.inst.destroy) slide.inst.destroy();
		slide.inst = null;
		slide.stage.innerHTML = '';

		var tier = nextChainIndex(fromTier, slide.post);
		slide.tier = tier;
		// Drives the terminal-tier presentation (rule 1.19) from an attribute
		// rather than by building or moving DOM, so the permanent CTA is
		// untouched by an escalation (§6f).
		if (slide.frame) {
			slide.frame.setAttribute('data-tier', tier >= 2 ? 'terminal' : tierName(tier));
			// A new tier means new (or no) intrinsic dimensions; the previous
			// tier's answer must not survive into it.
			slide.frame.removeAttribute('data-fit');
			slide.frame.removeAttribute('data-buffering');
		}

		if (tier === 0) {
			slide.caps = FULL_CAPS;
			slide.inst = instantiateNativeVideo(slide, index);
		} else if (tier === 1) {
			slide.caps = NO_CAPS;
			slide.inst = instantiateEmbed(slide, index);
		} else {
			slide.caps = NO_CAPS;
			slide.inst = instantiatePosterLink(slide, index);
			if (!slide.terminalReported) {
				slide.terminalReported = true;
				emitAnalytics('swipeview_terminal_tier', { index: index, adapter: 'poster-link' });
			}
		}
	}

	function handleAdapterEvent(slide, index, kind, detail) {
		// ── §9.1 INTERIM CONTRACT: consumer-side emission discard (SMASH-1979) ──
		//
		// Pre-warm has no warm-only instantiation path to use: `create(post, ctx)`
		// is the seam's ONLY entry point and it wires `ctx.emit` unconditionally, so
		// a pre-warmed <video> arrives fully connected to this function — its
		// `error`, `playing` and `ended` listeners all land here exactly as an active
		// slide's do. §4.4 therefore mandates the consumer side of the fix:
		// "Adapter emissions (§9.1) from a slide that is not active MUST be
		// discarded." This is that discard, and it is deliberately the FIRST thing
		// this function does — every branch below either emits §8 analytics or
		// escalates the chain, and both are forbidden for a pre-warm:
		//
		//   "a pre-warm error MUST NOT escalate the chain, MUST NOT pin or skip a
		//    tier, and MUST NOT emit swipeview_playback_fallback or any other §8
		//    event."  (§4.4 rule 1)
		//
		// Why that matters beyond correctness: a leaked pre-warm failure corrupts the
		// two numbers §11 leans on hardest — the fallback rate and
		// swipeview_terminal_tier — by counting failures no visitor ever saw. A
		// signed IG media URL that has expired (§5: six of six sampled URLs already
		// 403) would otherwise report a fallback for every warmed neighbour on the
		// track, whether or not anyone swiped to it.
		//
		// INTERIM, not the destination. The durable fix is a seam change — a
		// warm-only adapter entry point, or an "emissions suppressed until activated"
		// clause on the instance contract — recorded as future work in
		// IMPLEMENTATION-PLAN item O. Until that lands, isolation is the consumer's
		// job and this is the one place it happens.
		//
		// Keyed on `slide.warm`, NOT on `index !== currentIndex`. The narrower key is
		// the deliberate choice: an ACTIVATED slide sitting off-screen (paused, per
		// §4.4) keeps its pre-existing escalation behaviour, which SMASH-1979 has no
		// mandate to change. Only media that exists speculatively is silenced.
		if (slide && slide.warm) return;

		if (kind === 'error') {
			var from = tierName(slide.tier);
			var toTier = nextChainIndex(slide.tier + 1, slide.post);
			var to = toTier > slide.tier ? tierName(toTier) : null;
			emitAnalytics('swipeview_playback_fallback', {
				index: index, from: from, to: to, reason: (detail && detail.reason) || 'load-error'
			});
			instantiateTier(slide, index, slide.tier + 1);
			if (index === currentIndex) activateSlide(index, /* alreadyCurrent */ true);
			return;
		}
		if (kind === 'playing') {
			slide.playingSeen = true;
			clearWatchdog(slide);
			if (index === currentIndex) updateChrome();
			return;
		}
		if (kind === 'ended') {
			if (index === currentIndex && slide.inst && slide.inst.restart) slide.inst.restart();
			return;
		}
		if (kind === 'autoplay_blocked') {
			emitAnalytics('swipeview_autoplay_blocked', { index: index, intended: detail && detail.intended });
			// Task B (SMASH-1851, mirrors SMASH-1853): only arm the pill for
			// the slide the visitor is actually looking at — a neighbour
			// slot can independently hit this same rejection (e.g. while
			// pre-activating ahead of a swipe) and must not pop a pill for
			// an off-screen slide. Only an UNMUTED attempt being refused
			// arms it; a rejected MUTED retry means autoplay is blocked
			// outright, which the pill has nothing to offer for.
			if (index === currentIndex && detail && detail.intended === 'unmuted') {
				// Rule 1.7b: the design's "Tap to unmute" label is the REFUSAL
				// arm in our model, so this is the one event that can turn it
				// on. Sticky for the session rather than per-slide, because the
				// browser's autoplay policy is a property of the page, not of
				// the clip — once sound has been refused it will be refused on
				// the next slide too, which is exactly why the reference replays
				// its label per slide.
				autoplayRefused = true;
				updateChrome();
				startSoundHint();
			}
			return;
		}
	}

	// Shared play-with-fallback for the native <video> tier (SMASH-1851
	// §4.2 revision — sound-on-open, mirrors SMASH-1853). "If unmuted
	// playback is refused for want of a qualifying gesture, the viewer MUST
	// fall back to muted and continue... MUST NOT stall on a rejected
	// play() promise." This is the ONE place that logic lives — play(),
	// restart() and setMuted(false) all route through it, so the fallback
	// can't stay fixed in one call site while silently regressing in
	// another. That regression shape is not hypothetical: a bare
	// `video.play().catch(() => {})` in restart() (the §4.3 loop-at-end
	// path) would swallow a rejected replay without ever muting, emitting,
	// or re-arming the pill, leaving the shell believing playback was fine
	// while the element had in fact stopped (a rejected play() leaves the
	// video paused).
	//
	// `muted` is a plain boolean INTENT, asserted on `video.muted` directly
	// — no double negation anywhere in this file. Every caller passes the
	// value it actually wants, never a negation of some other flag (that
	// exact bug — `play({muted: !userMuted})` — shipped in a sibling port
	// of this same viewer and is the reason this helper exists as one
	// place, not one per call site).
	// The ONE writer of `unmuteSucceeded` (2026-08-24 feedback). Kept as a named
	// function rather than an inline assignment so the test harnesses that
	// extract attemptPlay() have something to stub and spy on — an inline
	// `unmuteSucceeded = true` would, in the non-strict scope those harnesses
	// evaluate, silently create a global instead of failing loudly.
	function noteUnmuteSucceeded() {
		unmuteSucceeded = true;
	}

	// ── iOS audio priming (SMASH-1851, investigation 2026-09-09 Part A) ───────
	// WebKit banks the audible-playback grant PER MEDIA ELEMENT, and it banks it
	// on a gesture-backed play(). A freshly created element has nothing banked,
	// however good the gesture that created it — which Chrome and Firefox hide
	// completely, because they gate autoplay per ORIGIN and a new element
	// inherits the page's permission. That asymmetry is why this shipped.
	//
	// So §4.1's unmuted attempt was being refused on iOS for every slide, and
	// the refusal arm (rule 1.7's "Tap to unmute" label) fired every time —
	// working as designed, on a viewer that should never have needed it.
	//
	// The fix is to bank a grant on the element BEFORE asking it for sound: a
	// muted play() while the gesture's activation is still live, immediately
	// paused. Muted playback needs no permission, so it succeeds and the element
	// keeps the grant; the unmuted play() that follows is then allowed.
	//
	// THREE THINGS HERE ARE LOAD-BEARING.
	//
	// 1. The pause is SYNCHRONOUS, not chained off the play promise. attemptPlay
	//    issues the real play() later in this same task, so a pause landing in a
	//    later microtask would stop the playback we just started — the primer
	//    would break the thing it exists to enable. Pausing immediately makes
	//    the play() an invocation-under-activation and nothing more, which is
	//    all the grant needs. It also makes play() reject with AbortError, which
	//    is expected and swallowed rather than routed into the §4.2 refusal path
	//    (that path is for a REAL refusal, and treating a self-inflicted abort
	//    as one would arm the label we are trying to make unnecessary).
	//
	// 2. It runs ONLY for an element created for ACTIVATION, never for a
	//    pre-warm. §4.4 requires a warmed element to be "created muted and not
	//    playing" with metadata as its buffering ceiling, and a play() — even a
	//    muted one — commits past that. Priming a warm element would also be
	//    pointless: ensureSlideMedia() releases and rebuilds it on activation
	//    (§4.4 rule 2, see its comment), so the element that actually plays is
	//    ALWAYS a fresh one created inside the activating gesture. Priming at
	//    creation therefore covers every path with no §4.4 cost at all.
	//
	// 3. It needs no once-per-element guard, because instantiateNativeVideo()
	//    creates exactly one element per call. A guard would be worse than
	//    redundant: the watchdog-escalation path builds an element with no
	//    gesture in scope, where priming legitimately fails, and a sticky flag
	//    would then block the next genuine attempt.
	//
	// WHAT THIS DOES NOT FIX, recorded so it is not mistaken for solved: the
	// 4000ms watchdog escalation (armWatchdog -> handleAdapterEvent('error') ->
	// instantiateTier) runs from a TIMER, so no activation is live and the new
	// element cannot bank anything. §4.1's muted fallback carries that case,
	// which is the failure arm behaving correctly.
	//
	// The per-element banking behaviour is an inference about WebKit internals —
	// consistent with the reported symptom, not provable from this repo. On-device
	// confirmation is Asmita's iPhone, and the investigation names the
	// discriminator: audio persisting on BACK-swipes but not forward ones proves
	// element identity is the cause, because ensureSlideMedia() reuses a retained
	// element going backward.
	function primeForAudio(v) {
		if (!v || !v.src) return;
		try {
			v.muted = true;
			var p = v.play();
			// Synchronous — see note 1 above.
			v.pause();
			// The abort this pause causes is ours, and must not reach §4.2.
			if (p && typeof p.catch === 'function') p.catch(function () {});
		} catch (e) { /* a browser that refuses outright leaves us no worse off */ }
	}

	function attemptPlay(v, slide, index, muted) {
		v.muted = muted;
		var p = v.play();
		if (!p || typeof p.catch !== 'function') return;
		// A RESOLVED unmuted play() is the only honest proof the browser actually
		// granted audio — re-checking `v.muted` at resolve time rather than
		// trusting the intent we passed in, because the fallback below (or an
		// explicit mute racing us) may have flipped it in the meantime. The
		// rejection arm is a no-op here: the existing .catch() below owns that
		// path, and leaving this one empty keeps the promise from going unhandled.
		if (!muted && typeof p.then === 'function') {
			p.then(function () { if (!v.muted) noteUnmuteSucceeded(); }, function () {});
		}
		p.catch(function () {
			if (!muted) {
				v.muted = true;
				handleAdapterEvent(slide, index, 'autoplay_blocked', { intended: 'unmuted' });
				v.play().catch(function () {
					handleAdapterEvent(slide, index, 'autoplay_blocked', { intended: 'muted' });
				});
			} else {
				handleAdapterEvent(slide, index, 'autoplay_blocked', { intended: 'muted' });
			}
		});
	}

	function instantiateNativeVideo(slide, index) {
		var v = document.createElement('video');
		var src = safeMediaSrc(slide.post.videoSrc);
		v.src = src;
		var poster = safeMediaSrc(slide.post.poster);
		if (poster) v.poster = poster;
		v.muted = true; // Pre-gesture safe default only — attemptPlay() sets the real intended value synchronously once play() is actually invoked (below), which happens before this element ever paints a frame.
		v.playsInline = true;
		v.setAttribute('playsinline', ''); // iOS Safari: required or playback goes fullscreen.
		v.loop = false; // Looping is driven explicitly on `ended` so the loop event always fires (§4.3).
		v.preload = 'metadata'; // Full download only once actually activated (§4.4 spirit, even without full windowing).
		v.className = 'sbi-qs-video';

		// Bank the audible-playback grant while the activating gesture is still
		// live (see primeForAudio). `slide.warm` is set by prewarmSlide() BEFORE
		// it calls instantiateTier(), so this reads false only for an element
		// being built for activation — which is the one that will be asked for
		// sound, and the only one §4.4 permits us to play.
		if (!slide.warm) primeForAudio(v);

		v.addEventListener('error', function () { handleAdapterEvent(slide, index, 'error', { reason: 'media-load-failed' }); });
		// The earliest point videoWidth/videoHeight are readable. Without this the
		// first correct band would wait for the next 250ms tick, and the card would
		// visibly jump mid-entrance on a slow-loading source.
		// The earliest point videoWidth/videoHeight are readable, and therefore
		// the earliest point rule 1.14's contain-vs-cover question has an answer.
		// Before this the honest answer is `cover`, which is also the common case
		// — so a late decision never shows a black band it then removes.
		v.addEventListener('loadedmetadata', function () { applyFit(slide); });
		// §6.1's loading affordance (rule 1.19). `waiting` and `stalled` are the
		// two signals a <video> gives for "I have nothing to paint"; `playing`
		// and `canplay` are the two for "I do". Driven off the element's own
		// events rather than a timer, so the spinner cannot linger after the
		// media recovers.
		v.addEventListener('waiting', function () { setBuffering(slide, true); });
		v.addEventListener('stalled', function () { setBuffering(slide, true); });
		v.addEventListener('canplay', function () { setBuffering(slide, false); });
		v.addEventListener('playing', function () { setBuffering(slide, false); handleAdapterEvent(slide, index, 'playing'); });
		v.addEventListener('ended', function () { handleAdapterEvent(slide, index, 'ended'); });
		// §4.2 revision (SMASH-1851, mirrors SMASH-1853): `volumechange`
		// fires for BOTH a user-driven change and a direct property
		// assignment (attemptPlay()'s fallback sets `v.muted` this way), so
		// this is the one listener that keeps the mute button/pill in sync
		// with reality regardless of which code path changed it — never
		// the `userMuted` intent, which can legitimately diverge from the
		// real property for as long as a rejected retry's fallback is in
		// effect.
		v.addEventListener('volumechange', function () {
			if (index === currentIndex) updateMuteChrome();
		});

		slide.stage.appendChild(v);

		return {
			name: 'native-video',
			el: v,
			play: function (opts) {
				var wantMuted = !opts || opts.muted !== false;
				v.preload = 'auto';
				attemptPlay(v, slide, index, wantMuted);
			},
			pause: function () { v.pause(); },
			setMuted: function (m) {
				// Muting never needs a play() call; unmuting does, and
				// routes through the SAME fallback as every other
				// activation so a rejected retry still degrades to muted +
				// re-arms the pill instead of leaving the element silently
				// paused.
				if (m) {
					v.muted = true;
				} else {
					attemptPlay(v, slide, index, false);
				}
			},
			// MUST NOT report optimistically (§9.1) — real paused/ended state only.
			isPlaying: function () { return !v.paused && !v.ended; },
			// Rex-class review demand (mirrors SMASH-1853 findings #1/#2):
			// the shell must render the REAL mute state, never the
			// `userMuted` intent — a rejected attemptPlay() retry can leave
			// the element muted even though intent never flipped (§4.2's
			// fallback is per-attempt, not persisted). Sampled by the
			// volumechange listener above and by the 250ms tick() poll.
			isMuted: function () { return v.muted; },
			progress: function () { return { current: v.currentTime || 0, duration: v.duration || 0 }; },
			restart: function () {
				// §4.3 loop-at-end — the spec calls this out by name as an
				// activation path that can land outside a user gesture.
				// Route through the SAME attemptPlay() fallback as
				// play()/setMuted() rather than a bare
				// `video.play().catch(() => {})`: that shape swallowed a
				// rejected replay silently (no mute, no emit, no pill) in
				// a sibling port of this viewer. Preserve whatever mute
				// state is currently in effect rather than forcing either
				// value.
				try { v.currentTime = 0; } catch (e) {}
				attemptPlay(v, slide, index, v.muted);
			},
			destroy: function () { try { v.pause(); v.removeAttribute('src'); v.load(); } catch (e) {} v.remove(); }
		};
	}

	function instantiateEmbed(slide, index) {
		var embedSrc = embedUrlForPermalink(slide.post.permalink);
		var frame = document.createElement('iframe');
		frame.src = embedSrc;
		frame.allow = 'autoplay; encrypted-media; picture-in-picture';
		frame.referrerPolicy = 'strict-origin-when-cross-origin';
		frame.setAttribute('scrolling', 'no');
		frame.setAttribute('title', 'Instagram embed');
		frame.className = 'sbi-qs-embed';
		var loaded = false;

		// §5.2 / §9.1: a cross-origin embed's `load` fires even for an error
		// document — this is the accepted, documented limitation. Reporting
		// `playing` on load is optimistic BY NECESSITY (there is no other
		// signal), and is what lets a genuinely-working embed disarm its own
		// watchdog instead of being escalated away every time.
		frame.addEventListener('load', function () {
			loaded = true;
			handleAdapterEvent(slide, index, 'playing');
		});

		slide.stage.appendChild(frame);

		return {
			name: 'ig-reel-embed',
			el: frame,
			play: function () {},
			pause: function () {},
			setMuted: function () {},
			isPlaying: function () { return loaded; },
			// No real mute control on this tier (caps.mute is false, so the
			// shell's toggle stays disabled and the pill's caps.mute gate
			// keeps it hidden regardless) — advisory only.
			isMuted: function () { return false; },
			progress: function () { return null; },
			restart: function () {},
			destroy: function () { frame.src = 'about:blank'; frame.remove(); }
		};
	}

	function instantiatePosterLink(slide, index) {
		var poster = safeMediaSrc(slide.post.poster);
		if (poster) {
			var img = document.createElement('img');
			img.className = 'sbi-qs-poster';
			img.src = poster;
			img.alt = '';
			// Rule 1.14 applies to the poster tier identically — a landscape
			// poster letterboxes over its own blurred blow-up rather than being
			// cropped. `load` is the poster's equivalent of `loadedmetadata`.
			img.addEventListener('load', function () { applyFit(slide); });
			slide.stage.appendChild(img);
		}
		// Terminal tier: nothing plays, but it's a valid presentation. Report
		// `playing` immediately so the watchdog stays quiet — there's nowhere
		// left to escalate to. Reliability is measured via swipeview_terminal_tier
		// instead (already emitted by instantiateTier()).
		handleAdapterEvent(slide, index, 'playing');
		return {
			name: 'poster-link',
			play: function () {},
			pause: function () {},
			setMuted: function () {},
			isPlaying: function () { return true; },
			// No audio at all on this tier (caps.mute is false) — `true` is
			// the more honest advisory default (nothing is playing). Also
			// the GDPR-no-consent shape's presentation, where the sound
			// control MUST NOT appear at all — the caps.mute gate in
			// updateMuteChrome() is what actually enforces that.
			isMuted: function () { return true; },
			progress: function () { return null; },
			restart: function () {},
			destroy: function () {}
		};
	}

	function ensureSlideMedia(index) {
		var slide = slides[index];
		if (!slide) return;
		// §4.4 rule 2 — "A stale pre-warm MUST NOT skip tiers." A pre-warmed slide
		// arrives here already carrying an instantiated tier, and the ONE thing
		// activation may not do is inherit it: "On activation the chain MUST be
		// evaluated from tier 1 per §5.1 against the freshly-read source, exactly as
		// if no pre-warm had happened."
		//
		// So the warm element is released and the chain re-runs from tier 1 (index 0
		// here) below, through the identical `instantiateTier(slide, index, 0)` call a
		// never-warmed slide takes. Without this release the `slide.tier !== -1` bail
		// on the next line would hand activation the warm element, and a pre-warm that
		// succeeded minutes ago would silently decide the outcome of an activation
		// happening now — against a signed URL whose ~48h window may well have closed
		// in between (§5). That is precisely the authority §4.4 denies it: "pre-warm
		// may only ever make activation FASTER. It has no authority over what
		// activation DECIDES."
		//
		// The speed benefit survives intact, because what a pre-warm actually warms is
		// the HTTP cache, not the element instance — a fresh element on a still-valid
		// URL starts from cached bytes. What does not survive is the stale element's
		// verdict, which is the whole point.
		if (slide.warm) releaseWarmSlide(slide);
		if (slide.tier !== -1) return;
		instantiateTier(slide, index, 0);
	}

	// ── Adjacent pre-warm (§4.4, SMASH-1979) ────────────────────────────────
	//
	// §4.4's slot rules bound the COST of preloading and leave the BENEFIT
	// unspecified, so before this every next-swipe paid a cold start and the visitor
	// watched a loader on a slide the viewer could already have been warming. This
	// block is the benefit half, and every one of its bounds is a spec MUST.
	//
	// Worth stating plainly what this viewer is, because it changes what the rules
	// require: Instagram renders EVERY slide and instantiates media lazily on
	// activation (§4.4's "Where the implementations stand today" names it). Rendering
	// a slide implies nothing about its media — so ±1 is a bound this code has to
	// impose deliberately rather than inherit from a three-slot DOM window, and the
	// release half (releaseWarmOutsideWindow) has to be explicit for the same reason:
	// "where every slide is rendered, it MUST be done explicitly, because rendering a
	// slide implies nothing about releasing its media."

	// §4.4: "the viewer SHOULD pre-warm the NEXT slide's media resource, then the
	// PREVIOUS one. It MUST NOT pre-warm any slide beyond ±1." Both facts live in
	// this one array — the offsets AND their order — and it is the single source for
	// the warm set and the release window alike (isWithinPrewarmWindow reads it too).
	// That coupling is intentional: widening the warm set without widening the
	// release window, or the reverse, is the drift that would reintroduce the
	// unbounded accumulation the ±1 bound exists to prevent, and it cannot be
	// expressed here without editing one array that both halves read.
	//
	// Not a tunable. The bound is the point, not an implementation convenience: the
	// track is a snapshot of a whole feed (§2.3) the visitor may never scroll, so
	// every slide warmed past the adjacent pair is a fetch nobody is likely to
	// redeem. ±1 holds "regardless of what the host renders".
	var PREWARM_OFFSETS = [1, -1];

	// §4.4: "Transport, not tier index — never pre-warm an iframe." The spec is
	// emphatic that the scoping is by TRANSPORT and not by position in the chain,
	// because "scoping this rule by index rather than by transport would permit
	// precisely the case its rationale forbids" — a renumbered or inserted tier would
	// silently move an iframe into pre-warm range. So each tier declares what it IS
	// and pre-warm asks that question, rather than comparing an integer.
	//
	// Three properties of the iframe transport compound, and none of them are
	// properties of the tier index: an iframe is heavy; it exposes no playback API to
	// warm against (the frame's `load` event is all the page can observe — §5.2's
	// accepted limitation); and it is a THIRD-PARTY load carrying its own consent
	// semantics, so a frame fetched for a slide the visitor never reaches is "a
	// third-party request made on their behalf for content they never asked to see, a
	// privacy cost under §5.3 and not one the viewer may incur speculatively".
	// The terminal tier is a poster image plus the permalink CTA — a link-out, with
	// no media element to warm at all.
	var TIER_TRANSPORT = {
		0: 'media-element', // native <video> — an HTMLMediaElement, the only warmable transport
		1: 'iframe',        // IG Reel embed — MUST NOT be pre-warmed, whatever its index
		2: 'link'           // terminal poster + "View on Instagram" CTA — nothing to warm
	};

	function tierIsPrewarmable(tierIndex) {
		return TIER_TRANSPORT[tierIndex] === 'media-element';
	}

	// §4.4 "Data preferences" + the Level B gate, resolved in ONE place so the whole
	// policy is decided once per activation rather than re-derived per neighbour.
	// Returns exactly one of:
	//
	//   'none'     — pre-warm suppressed entirely, Level A included. No element.
	//   'metadata' — Level A, the normative floor and the default.
	//   'buffer'   — Level B, a MAY, only on a plausibly-fast connection.
	//
	// Read fresh on every activation, never cached: `navigator.connection` is live, so
	// a visitor who moves onto a metered connection mid-session stops being warmed
	// from the next swipe onward, and one who enables Save-Data stops immediately.
	function prewarmLevel() {
		var conn = navigator.connection;
		// §4.4: "Pre-warm MUST be suppressed entirely — no element instantiated,
		// Level A included — when navigator.connection.saveData is true." Save-Data is
		// a hard suppression rather than one input among several because it is the only
		// signal of metered INTENT the platform offers — effectiveType separates fast
		// from slow, not metered from unmetered (a fast cellular connection reads
		// '4g').
		if (conn && conn.saveData === true) return 'none';
		// §4.4: "Plausibly fast means navigator.connection.saveData is false AND
		// effectiveType is 4g."
		//
		// Both halves are compared with === against the exact values the spec names,
		// which is load-bearing and not stylistic. A truthiness test — `!conn.saveData`
		// — would read an ABSENT saveData (undefined) as "false" and promote an API
		// that never reported the signal all the way to Level B. §4.4 forbids exactly
		// that inference: "Absence of the signal is not permission — where the Network
		// Information API is unavailable, an implementation MUST stay at Level A",
		// which is "the same fail-safe direction §2.4 takes on suppression: the unknown
		// case resolves to the cheaper behaviour, never the more expensive one."
		if (conn && conn.saveData === false && conn.effectiveType === '4g') return 'buffer';
		return 'metadata';
	}

	// The ±1 adjacency, derived from PREWARM_OFFSETS rather than restated as a
	// radius, so the release window can never disagree with the warm set. The active
	// slide is inside its own window by definition — it is not warm, but including it
	// keeps this a straightforward "is this index in the adjacency set" question.
	function isWithinPrewarmWindow(index, activeIndex) {
		if (index === activeIndex) return true;
		for (var k = 0; k < PREWARM_OFFSETS.length; k++) {
			if (index === activeIndex + PREWARM_OFFSETS[k]) return true;
		}
		return false;
	}

	// §4.4: "A warmed slide that leaves the ±1 adjacency MUST be released — its media
	// element torn down or its source detached — and warmed elements MUST NOT
	// accumulate beyond the adjacency set." (Tariq's blocking condition B2 on the
	// spec.) The adapter's own destroy() does the teardown properly — pause,
	// removeAttribute('src'), load(), remove() — which is what actually releases the
	// buffers rather than merely orphaning a node that keeps downloading.
	//
	// Resetting `tier` to -1 is as important as the teardown: it returns the slide to
	// "not instantiated", which is what lets ensureSlideMedia() re-run the chain from
	// tier 1 if the visitor ever does arrive here (§4.4 rule 2).
	//
	// `terminalReported` is deliberately NOT reset — it is a once-per-session
	// analytics latch, and a release is not a new session.
	function releaseWarmSlide(slide) {
		if (!slide || !slide.warm) return;
		clearWatchdog(slide);
		if (slide.inst && slide.inst.destroy) slide.inst.destroy();
		slide.inst = null;
		slide.caps = NO_CAPS;
		slide.tier = -1;
		slide.playingSeen = false;
		slide.warm = false;
		if (slide.stage) slide.stage.innerHTML = '';
	}

	// Sweeps warm elements that have fallen outside the adjacency set. The
	// `slide.warm` gate is what keeps this surgical: an ACTIVATED slide that is now
	// off-screen is never released here, because §4.4 requires off-screen slides be
	// "paused, not destroyed, so a one-step back-swipe is instant". Only speculative
	// media is reclaimed — which is also exactly the accumulation SMASH-1979
	// introduces and therefore owes a bound.
	function releaseWarmOutsideWindow(activeIndex) {
		slides.forEach(function (slide, i) {
			if (!slide.warm) return;
			if (isWithinPrewarmWindow(i, activeIndex)) return;
			releaseWarmSlide(slide);
		});
	}

	function prewarmSlide(index, level) {
		var slide = slides[index];
		// Off either end of the track. §2.3 clamps navigation the same way, and
		// §4.4 is explicit that "declining to pre-warm is not a failure" — nothing is
		// emitted and nothing is logged.
		if (!slide) return;
		// Already instantiated, by a previous warm or by an earlier activation.
		// Both must be left alone, for different reasons: re-warming is pointless,
		// and rebuilding an activated slide's element would restart the playback
		// §4.4 preserves by pausing rather than destroying.
		if (slide.tier !== -1) return;
		// Ask the chain which tier this post would actually get, then warm ONLY if
		// that tier's transport is an HTMLMediaElement. Routing through
		// nextChainIndex() rather than assuming tier 0 is what makes §5.4 fall out for
		// free: a source tier 1 would decline (no usable videoSrc) resolves to the
		// embed or terminal tier, neither of which is warmable, so "a source tier 1
		// would decline MUST NOT be pre-warmed" needs no separate check. A
		// GDPR-suppressed embed tier is handled by the same call.
		var tier = nextChainIndex(0, slide.post);
		if (!tierIsPrewarmable(tier)) return;

		// ORDERING IS LOAD-BEARING: the flag goes up BEFORE instantiation, never
		// after. instantiateTier() can emit synchronously — instantiatePosterLink()
		// reports `playing` inline, and the terminal branch emits
		// swipeview_terminal_tier — so a flag set afterwards would leave a window in
		// which this slide's emissions reach handleAdapterEvent() unguarded. Unreachable
		// today (the transport check above means only tier 0 gets here, and the native
		// adapter emits nothing during construction), which is exactly why it is
		// written down: the guard costs one line now and survives a tier being added.
		slide.warm = true;
		instantiateTier(slide, index, 0);

		// Level A needs nothing further. instantiateNativeVideo() already builds the
		// element the floor requires — `preload = 'metadata'`, `muted = true`, no
		// play() call anywhere in construction — and pre-warm never invokes
		// inst.play(), so the element is paused, muted and metadata-capped by
		// construction. That "created muted and not playing, WHATEVER the session's
		// mute state is" is §4.4's own emphasis, and the reason it is emphasised is the
		// failure it prevents: §4.2's unmute persistence "attaches to a slide when it
		// BECOMES active, not when it is warmed — applying the session's unmuted state
		// at creation time is how an off-screen slide ends up audible". Note that
		// nothing here reads `userMuted`; that is the mechanism, not an oversight.
		if (level !== 'buffer') return;

		// Level B (§4.4, a MAY): buffer ahead of metadata on a plausibly-fast
		// connection. Written directly on the element because the adapter couples its
		// own `preload = 'auto'` promotion to play() — and play() is the one thing a
		// pre-warm must not do. This is the only place outside the adapter that writes
		// `preload`, and it is reached only for a tier whose transport is an
		// HTMLMediaElement, so `inst.el` is the <video>.
		if (slide.inst && slide.inst.el) slide.inst.el.preload = 'auto';
	}

	// THE single pre-warm entry point. Called from activateSlide() and nowhere else,
	// so "on activation or navigation" is satisfied for every input source at once —
	// wheel, touch, keyboard, open(), and the post-escalation re-activation — without
	// a second trigger that could drift from this one.
	//
	// On the trigger moment: §4.4 phrases the scope as "WHILE the active slide is
	// playing", and this fires at activation rather than on the active slide's
	// `playing` event. Deliberate, and the cheaper direction of the two. A visitor can
	// swipe before the active slide ever reports `playing` — a stalled slide is
	// precisely when a warmed neighbour helps most, and gating on `playing` would
	// withhold the warm exactly then, up to the 4000ms the §5.2 watchdog allows.
	// Level A is metadata-only by construction, which is what makes the earlier
	// trigger affordable: it is not the "three concurrent full downloads" §4.4
	// refuses as a default.
	function prewarmAdjacent(activeIndex) {
		// Release BEFORE warming. The two halves are one lifecycle — §4.4: "The bound
		// is a lifecycle, not just an action" — and releasing first means the count of
		// live warm elements never even momentarily exceeds the adjacency set.
		releaseWarmOutsideWindow(activeIndex);

		var level = prewarmLevel();
		// §4.4 Save-Data: "suppressed entirely — no element instantiated, Level A
		// included". Placed after the release so a visitor who turns Save-Data on
		// mid-session still gets existing warm elements reclaimed rather than frozen
		// in place.
		if (level === 'none') return;

		for (var k = 0; k < PREWARM_OFFSETS.length; k++) {
			prewarmSlide(activeIndex + PREWARM_OFFSETS[k], level);
		}
	}

	// ── Navigation ──────────────────────────────────────────────────────────

	// The JS half of the vh-then-dvh convention documented at the top of
	// css/sbi-quickscroll.css (team feedback 2026-08-24). The track moves one
	// viewport height per slide, so this unit MUST match .sbi-qs-post's height
	// unit. If the CSS moves to dvh and this stays on vh, every slide lands
	// N * (100vh - 100dvh) out of position — invisible on desktop (where the two
	// units are equal) and progressively worse on a phone with every swipe.
	//
	// Two assignments to the same property, vh FIRST: the CSSOM ignores a value
	// it cannot parse, so a browser without dvh support silently keeps the vh
	// offset from the line above. This is the exact equivalent of the
	// stylesheet's duplicate-declaration fallback — that cascade trick isn't
	// available here because jQuery's .css({...}) takes one value per key.
	// SMASH-1978 extends this with an optional px delta for the thumb-follow
	// drag. The drag is a PIXEL quantity (the finger's travel) composed over a
	// VIEWPORT-UNIT base (the slide's rest position), so the two cannot be added
	// in JS — they are added by the browser inside calc(). The fallback-pair
	// discipline above applies to the composed value exactly as it does to the
	// bare one: the vh form is written first, the dvh form second, and a browser
	// that cannot parse dvh silently keeps the vh composition.
	//
	// The sign is normalised into the operator (`- 40px`, never `+ -40px`).
	// calc() does accept a signed operand, but the negative-plus form is the
	// shape engines have historically been picky about, and it costs nothing to
	// emit the unambiguous one.
	function setTrackOffset(vhOffset, pxDelta) {
		var node = $track && $track[0];
		if (!node) return;
		var d = pxDelta || 0;
		// Builds one unit's value. Kept as a local so the composition rule lives
		// in one place, while the two ASSIGNMENTS below stay written out — the
		// vh-then-dvh pair is the mechanism this function exists for, and hiding
		// it inside a loop or a second call would make the ordering invisible at
		// exactly the site whose comment is about that ordering.
		var offset = function (unit) {
			var base = vhOffset + unit;
			// No delta: emit the plain unit form the rest position has always
			// used, so a track at rest carries byte-identical CSS to what shipped
			// before the drag existed.
			if (d === 0) return base;
			return 'calc(' + base + (d < 0 ? ' - ' + Math.abs(d) : ' + ' + d) + 'px)';
		};
		node.style.transform = 'translate3d(0, ' + offset('vh') + ', 0)';
		node.style.transform = 'translate3d(0, ' + offset('dvh') + ', 0)';
	}

	function goToIndex(newIndex, opts) {
		opts = opts || {};
		if (transitioning) return;
		// §2.3: clamped at both ends — out-of-range input is a strict NO-OP,
		// matching the TikTok viewer. The earlier "gentle bounce" (a spec MAY,
		// not a requirement) was removed on maintainer feedback 2026-08-19:
		// its transform re-fired on every key-repeat event — navigate() never
		// arms navLocked for out-of-range targets and bounce never set
		// `transitioning` — so holding ArrowUp on the first reel (or ArrowDown
		// on the last) visibly juddered the track ~30x/sec instead of playing
		// one clean overshoot.
		if (newIndex < 0 || newIndex >= posts.length) return;
		currentIndex = newIndex;
		if (slidesViewed) slidesViewed.add(currentIndex);
		transitioning = true;

		var instant = opts.smooth === false || prefersReducedMotion();
		var translateY = -newIndex * 100;
		// §3.2: reduced motion REMOVES the transition entirely — it does not
		// merely shorten it. `transition: none` (not a smaller duration) is
		// the only thing that satisfies "the slide changes instantly". Set
		// BEFORE the transform so an instant move never animates the first frame.
		$track.css('transition', instant ? 'none' : 'transform ' + TRANSITION_MS + 'ms cubic-bezier(0.22, 0.61, 0.36, 1)');
		setTrackOffset(translateY);
		// ── The commit: the rail lands at rest, INSTANTLY, and stays there ───
		// This is the line Asmita's report is about. The track animates the
		// remaining distance; the rail does not move at all, and updateChrome()
		// on the next line swaps its counts in the same paint. Unconditionally
		// instant — a commit is never the animated case, so this is not gated
		// on reduced motion (setRailTravel is instant for `animate: false`
		// either way).
		//
		// It runs on EVERY navigation path by construction: wheel, key, chevron
		// and drag-commit all route through goToIndex(). A drag-commit is the
		// one that needs it — `dragDeltaPx` is non-zero when the gesture ends,
		// so without this the rail would stay parked mid-drag while the track
		// snapped to the new slide.
		setRailTravel(0, false);

		updateChrome();
		activateSlide(newIndex, false);

		var settle = instant ? 0 : TRANSITION_MS;
		setTimeout(function () { transitioning = false; }, settle);
	}

	// §3.1: a single 420ms cooldown gates every input source (wheel/touch/key),
	// separate from the 320ms transition, so a fast repeat can't outrun it.
	function navigate(delta) {
		if (navLocked) return;
		var target = currentIndex + delta;
		if (target < 0 || target >= posts.length) return; // §2.3 clamp — strict no-op, see goToIndex.
		navLocked = true;
		setTimeout(function () { navLocked = false; }, NAV_COOLDOWN_MS);
		// Same reasoning for the pause glyph: a glyph still dissolving over the
		// slide being swiped away describes a playback state on a video the
		// visitor is no longer looking at.
		clearFlash();
		goToIndex(target);
		emitAnalytics(delta > 0 ? 'swipeview_next' : 'swipeview_prev', { index: currentIndex });
	}

	// Reads the ACTIVE slide's real mute state off its adapter instance, not
	// the `userMuted` intent — see instantiateNativeVideo()'s isMuted() for
	// why those two can diverge. `true` (muted) is the honest advisory
	// default for a slide with no instance yet, or a tier with no real mute
	// control at all (embed / poster-link — see their own isMuted()).
	function realMuted() {
		var slide = slides[currentIndex];
		var inst = slide && slide.inst;
		return inst && inst.isMuted ? inst.isMuted() : true;
	}

	// §6.1/§4.2 (SMASH-1851, mirrors SMASH-1853): the mute button and the
	// "Tap to unmute" pill MUST reflect the media element's ACTUAL muted
	// property, never the `userMuted` intent — Rex-class review demand: a
	// rejected attemptPlay() retry can leave the element muted even though
	// intent never flipped (that per-attempt fallback is deliberate, see
	// attemptPlay()), so rendering off intent alone would let the button
	// claim sound is on when it is not.
	//
	// Called from three places, all needed: the video's own `volumechange`
	// listener (immediate sync the instant the real property changes,
	// however it changed), updateChrome() (every slide/nav/toggle
	// transition), and tick()'s 250ms poll (a defensive backstop matching
	// §6.1's refresh cadence for the rest of the chrome, in case a future
	// browser path changes `.muted` without firing `volumechange`).
	function updateMuteChrome() {
		var slide = slides[currentIndex];
		var caps = (slide && slide.caps) || NO_CAPS;
		var muted = realMuted();

		// Rule 1.20 / §6.2: DISABLED, never omitted. The reference omits the
		// button entirely when the source has no audio, which leaves `m` flipping
		// a state with no control and no audible effect.
		$muteBtn.prop('disabled', !caps.mute);
		// The glyph reports the CURRENT state (crossed speaker == audio is off)
		// while aria-label names the ACTION ("Unmute") — the platform
		// convention, and the reference's own fixed "Toggle sound" reflects
		// neither (spec §4.4 item 2).
		setControlIcon($muteBtn, muted ? 'volumeOff' : 'volumeOn', 20);
		$muteBtn.attr('aria-label', muted ? 'Unmute' : 'Mute');
		// Rule 1.6's inverted paint: MUTED is loud (solid white), UNMUTED is
		// quiet (dark translucent). Driven by an attribute the stylesheet reads,
		// off the REAL sampled state, so rule 1.7a holds — the button paints
		// white whenever the viewer is muted, including when it is muted for a
		// reason the visitor never chose.
		$muteBtn.attr('data-state', muted ? 'off' : 'on');
		$container.attr('data-muted', muted ? 'true' : 'false');

		// Rule 1.7's label gate, and the three-way distinction it exists for.
		// The label may only be out while ALL of these hold:
		//   - the tier HAS a mute control at all (caps.mute) — an embed or
		//     poster tier has no sound to unmute, so an affordance there is a
		//     promise the tier cannot keep (§6.2);
		//   - the viewer is really muted right now;
		//   - sound was REFUSED rather than chosen (autoplayRefused, and NOT
		//     userMuted) — nagging a visitor who deliberately muted is rule
		//     1.7c's explicit "respect the choice";
		//   - the visitor has never successfully unmuted this session
		//     (!unmuteSucceeded) — rule 1.7b's "stops forever once the visitor
		//     unmutes".
		// Any of them failing retracts the label immediately, which is why this
		// is one expression at the render gate rather than four scattered
		// conditions.
		if (!(caps.mute && muted && autoplayRefused && !userMuted && !unmuteSucceeded)) {
			stopSoundHint();
		}
	}

	// ── The label's own timing (rule 1.6, measured) ──────────────────────────
	// Show at +350ms after activation, retract at 4500ms, and replay on each new
	// slide while still in the refused-muted state. Called from activateSlide()
	// so "each new slide" is by construction rather than by a second scheduler.
	function startSoundHint() {
		stopSoundHint();
		var slide = slides[currentIndex];
		var caps = (slide && slide.caps) || NO_CAPS;
		if (!caps.mute || !autoplayRefused || userMuted || unmuteSucceeded || !realMuted()) return;
		soundHintInTimer = setTimeout(function () {
			soundHintInTimer = null;
			// Re-checked at fire time, not only at schedule time: 350ms is long
			// enough for a visitor to have hit the mute button, and a label that
			// slides out after the state it describes has gone is worse than no
			// label.
			if (!realMuted() || userMuted || unmuteSucceeded) return;
			$muteBtn.addClass('sbi-qs-mute-hinting');
			soundHintOutTimer = setTimeout(function () {
				soundHintOutTimer = null;
				$muteBtn.removeClass('sbi-qs-mute-hinting');
			}, MUTE_HINT_OUT_MS - MUTE_HINT_IN_MS);
		}, MUTE_HINT_IN_MS);
	}

	function stopSoundHint() {
		if (soundHintInTimer) { clearTimeout(soundHintInTimer); soundHintInTimer = null; }
		if (soundHintOutTimer) { clearTimeout(soundHintOutTimer); soundHintOutTimer = null; }
		if ($muteBtn && $muteBtn.length) $muteBtn.removeClass('sbi-qs-mute-hinting');
	}

	function updateChrome() {
		// Rule 1.8: the VISIBLE counter is gone (the design has none, and the
		// frame's top-left is deliberately blank). §7.1's position announcement
		// survives AT-only.
		announceLive((currentIndex + 1) + ' of ' + posts.length);
		// ── §7.1 / rule 1.18: non-active slides are INERT ────────────────────
		// `inert` is the right primitive here and `aria-hidden` is not, which is
		// the opposite of the call made for the gesture layer (see its comment):
		// that element must keep pointer interaction, because pointer
		// interaction is its entire purpose. A non-active slide must lose
		// everything — it should not be reachable by Tab, should not be read by
		// AT, and should not be hit-testable. That is exactly `inert`'s
		// definition, and doing it with `aria-hidden` instead would leave
		// focusable links inside a hidden subtree, which is the "Blocked
		// aria-hidden" defect the gesture layer already taught this file.
		//
		// Measured against the reference: 0 of 12 slides inert, 157 focusables
		// in the viewer, and Tab from an open viewer walks 10 grid cards behind
		// the overlay before reaching the first viewer control (spec §4.1 item
		// 2). The design is silent on this because focus management is
		// invisible, so there is nothing to match — this is ours.
		//
		// Set as a PROPERTY, not an attribute, so a browser without `inert`
		// support (Safari < 15.5) simply ignores it rather than inheriting a
		// stray attribute; focusables() already scopes per-slide controls to the
		// active slide, so the fallback behaviour is the status quo rather than a
		// regression.
		$container.find('.sbi-qs-post').each(function () {
			var active = this.getAttribute('data-index') === String(currentIndex);
			this.classList.toggle('sbi-qs-post-active', active);
			this.inert = !active;
		});

		var slide = slides[currentIndex];
		var post = slide && slide.post;
		var caps = (slide && slide.caps) || NO_CAPS;
		$progressBar.css('display', caps.progress ? '' : 'none');

		// ── The session-level CTA's per-slide href (rule IG-6, §6f) ──────────
		// One element, re-pointed on slide change. §6f requires the CTA to be
		// permanent chrome that is never re-rendered or relocated as the tier
		// chain escalates — writing an href satisfies that far more strongly
		// than rebuilding a per-tier link would, because there is only ever one
		// of these and no tier code touches it.
		var href = post && isHttpUrl(post.permalink) ? post.permalink : '';
		if (href) {
			$viewPill.attr('href', href).removeAttr('aria-disabled');
		} else {
			// A post with no safe permalink has nowhere to send anyone. Left in
			// place and marked disabled rather than hidden, so the top row's
			// geometry does not change between slides while swiping.
			$viewPill.attr('href', '#').attr('aria-disabled', 'true');
		}

		// ── The session-level rail's per-slide content (rule IG-3) ───────────
		// Same shape and the same moment as the CTA pill above: one element,
		// re-pointed on slide change. This IS the commit moment — TikTok swaps
		// its counts in the paint the commit lands in, and a mid-transition
		// swap would put the incoming post's figures over the outgoing post's
		// video for the length of the transition.
		updateRail(post);

		// §2.3's end clamp, made visible (rule 1.11's `disabled` at the ends).
		// navigate() already refuses an out-of-range target, so this is
		// presentational and assistive rather than functional — but a chevron
		// that looks live and does nothing is the §6.2 defect class applied to
		// position instead of capability. Also drops the button out of the Tab
		// cycle via focusables()' :not([disabled]) filter, so keyboard users
		// don't land on a dead stop at either end of the track.
		$navPrev.prop('disabled', currentIndex <= 0);
		$navNext.prop('disabled', currentIndex >= posts.length - 1);

		updateMuteChrome();
		syncPlayState();
	}

	// §7.1's polite position announcement (rule 1.8). Guarded against
	// re-writing an unchanged string for the same reason announcePlayState() is:
	// a live region re-announces on every write, so an idempotent write is an
	// audible repetition rather than a no-op.
	function announceLive(text) {
		if (!$live || !$live.length) return;
		if ($live[0].textContent === text) return;
		$live[0].textContent = text; // text node — never markup (§12).
	}

	// Activates (or re-activates, after a fallback escalation) the slide at
	// `index`: lazily builds its media on first visit, plays it, and pauses
	// every other slide WITHOUT destroying it (§4.4 — off-screen slides are
	// paused, not torn down, so a one-step back-swipe is instant).
	function activateSlide(index, reactivateOnly) {
		ensureSlideMedia(index);
		slides.forEach(function (slide, i) {
			if (!slide.inst) return;
			if (i === index) {
				// §4.1/§4.2: play({ muted }) mirrors setMuted(bool) -- muted:true
				// means "play muted". Passing userMuted directly (not negated)
				// is what makes an explicit unmute persist across a swipe; the
				// negated form used to re-mute every newly-activated slide.
				slide.inst.play({ muted: userMuted });
				armWatchdog(slide, i);
			} else if (!reactivateOnly) {
				clearWatchdog(slide);
				slide.inst.pause();
			}
		});
		updateChrome();
		syncCaptionExpansion(index);
		// Rule 1.14: a slide activated from a pre-warm may already have readable
		// intrinsic dimensions, in which case no `loadedmetadata` is coming and
		// the fit has to be decided here instead.
		applyFit(slides[index]);
		// Rule 1.6/1.7b: the label REPLAYS on each new slide while the viewer is
		// still muted because sound was refused, and stops forever once the
		// visitor unmutes. Calling it from the one place that means "a slide
		// became active" is what makes "per slide" structural.
		startSoundHint();
		// §4.4 adjacent pre-warm (SMASH-1979) — LAST, after the active slide has been
		// asked to play. Ordering is the cheap-but-real kind: the active slide's own
		// request goes out first, so a warm fetch never queues ahead of the media the
		// visitor is actually looking at. Also runs the release half, so a slide that
		// just left the ±1 window is reclaimed on the same activation that moved the
		// window past it.
		prewarmAdjacent(index);
	}

	// ── Caption expansion lifecycle (§6.1, rules IG-4/IG-5) ──────────────────
	// Two things changed with the design's ONE-LINE clamp, and the first is easy
	// to get wrong: overflow is now a WIDTH question, not a height one. The
	// three-line clamp used `-webkit-line-clamp`, so overflow showed up as
	// scrollHeight > clientHeight; a single line with `white-space: nowrap` +
	// ellipsis overflows HORIZONTALLY, so the only measurement that detects it is
	// scrollWidth > clientWidth. Keeping the height comparison would have left
	// "more" permanently hidden and silently truncated every long caption — the
	// exact class of silent text loss spec §4.1 item 9 measured in the reference.
	//
	// The reveal is also driven by a CLASS on the caption rather than the
	// button's `hidden` attribute. `hidden` on a flex item is honoured, but the
	// button then also has to be measured to decide whether the text has room
	// for it, and the two-way dependency (button visible -> less width for text
	// -> maybe no overflow -> hide button) oscillates. Measuring the TEXT node's
	// own overflow while the button is display:none breaks the cycle: the answer
	// no longer depends on the answer.
	//
	// §6.1's "expansion never survives a slide change" is enforced by sweeping
	// every non-active slide on every activation, which is what the reference's
	// IG skin fails to do (measured: aria-expanded still true after away-and-back)
	// while his own YouTube skin gets right.
	function syncCaptionExpansion(activeIndex) {
		slides.forEach(function (slide, i) {
			if (!slide.article) return;
			var cap = slide.article.querySelector('.sbi-qs-caption');
			var text = slide.article.querySelector('.sbi-qs-caption-text');
			var btn = slide.article.querySelector('.sbi-qs-caption-more');
			if (!cap || !text || !btn) return;
			if (i !== activeIndex) {
				cap.classList.remove('sbi-qs-caption-expanded');
				text.scrollTop = 0;
				btn.setAttribute('aria-expanded', 'false');
				btn.textContent = 'more';
				return;
			}
			// Active slide: reveal the toggle only for real overflow, measured in
			// the clamped state. An already-expanded caption is left alone on
			// reactivateOnly passes — re-measuring an expanded block would find
			// no horizontal overflow and hide the only way back.
			if (!cap.classList.contains('sbi-qs-caption-expanded')) {
				if (text.scrollWidth > text.clientWidth + 1) {
					cap.classList.add('sbi-qs-caption-has-more');
				} else {
					cap.classList.remove('sbi-qs-caption-has-more');
				}
			}
		});
	}

	// ── Mute / play-pause ───────────────────────────────────────────────────
	// Rex-class review demand (mirrors SMASH-1853): this must flip based on
	// the REAL sampled state (realMuted()), not the `userMuted` intent.
	// After a rejected attemptPlay() retry falls back to muted, intent
	// never flips (by design — §4.2's fallback is per-attempt, not a
	// persisted choice), so the button's own label already correctly says
	// "Unmute" at that point (driven by updateMuteChrome() above). Acting
	// on the same real state the label reads from is what keeps the label
	// and the action in agreement — toggling off the STALE intent instead
	// would silently mute a button that visibly says "Unmute".
	function toggleMute() {
		var slide = slides[currentIndex];
		if (!slide || !slide.caps || !slide.caps.mute) return;
		var shouldUnmute = realMuted();
		userMuted = !shouldUnmute; // record the new explicit choice for future activations (§4.2).
		if (slide.inst && slide.inst.setMuted) slide.inst.setMuted(!shouldUnmute);
		// An explicit unmute is rule 1.7b's "stops forever"; an explicit mute is
		// rule 1.7c's "respect the choice". Either way the label must not be out
		// after the visitor has touched this control, and stopSoundHint() is
		// idempotent so calling it on both legs is simpler than branching.
		stopSoundHint();
		// ── DELIBERATELY DOES NOT record the unmute as SUCCEEDED ─────────────
		// This line used to read `if (shouldUnmute) noteUnmuteSucceeded();` and
		// that was a real defect, found by the live refusal-arm proof: a TAP is
		// not a success. Where autoplay is refused, tapping the chip calls
		// setMuted(false) -> attemptPlay(muted: false), which the browser can
		// refuse just as it refused the first attempt — and the element falls
		// back to muted. Recording success on the tap would then set the
		// "never label again" flag on a viewer that is still silent, removing
		// the only affordance the visitor has left. It is the exact failure the
		// pill's own handler was written to avoid, re-introduced when the pill
		// was folded into this button.
		//
		// noteUnmuteSucceeded() has exactly ONE writer, and it is attemptPlay()'s
		// resolve handler, gated on the element ACTUALLY being unmuted at resolve
		// time (`p.then(function () { if (!v.muted) … })`). A successful tap goes
		// through that path too, so nothing is lost by staying out of it — the
		// flag is set by reality rather than by intent.
		updateChrome();
		dismissCoach();
		emitAnalytics(shouldUnmute ? 'swipeview_unmuted' : 'swipeview_muted', { index: currentIndex });
	}

	// ── Pause glyph (rule 1.10) ──────────────────────────────────────────────
	// REPLACES the 600ms tap-flash. The glyph is no longer an echo of a gesture —
	// it is a STATE readout: a play triangle shown for as long as the slide is
	// paused, however it got paused (tap, Space, or a stalled tier). That is
	// strictly more honest than the flash, which fired on the tap and then
	// vanished whether or not the video actually stopped.
	//
	// Consequence worth naming: the flash was also the confirmation for
	// UNPAUSING, and a state readout cannot be — there is no paused state left
	// to show. Rule 1.10's asymmetric dissolve is what covers that: the glyph
	// animates out over 100ms rather than disappearing, so a resume still gets a
	// visible acknowledgement. `.sbi-qs-flash-on` is the one-shot class that
	// keeps it displayed for exactly that window.
	//
	// Driven off the root's `data-paused` attribute, written from the SAME
	// 250ms-sampled real player state syncPlayState() announces. One source of
	// truth for "is it paused": a separate class toggled by the tap handler would
	// be a second, and this file's history is full of two-source-of-truth bugs.
	function setPaused(paused) {
		if (!$container || !$container.length) return;
		var was = $container.attr('data-paused') === 'true';
		if (was === paused) return;
		$container.attr('data-paused', paused ? 'true' : 'false');
		if (flashOffTimer) { clearTimeout(flashOffTimer); flashOffTimer = null; }
		if (paused) {
			$flash.removeClass('sbi-qs-flash-on');
			return;
		}
		// Unpausing: hold the glyph displayed for exactly the dissolve's length,
		// then drop it.
		$flash.addClass('sbi-qs-flash-on');
		flashOffTimer = setTimeout(function () {
			flashOffTimer = null;
			$flash.removeClass('sbi-qs-flash-on');
		}, FLASH_OUT_MS);
	}

	// Cleared on open/close/navigate as well as by its own timer — a glyph left
	// over from the slide being swiped away describes a playback state on a video
	// the visitor is no longer looking at.
	function clearFlash() {
		if (flashOffTimer) { clearTimeout(flashOffTimer); flashOffTimer = null; }
		if ($flash && $flash.length) $flash.removeClass('sbi-qs-flash-on');
		if ($container && $container.length) $container.attr('data-paused', 'false');
	}

	// ── First-run swipe coach (rule 1.9) ─────────────────────────────────────
	// Touch only, first run only. Both gates are load-bearing: desktop has
	// visible chevrons and needs no swipe instruction (and the CSS makes the same
	// distinction with the same capability query, so the two cannot disagree
	// about which device they are on), and "once ever" is what separates a coach
	// mark from the instructional overlay Aman deliberately removed.
	//
	// localStorage is wrapped because it THROWS rather than returning null in
	// Safari's private mode and under a blocked-site-data policy. A throw there
	// must not take the viewer down with it, and the safe direction on failure is
	// to SHOW the coach: a visitor whose browser cannot persist the flag is
	// better served by seeing a one-line hint again than by never seeing it.
	function coachAlreadySeen() {
		try {
			return !!(window.localStorage && window.localStorage.getItem(COACH_STORAGE_KEY) === '1');
		} catch (e) { return false; }
	}

	function markCoachSeen() {
		try {
			if (window.localStorage) window.localStorage.setItem(COACH_STORAGE_KEY, '1');
		} catch (e) { /* private mode / blocked storage — nothing to record */ }
	}

	function maybeShowCoach() {
		if (hasKeyboardAffordance()) return;   // desktop: the chevrons already say it
		if (coachAlreadySeen()) return;
		if (!$coach || !$coach.length) return;
		$coach.addClass('sbi-qs-coach-visible');
		markCoachSeen();
		// Dismiss listeners go live 350ms AFTER open, so the very tap that opened
		// the viewer cannot dismiss the overlay before it has been read (rule 1.9).
		coachArmed = false;
		coachArmTimer = setTimeout(function () { coachArmTimer = null; coachArmed = true; }, COACH_ARM_MS);
		coachOffTimer = setTimeout(dismissCoach, COACH_AUTO_MS);
	}

	// Called from every input that means "the visitor is now driving" — the same
	// call sites the intro card's dismissHint() had, minus the ones that no
	// longer exist. Named `dismissCoach` rather than kept as `dismissHint`
	// because "the hint" used to mean the four-row card, and a reader coming from
	// the old code should not be able to mistake one for the other.
	function dismissCoach() {
		if (coachOffTimer) { clearTimeout(coachOffTimer); coachOffTimer = null; }
		// Before the arm delay elapses a dismiss request is DEFERRED rather than
		// obeyed: the whole point of the delay is that the opening tap does not
		// count, and dropping the request instead of re-scheduling it would leave
		// the overlay up until the auto-dismiss.
		if (!coachArmed && $coach && $coach.hasClass('sbi-qs-coach-visible')) {
			coachOffTimer = setTimeout(dismissCoach, COACH_ARM_MS);
			return;
		}
		if (coachArmTimer) { clearTimeout(coachArmTimer); coachArmTimer = null; }
		coachArmed = false;
		if ($coach && $coach.length) $coach.removeClass('sbi-qs-coach-visible');
	}

	// §6.1's loading affordance (rule 1.19). An attribute on the frame rather
	// than a class on the spinner: the spinner is one of several things the
	// frame's state drives, and one attribute keeps them from disagreeing.
	function setBuffering(slide, on) {
		if (!slide || !slide.frame) return;
		if (on) {
			slide.frame.setAttribute('data-buffering', 'true');
		} else {
			slide.frame.removeAttribute('data-buffering');
		}
	}

	// ── Smooth progress interpolation (maintainer direction 2026-08-27) ──────
	//
	// THE PROBLEM. The bar was written straight from tick(), i.e. once every
	// CHROME_POLL_MS, so it advanced in visible 250ms steps — four jerks a second
	// against a video that is obviously continuous.
	//
	// THE MECHANISM, taken from SMASH-1853: keep ONE sampling point at the §6.1
	// cadence and let CSS interpolate between samples, rather than adding a
	// second, faster sampler. That matters beyond effort — a rAF loop reading
	// currentTime would be a second source of truth for "where is playback",
	// running at 60Hz next to a 4Hz one, and this file's history is full of
	// exactly that kind of drift. The 250ms poll stays the only reader.
	//
	// TWO DEVIATIONS from the reference, both deliberate:
	//
	//   1. `transform: scaleX()`, not `width`. SMASH-1853 transitions `width`,
	//      which is a LAYOUT property: every frame of a continuously-running
	//      transition costs a layout pass for the life of the viewer. scaleX is
	//      compositor-only. Same visual result, and it is the one property choice
	//      the brief calls out.
	//   2. The transition duration MATCHES the poll interval exactly (the
	//      reference uses 200ms against a 250ms poll, leaving a 50ms hold at the
	//      end of every cycle). Matching means each sample's interpolation ends
	//      precisely as the next arrives, so the motion is continuous rather than
	//      advance-hold-advance. A test asserts the two numbers agree.
	//
	// The cost of interpolating toward the LAST SAMPLE is that the bar trails real
	// playback by up to one poll interval. That is inherent to this mechanism and
	// invisible at 250ms on a progress readout; it is the trade being made, not an
	// oversight.
	//
	// `lastProgressFraction` exists for the discontinuity test below, and is
	// `null` when nothing has been written yet — distinct from 0, which is a real
	// position.
	var lastProgressFraction = null;
	// A backward move larger than this is a DISCONTINUITY (a loop back to the
	// start, a slide change, a re-instantiated tier), not playback. Interpolating
	// through one animates a rewind the visitor never performed — the single most
	// visible way this feature can go wrong. Small enough that ordinary jitter in
	// `currentTime` never trips it, large enough to catch any real reset.
	var PROGRESS_JUMP_EPSILON = 0.02;

	function setProgress(fraction, forceJump) {
		var node = $progressFill && $progressFill[0];
		if (!node) return;
		// Clamp defensively. `duration` can be NaN or Infinity on a stream, and
		// `!(f >= 0)` catches NaN where `f < 0` would not.
		var f = fraction;
		if (!(f >= 0)) f = 0;
		if (f > 1) f = 1;

		// Forward motion interpolates; anything else lands instantly.
		var jump = !!forceJump || lastProgressFraction === null || f < lastProgressFraction - PROGRESS_JUMP_EPSILON;
		lastProgressFraction = f;

		// ORDER AND SAME-TASK are both load-bearing. A transition starts only if
		// the AFTER-change computed style still declares one, so toggling the
		// no-transition class and writing the transform in this one task is what
		// makes the jump instant — and removing the class on the next write is what
		// lets the following sample ease from wherever the jump landed. Split these
		// across tasks (a rAF, a timeout) and the jump animates instead.
		$progressFill.toggleClass('sbi-qs-progress-fill-jump', jump);
		node.style.transform = 'scaleX(' + f + ')';
	}

	// §6.1's play-state readout for assistive tech, replacing the removed
	// button's own accessible name.
	//
	// The `lastPlayStateText` guard is REQUIRED, not tidiness. This is called from
	// tick(), i.e. four times a second, and assigning textContent replaces the
	// text node even when the string is identical — a mutation several screen
	// readers announce. Without the guard a paused video would say "Paused" every
	// 250ms for as long as the viewer is open. SMASH-1853 gets this for free
	// because React diffs the value; an imperative updater has to do it by hand.
	function announcePlayState(text) {
		if (text === lastPlayStateText) return;
		lastPlayStateText = text;
		if ($playState && $playState.length) $playState[0].textContent = text; // text node — never markup (§12).
	}

	// Reads the ACTIVE slide's real playing state and its capability, and keeps
	// the live region in step. One place, called from updateChrome() and tick()
	// — the two updaters that used to swap the button's glyph and label.
	function syncPlayState() {
		var slide = slides[currentIndex];
		var caps = (slide && slide.caps) || NO_CAPS;
		if (!caps.playPause || !slide || !slide.inst || !slide.inst.isPlaying) {
			// §6.2: silent rather than claiming a state no control can honour.
			announcePlayState('');
			// A tier with no play/pause capability has no paused state to
			// report, so rule 1.10's glyph must not claim one either.
			setPaused(false);
			return;
		}
		// Sampled ONCE and held, then read by both channels. Rule 1.10's glyph
		// and §6.1's live region are two renderings of one fact, and sampling
		// twice is how they come to disagree — the same one-sample discipline
		// togglePlay() follows for its own branch.
		var playing = slide.inst.isPlaying();
		announcePlayState(playing ? 'Playing' : 'Paused');
		setPaused(!playing);
	}

	// ── Desktop chevron nav (2026-08-27) ─────────────────────────────────────
	// Reads its direction off `data-nav` so ONE handler serves both buttons,
	// matching the `data-act` convention the mute button already uses.
	//
	// It deliberately does nothing except dismiss the hint and call navigate() —
	// the same two statements the ArrowUp/ArrowDown branches of onKeydown run. Any
	// extra step here (its own cooldown, its own clamp, its own emit) would be a
	// second definition of "advance one slide" that could drift from the keyboard
	// one; a test pins the two paths as producing identical navigate() calls.
	//
	// No preventDefault: unlike the key handler there is no default scroll or
	// page action to suppress on a <button type="button"> click.
	function onNavClick(e) {
		var btn = e && (e.currentTarget || e.target);
		var dir = btn && btn.getAttribute ? btn.getAttribute('data-nav') : null;
		// Anything other than the two known values is ignored rather than guessed
		// at — a mistyped attribute must not silently navigate the wrong way.
		if (dir !== 'prev' && dir !== 'next') return;
		dismissCoach();
		navigate(dir === 'next' ? 1 : -1);
	}

	// The painted stage column, read off the live element. Deliberately NOT
	// recomputed from `min(100vw, 100dvh * 9 / 16)`: that expression already
	// exists in the stylesheet (see .sbi-qs-media), a media query is free to
	// override it, and two copies of a geometry rule drift. .sbi-qs-media is built
	// for every slide regardless of tier, so this is defined on the embed tier too
	// — which matters below, because a tier-dependent close region would be a
	// worse bug than the one being fixed.
	// The PAINTED FRAME's rect, not the media host's. The two resolve to the same
	// box today — the host is `inset: 0` inside the frame — so this is a
	// correctness-of-intent change rather than a behaviour change: what
	// "backdrop" means is "outside the picture", and the picture is the frame.
	// Reading the host would start lying the moment the host gains an inset of
	// its own, and it is the frame that the 8px desktop margins are measured
	// from (rule 1.1).
	function stageRect() {
		var slide = slides[currentIndex];
		if (!slide || !slide.frame) return null;
		var box = slide.frame.getBoundingClientRect();
		return (box.width > 0 && box.height > 0) ? box : null;
	}

	function pointInRect(x, y, box) {
		return !!box && x >= box.left && x <= box.right && y >= box.top && y <= box.bottom;
	}

	// §2 uniform grammar (maintainer direction 2026-08-31): a click on the black
	// surround closes the viewer, as TikTok's does. Everything inside the stage
	// column keeps the tap-to-pause toggle.
	//
	// The boundary is the STAGE COLUMN, not the painted media frame inside it.
	// Those differ whenever the source is not exactly 9:16 — object-fit: contain
	// leaves a band above and below the picture (the same band
	// letterboxBottomBand() measures for the hint card) — and using the painted
	// frame was rejected on two counts:
	//   - The bottom band is where the chrome lives. The caption inherits
	//     pointer-events: none, so a near-miss on it reaches this handler, and
	//     closing the viewer because someone aimed slightly wide of a caption is
	//     a worse defect than the one being fixed.
	//   - It would be tier-dependent. The embed tier is a cross-origin iframe with
	//     no measurable intrinsic size, so letterboxBottomBand() returns 0 there
	//     and the "painted frame" IS the stage box. Identical-looking layouts
	//     would then close in different places depending on which tier the post
	//     resolved to, which is not a grammar anyone can learn.
	// The stage column is the same box on every tier and has no chrome inside it
	// at all (see .sbi-qs-media's comment), so it is the one boundary that is both
	// unambiguous and uniform. On phones the column resolves to 100vw, so there is
	// no surround and this branch never fires — correct, since a full-bleed viewer
	// has no backdrop to click.
	//
	// ONE CARVE-OUT: the chevron cluster. .sbi-qs-nav sits 60px OUTSIDE the
	// column's edge, and its container is deliberately pointer-events: none so the
	// 12px gap between the two discs does not swallow swipe-starts (§6.3). That
	// made the gap fall through to a harmless tap-to-pause; letting it fall through
	// to close() would turn a 12px vertical near-miss on "next" into losing your
	// place in the track. The cluster's own box is therefore excluded. It needs no
	// visibility check: the cluster is display: none on touch viewports, and a
	// display: none element reports a 0x0 rect that contains no point, so the
	// carve-out self-disables exactly where the chevrons do not exist.
	//
	// Every genuine control (close, mute, chevrons, unmute pill, caption expander)
	// declares pointer-events: auto and so is never seen by this handler at all —
	// their clicks are unaffected by any of this.
	// ── Control dead space (cross-viewer alignment, 2026-09-10) ───────────────
	// The rail column and the chevron cluster, as BOUNDING BOXES rather than as
	// their individual controls. A point in here is inside a region the visitor
	// reads as "the controls" but is not on one of them — the 18px gaps between
	// rail glyphs, the rail's 18px of bottom padding, the 12px between the two
	// chevron discs.
	//
	// Such a point now does NOTHING: it neither dismisses the viewer nor toggles
	// playback. That is an orchestrator call for the uniform contract, made
	// after Facebook reproduced Asmita's "the like icon acts as play/pause"
	// report as a NEAR-MISS — a tap in the 16px strip between its rail items
	// fell through and paused the reel. FB now has `pointIsInControlDeadSpace()`
	// and Instagram mirrors it.
	//
	// It REVERSES a conclusion I recorded two commits ago, and the reversal is
	// the interesting part, so it is worth writing down rather than quietly
	// overwriting: I had argued that a carve-out's job is "do not dismiss" and
	// never "do not pause", on the grounds that dismissal is destructive and
	// unrecoverable while pausing is neither. That reasoning is sound about
	// CONSEQUENCE and wrong about INTENT. Someone aiming at a 26px bare glyph
	// and missing it by eight pixels did not intend to pause the reel; they
	// intended to hit the glyph. Sizing the response to the damage rather than
	// to the evident intent is what made an 18px gap behave like the middle of
	// the video, and "harmless" is not the same as "wanted".
	//
	// The MEDIA still toggles on tap, which is the whole point of the
	// distinction: dead space is the gaps inside a control cluster, not the
	// picture.
	// A `display: none` element reports a 0x0 rect, and pointInRect() is
	// inclusive on all four edges — so a degenerate rect sitting at the origin
	// "contains" the point (0, 0). Harmless for a cluster positioned out at
	// x 954, which is why it went unnoticed; not harmless on a touch viewport,
	// where a hidden cluster's rect really is 0x0 at 0,0 and (0, 0) is the
	// frame's own top-left corner. A hidden cluster must carve out nothing at
	// all, which is what the self-disable checks have always claimed.
	function rectHasArea(box) {
		return !!box && box.width > 0 && box.height > 0;
	}

	function pointIsInControlDeadSpace(x, y) {
		// Session-level, so it hangs off the container.
		var nav = $container.find('.sbi-qs-nav').get(0);
		var navBox = nav ? nav.getBoundingClientRect() : null;
		if (rectHasArea(navBox) && pointInRect(x, y, navBox)) return true;
		// ALSO session-level since SMASH-1851, and this lookup INVERTED with
		// that change: it used to have to start from `slides[currentIndex]`
		// because a container-wide query would return whichever slide's column
		// came first in the DOM — the wrong box, and one that moved under a
		// drag. There is exactly one column now, so the container query is the
		// only correct one and the per-slide query would throw or find nothing.
		//
		// `getBoundingClientRect()` stays the measurement, and now for a second
		// reason as well as the first: it already accounts for the rail's own
		// drag-follow transform (setRailTravel), so the carve-out tracks the
		// finger during a drag instead of guarding the resting rect.
		var railcol = $container.find('.sbi-qs-railcol').get(0);
		var railBox = railcol ? railcol.getBoundingClientRect() : null;
		if (rectHasArea(railBox) && pointInRect(x, y, railBox)) return true;
		return false;
	}

	function clickIsOnBackdrop(x, y) {
		var stage = stageRect();
		if (!stage) return false;
		if (pointInRect(x, y, stage)) return false;
		// The near-miss carve-outs, now shared with the pause path above rather
		// than restated here. Sharing the predicate is what stops dismissal and
		// pausing disagreeing about where the controls are — they were two
		// separate opinions for exactly one commit, and that was one too many.
		//
		// On desktop both clusters sit OUTSIDE the frame (the rail column at
		// x 954.6-998.6 against a frame ending at 938.7), so without this every
		// pixel of them would be backdrop. On touch the rail is an in-frame
		// overlay and the frame check above already covers it.
		if (pointIsInControlDeadSpace(x, y)) return false;
		return true;
	}

	function onGestureClick(e) {
		if (suppressTap) {
			suppressTap = false;
			return;
		}
		// A click with no usable coordinates (a programmatic .click(), a synthetic
		// event) falls through to the toggle rather than guessing at a position —
		// again the fail-safe direction, since one of the two outcomes is
		// destructive and the other is not.
		if (e && typeof e.clientX === 'number' && typeof e.clientY === 'number') {
			// Dead space FIRST, and the order is the mechanism: a point inside a
			// control cluster but on no control must fall out here before either
			// action is considered, so neither the dismiss branch nor the toggle
			// below can claim it. Checking it after clickIsOnBackdrop() would
			// work only because that function happens to carve the same rects —
			// this way the two cannot drift.
			if (pointIsInControlDeadSpace(e.clientX, e.clientY)) return;
			if (clickIsOnBackdrop(e.clientX, e.clientY)) {
				close();
				return;
			}
		}
		togglePlay();
	}

	function togglePlay() {
		var slide = slides[currentIndex];
		if (!slide || !slide.inst) return;
		dismissCoach();
		if (slide.caps && !slide.caps.playPause) return; // Disabled, never silently inert (§6.2).
		// Resolved ONCE, before anything acts on it, and reused for both the flash
		// and the branch below. Sampling `isPlaying()` twice — once to pick the
		// glyph and once to pick the action — is how the picture and the behaviour
		// come to disagree: pause() and play() both change what the second read
		// would return.
		var willPlay = !(slide.inst.isPlaying && slide.inst.isPlaying());
		// Rule 1.10: there is no flash to fire here any more. The glyph is a
		// STATE readout now, so updateChrome() -> syncPlayState() at the end of
		// this function is what shows or dissolves it — off the REAL post-toggle
		// state rather than off the intent this handler is acting on. That also
		// retires the §6.2 concern the old call site carried: a tier with no
		// playPause capability reports no paused state, so nothing can be
		// promised that the tier cannot honour.
		if (!willPlay) {
			clearWatchdog(slide);
			slide.inst.pause();
		} else {
			// Same fix as activateSlide() above -- pass userMuted, not its negation.
			slide.inst.play({ muted: userMuted });
			armWatchdog(slide, currentIndex);
		}
		updateChrome();
	}

	// ── Onboarding hint ─────────────────────────────────────────────────────
	// ── Wheel (rule 1.16 — the reference's tuning, adopted) ──────────────────
	// The old shape fired on any single event whose |deltaY| cleared 25, then
	// locked for 550ms. On a trackpad that reads the INERTIA TAIL as fresh
	// intent: one flick emits a long decaying burst, several events of which
	// clear any per-event threshold, so once the lock expired mid-tail the
	// remaining momentum moved another slide. Aman's commit for this says it
	// plainly — "one slide per gesture, inertia tail ignored" — and the video
	// notes flag it as non-obvious and easy to lose.
	//
	// The replacement accumulates, and the three numbers work as a set:
	//   - the accumulator RESETS when the gap since the last event exceeds
	//     WHEEL_GAP_MS. That gap is what "the gesture ended" actually looks
	//     like; a decaying tail keeps firing inside it, a deliberate second
	//     scroll does not.
	//   - one slide fires when |acc| clears WHEEL_THRESHOLD, and the accumulator
	//     is zeroed so the rest of the same gesture cannot add to it.
	//   - after firing, nothing else fires until BOTH a real gap has been seen
	//     AND WHEEL_MIN_INTERVAL_MS has passed. The AND is the point: a time
	//     lock alone is what let the tail through, and a gap check alone would
	//     let a fast deliberate double-scroll outrun the transition.
	//
	// `ctrlKey` is ignored because that is a pinch-zoom on a trackpad, not a
	// scroll — hijacking it would break the browser's own zoom inside a viewer
	// that has already taken over the page.
	function onWheel(e) {
		e.preventDefault();
		if (e.ctrlKey) return;
		var now = Date.now();
		var gap = now - wheelLastAt;
		if (gap > WHEEL_GAP_MS) {
			wheelAcc = 0;
			// A genuine gap is also what releases the post-fire lock.
			wheelLock = false;
		}
		wheelLastAt = now;
		if (wheelLock) return;
		if (now - wheelFiredAt < WHEEL_MIN_INTERVAL_MS) return;
		wheelAcc += e.deltaY;
		if (Math.abs(wheelAcc) < WHEEL_THRESHOLD) return;
		var dir = wheelAcc > 0 ? 1 : -1;
		wheelAcc = 0;
		wheelLock = true;
		wheelFiredAt = now;
		dismissCoach();
		navigate(dir);
	}

	function resetWheel() {
		wheelAcc = 0;
		wheelLastAt = 0;
		wheelFiredAt = 0;
		wheelLock = false;
	}

	// ── Thumb-follow drag (SMASH-1978) ──────────────────────────────────────

	// One slide's height in px — the unit both the clamp and the area rule are
	// expressed in. Measured off the live element rather than derived from
	// window.innerHeight: the post IS the thing being translated, its height is
	// the `100dvh` the stylesheet resolved, and offsetHeight is unaffected by the
	// track's transform. innerHeight is only the fallback for a slide that has
	// not been laid out yet.
	function slideHeightPx() {
		var slide = slides[currentIndex];
		var h = (slide && slide.article) ? slide.article.offsetHeight : 0;
		return h > 0 ? h : (window.innerHeight || 0);
	}

	// §2.3 clamp, applied to the LIVE drag rather than only to the commit. Two
	// separate limits, both normative rather than cosmetic:
	//
	//  1. Ends of the track. At the first slide the track may not move DOWN and
	//     at the last it may not move UP, because there is nothing there — the
	//     spec makes the clamp normative and the bounce only a MAY, and this
	//     file's own history removed an edge bounce for juddering. Letting the
	//     drag path reveal empty space would reintroduce that overshoot by the
	//     back door, so the clamp lives here, not in the release handler.
	//
	//  2. One slide per gesture. The delta is capped at a single slide height so
	//     a long drag can never show slide+2 and then snap back to slide+1. This
	//     is the one place the follow stops being strictly 1:1 with the finger,
	//     and it is deliberate: 1:1 holds throughout the range a gesture can
	//     actually commit to, and native players clamp the same way.
	function clampDragDelta(fingerDy) {
		var h = slideHeightPx();
		var d = fingerDy;
		if (h > 0) d = Math.max(-h, Math.min(h, d));
		// Dragging up (negative) reveals the NEXT slide; impossible at the end.
		// §2.3's strict clamp: no wrap, no rubber-band, a hard no-op.
		if (dragBaseIndex >= posts.length - 1 && d < 0) return 0;
		// Dragging down (positive) reveals the PREVIOUS slide; impossible at 0.
		if (dragBaseIndex <= 0 && d > 0) {
			// ── Pull-to-close's ONLY concession to the clamp (rule 1.16) ─────
			// This used to be a hard 0 — the track did not move at all.
			// Pull-to-close needs the gesture to be legible WHILE it happens, so
			// the track now follows a little and then returns: a fraction of the
			// finger's travel, capped just past the release threshold.
			//
			// Deliberately NOT a 1:1 follow, and that is the whole difference
			// between this and the rubber-band bounce that was removed at
			// da3aeb4a. The ratified clamp feel is "the track does not move
			// where there is nothing to move to"; a damped, capped follow reads
			// as RESISTANCE rather than as travel, so it acknowledges the
			// gesture without implying there is a slide above. The strict clamp
			// at the LAST slide is untouched, because nothing is bound to it.
			return Math.min(d * PULL_FOLLOW_RATIO, PULL_CLOSE_PX + 20);
		}
		return d;
	}

	// THE one place tap suppression is captured (2026-08-27). Every path that ends
	// a gesture routes through here, which is what makes "a drag never toggles
	// playback" a property of ending a drag rather than something each call site
	// has to remember — see `suppressTap` for the defect that shape prevents.
	function resetDrag() {
		suppressTap = dragging;
		touchStartY = null;
		dragging = false;
		dragDeltaPx = 0;
	}

	// Return the track to the slide it started from, animated (or not, under
	// reduced motion — the release snap is where §3.2 applies; the follow-drag
	// itself is direct manipulation and is never animated either way).
	function settleBack() {
		var instant = prefersReducedMotion();
		$track.css('transition', instant ? 'none' : 'transform ' + TRANSITION_MS + 'ms cubic-bezier(0.22, 0.61, 0.36, 1)');
		setTrackOffset(-currentIndex * 100, 0);
		// The ONE caller that animates the rail. A drag that did not commit
		// returns to rest, and the rail returns with the track over the same
		// duration and the same easing — the release snap is exactly where §3.2
		// applies, so setRailTravel() drops it under reduced motion.
		setRailTravel(0, !instant);
	}

	function onTouchStart(e) {
		// Single finger only (2026-08-27, mirrors SMASH-1853). A second touch is a
		// pinch or a stray palm, and this handler used to read `e.touches[0]`
		// unconditionally — so a second finger landing mid-drag re-based the
		// gesture on that finger's Y and the track lurched by the distance between
		// the two contacts.
		//
		// Ending the drag here also captures the tap suppression (resetDrag does
		// it), which is the half SMASH-1853 shipped broken: an aborted pinch that
		// had already travelled is not a tap, but it can still deliver a
		// synthesised click, and that click used to toggle playback.
		if (!e.touches || e.touches.length !== 1) {
			if (touchStartY !== null) {
				var wasDragging = dragging;
				resetDrag();
				// An abort expresses no destination, so the track returns — the
				// same treatment onTouchCancel gives an interrupted gesture.
				if (wasDragging) settleBack();
			}
			return;
		}
		// A drag that cannot commit must not be allowed to follow the finger:
		// mid-transition it would fight the running snap, and inside the nav
		// cooldown (§3.1 / AC 4) it could only ever rubber-band back, which reads
		// as a broken control rather than as a rate limit. Refusing at the START
		// of the gesture is also what keeps the cooldown honest for drags — the
		// same guard navigate() applies to wheel and key input.
		if (transitioning || navLocked) {
			touchStartY = null;
			return;
		}
		touchStartY = e.touches[0].clientY;
		touchStartTime = Date.now();
		dragging = false;
		dragDeltaPx = 0;
		dragBaseIndex = currentIndex;
	}

	// Bound NON-PASSIVELY (see buildContainer) — the same trap class as the
	// wheel handler. Without { passive: false } this preventDefault is a no-op
	// warning and the page scrolls underneath the viewer.
	function onTouchMove(e) {
		if (touchStartY === null) return;
		// `!== 1`, not `!length` (2026-08-27): belt-and-braces behind
		// onTouchStart's single-finger abort, which has already nulled touchStartY
		// by the time a second finger can move. Kept because the two guards fail
		// in different directions — a platform that delivers touchmove for a
		// second contact WITHOUT a preceding touchstart would slip past the other
		// one, and following finger 0 while two are down produces the same lurch.
		if (!e.touches || e.touches.length !== 1) return;
		// Finger delta, DOWN-POSITIVE. The track moves with the finger, so this
		// is also the track's delta — no inversion anywhere on this path.
		var fingerDy = e.touches[0].clientY - touchStartY;
		if (!dragging) {
			if (Math.abs(fingerDy) < DRAG_START_PX) return; // still a tap, not a drag
			dragging = true;
			dismissCoach();
			// The follow must be immediate; any inherited transition would make
			// the track lag the finger.
			$track.css('transition', 'none');
		}
		// Only ever called for a real drag, never for a tap — see DRAG_START_PX.
		e.preventDefault();
		dragDeltaPx = clampDragDelta(fingerDy);
		setTrackOffset(-dragBaseIndex * 100, dragDeltaPx);
		// The rail is outside the track now, so its travel is explicit rather
		// than inherited. Same value, never a second derivation — see
		// setRailTravel(). Never animated here: a transition would make the
		// rail lag the finger.
		setRailTravel(dragDeltaPx, false);
	}

	function onTouchEnd(e) {
		if (touchStartY === null) return;
		var endY = (e.changedTouches && e.changedTouches[0]) ? e.changedTouches[0].clientY : touchStartY;
		// Legacy sign, UP-POSITIVE — kept as-is because the flick semantics below
		// are the ones that shipped. Not the same sign as dragDeltaPx.
		var dy = touchStartY - endY;
		var dt = Date.now() - touchStartTime;
		var wasDragging = dragging;
		var trackDelta = dragDeltaPx;
		resetDrag();

		// The flick accelerator: the pre-SMASH-1978 rule, unchanged — a short,
		// fast swipe past 60px advances. It is a VELOCITY path (distance within a
		// time budget), not the "fixed distance threshold" the ticket rules out
		// for the snap decision, and it is retained because every native player
		// commits on a quick flick that never travels half the screen. Composed
		// with the area rule below as an OR, so the area rule alone decides slow
		// drags and the flick alone decides fast short ones.
		var isFlick = dt <= SWIPE_MAX_DURATION_MS && Math.abs(dy) >= SWIPE_THRESHOLD_PX;

		if (!wasDragging) {
			// No follow ever started (a tap, or a sub-deadzone nudge). Behave
			// exactly as this handler did before the drag existed.
			if (!isFlick) return;
			dismissCoach();
			navigate(dy > 0 ? 1 : -1);
			return;
		}

		// A follow-drag happened. Decide by AREA: the incoming slide has the
		// majority of the viewport once the track has moved more than half a
		// slide. `trackDelta` is already end-clamped, so a drag at either end is
		// zero here and correctly falls through to settleBack().
		// ── Pull-to-close (rule 1.16) ───────────────────────────────────────
		// Checked BEFORE the snap decision, because the two are mutually
		// exclusive and this one is the more specific: it fires only from slide
		// 0, only on a downward gesture, and only past its own threshold —
		// exactly the conditions under which the snap has nowhere to go.
		//
		// Measured against the FINGER's travel (`dy`), not the track's damped
		// follow: the threshold is a statement about the gesture the visitor
		// made, and clampDragDelta() deliberately moves the track less than the
		// finger at this end. Using the track's delta would make the real
		// threshold 140 / 0.35 = 400px of finger travel.
		//
		// `dy` is start-minus-end, so a DOWNWARD drag is negative — hence the
		// negation. The reference's measured behaviour is 130 no / 145 yes,
		// hence a strict greater-than.
		if (pullToCloseArmed(-dy)) {
			emitAnalytics('swipeview_pull_close', { index: currentIndex });
			close();
			return;
		}
		var h = slideHeightPx();
		var moved = Math.abs(trackDelta);
		var areaSaysAdvance = h > 0 && moved > h * DRAG_SNAP_AREA_FRACTION;

		if (moved > 0 && (areaSaysAdvance || isFlick)) {
			// Negative track delta = dragged UP = next slide. Routed through
			// navigate() rather than goToIndex() so a drag-commit is a first-class
			// navigation: same cooldown, same stale-pill reset, same analytics,
			// and the same slide-change side effects (chrome, media activation,
			// caption collapse) — identical by construction rather than by
			// duplicated bookkeeping.
			navigate(trackDelta < 0 ? 1 : -1);
		} else {
			settleBack();
		}
	}

	// An interrupted gesture (system gesture, call, extra finger) must not leave
	// the track parked mid-drag.
	// Rule 1.16's conditions, in one predicate so a test can exercise the RULE
	// rather than the handler: downward travel past the threshold, from the FIRST
	// slide, with the track at rest. The reference's third condition is
	// "scrollTop === 0", which is its native scroller's way of saying the same
	// thing our `!transitioning` does.
	function pullToCloseArmed(downwardPx) {
		if (currentIndex !== 0) return false;
		if (transitioning) return false;
		return downwardPx > PULL_CLOSE_PX;
	}

	function onTouchCancel() {
		if (touchStartY === null) return;
		var wasDragging = dragging;
		resetDrag();
		if (wasDragging) settleBack();
	}

	function onKeydown(e) {
		if (!$container || !$container.hasClass('sbi-qs-active')) return;
		switch (e.key) {
			case 'Escape':
				e.preventDefault(); close(); break;
			// Rule 1.17: the existing map plus `j`/`k`, a strict superset. The
			// reference binds j/k and NOT PageUp/PageDown; §3.1 requires
			// PageUp/PageDown; both are cheap, so both ship. `j`/`k` is the
			// vi/Gmail/Reddit idiom for next/previous, and it is case-insensitive
			// for the same reason `m` is — Shift or caps lock must not silently
			// disable a shortcut.
			case 'ArrowDown':
			case 'PageDown':
			case 'j':
			case 'J':
				e.preventDefault(); dismissCoach(); navigate(1); break;
			case 'ArrowUp':
			case 'PageUp':
			case 'k':
			case 'K':
				e.preventDefault(); dismissCoach(); navigate(-1); break;
			case ' ':
				e.preventDefault(); togglePlay(); break;
			case 'm':
			case 'M':
				toggleMute(); break;
			case 'Tab':
				trapFocus(e); break;
		}
	}

	// §7.1 focus trap: the chrome PLUS the active slide's own focusable content
	// (its "View on Instagram" link — the terminal tier's only action) — never
	// the whole track, which would leak focus into off-screen slides.
	//
	// Rex review (SMASH-1851): .sbi-qs-unmute-pill is a real <button>, so it
	// IS in the document's native tab order on its own — but trapFocus()
	// below intercepts every Tab keypress and cycles ONLY through this
	// list, so a control left out of it is unreachable by keyboard even
	// though it's a genuine focusable element. Listing it here (rather than
	// giving it a bespoke visibility check) is sufficient on its own: the
	// offsetParent filter below already drops anything not actually
	// rendered, and the pill is `display: none` except when armed+muted
	// (see updateMuteChrome()) — so it silently drops out of the cycle
	// whenever it isn't visible, and rejoins the moment it is.
	// `.sbi-qs-actions button:not([disabled])` is GONE as of 2026-08-27: the
	// action stack held only the play/pause button by then, and removing that
	// button removed the container with it. Every surviving control is now named
	// individually, which is the shape this list should have had all along — a
	// group selector silently stops reaching a control that gets re-parented, and
	// that is precisely how the mute button became keyboard-unreachable for one
	// commit (invisible in testing, because it kept working under a mouse).
	//
	// There is deliberately NO focusable play/pause control left. The action
	// remains on Space (see onKeydown, which is bound at document level and so
	// fires regardless of where focus sits) and the STATE is announced through the
	// .sbi-qs-playstate live region. A screen-reader-only BUTTON was considered
	// and rejected: it would be an invisible Tab stop for sighted keyboard users,
	// trading one a11y defect for another, and it would diverge from SMASH-1853's
	// resolution of the identical problem.
	// The chevrons are named individually too, for the same reason and with the
	// same :not([disabled]) filter — they are disabled at the ends of the track
	// (updateChrome), and on a touch viewport they are `display: none`, which the
	// offsetParent filter below drops from the cycle without needing a second
	// capability check here.
	function focusables() {
		// Session-level controls, in DOM order. The unmute PILL is gone (rule 1.6
		// folds its job into the mute button's own expanding label, which is not
		// a separate focus stop — the label is aria-hidden and the button it
		// lives in was always in this list).
		var items = $container.find('.sbi-qs-mute:not([disabled]), .sbi-qs-view-on-ig:not([aria-disabled="true"]), .sbi-qs-nav-prev:not([disabled]), .sbi-qs-nav-next:not([disabled]), .sbi-qs-close').toArray();
		var $active = $container.find('.sbi-qs-post-active');
		if ($active.length) {
			items = items.concat($active.find('a[href], button:not([disabled])').toArray());
		}
		// ── The rail, appended LAST and deliberately as a separate step ──────
		// The rail's links became session-level in SMASH-1851, so they are no
		// longer inside `$active` and would otherwise drop out of the trap
		// entirely — a control that is visible, clickable and unreachable by
		// Tab.
		//
		// They are collected SEPARATELY rather than folded into the session
		// selector above, and the ordering is the reason. That selector is one
		// jQuery `.find()`, which returns DOCUMENT order, not selector order —
		// so adding the rail there would splice its items in wherever the
		// column happens to sit in the DOM. Concatenating here instead keeps
		// the Tab cycle byte-identical to what shipped: mute -> CTA pill ->
		// chevrons -> close -> the slide's own author / Follow / more -> the
		// rail's comment and View. Same sequence as when the rail was the last
		// thing inside the active article.
		//
		// A hidden item (no figure, no permalink) contributes nothing: `hidden`
		// gives it no offsetParent, and the filter below drops it — the same
		// mechanism that already keeps the touch-only "View" item out of the
		// desktop cycle.
		items = items.concat($container.find('.sbi-qs-railcol a[href]').toArray());
		return items.filter(function (node) { return node.offsetParent !== null || node === document.activeElement; });
	}

	function trapFocus(e) {
		var items = focusables();
		if (!items.length) return;
		var i = items.indexOf(document.activeElement);
		e.preventDefault();
		var next = e.shiftKey
			? (i <= 0 ? items.length - 1 : i - 1)
			: (i === items.length - 1 || i === -1 ? 0 : i + 1);
		items[next].focus();
	}

	// ── Open / close ────────────────────────────────────────────────────────

	// `opener` is passed in explicitly (§7.1) — the anchor that was actually
	// clicked — rather than inferred from document.activeElement, which Safari
	// in particular does not move focus to on a link click.
	function open(feedPosts, startIndex, opener, embedSuppressed) {
		if ($container && $container.hasClass('sbi-qs-active')) return;
		posts = feedPosts;
		if (!posts.length) return;

		suppressEmbedTier = !!embedSuppressed;
		slidesViewed = new Set();

		buildContainer();
		renderPosts();

		transitioning = false;
		navLocked = false;
		// A gesture interrupted by the viewer closing (or a session that ended
		// mid-drag) must not leave drag state armed for the next open().
		resetDrag();
		// resetDrag() sets `suppressTap` from whatever `dragging` was, so clear it
		// explicitly here: a session that ended mid-drag would otherwise open the
		// NEXT one primed to swallow its first genuine tap.
		suppressTap = false;
		clearFlash();
		stopSoundHint();
		resetWheel();
		lastPlayStateText = null; // Fresh session — re-announce the first real state.
		// Fresh session — the first write must LAND rather than ease in from
		// wherever the last session's bar happened to stop. The backward-move test
		// in setProgress() would usually catch this on its own; stating it here
		// makes "a session starts from nothing" an invariant rather than a
		// consequence of the previous session's final position.
		lastProgressFraction = null;
		// §4.2 revision (SMASH-1851, mirrors SMASH-1853 "sound-on-open"):
		// open() is itself a click — a qualifying gesture — so attempt
		// UNMUTED by default. The only writer of `true` from here on is an
		// explicit mute action (toggleMute / the mute button).
		userMuted = false;
		// Per-session, not per-slide: the point of the flag is that ONE proven
		// unmute settles the question for the rest of this viewing. navigate()
		// deliberately does NOT clear it —
		// that is what "never re-shows" means. A fresh open() is a fresh session,
		// and the browser's audio decision may genuinely have changed by then.
		unmuteSucceeded = false;
		// Rule 1.7: a fresh session has not been refused sound yet, so the label
		// starts unarmed even if a previous session on this page was refused —
		// the browser's policy can change between opens (a visitor who has now
		// interacted with the page gets a different answer).
		autoplayRefused = MUTED_FIRST;
		openerEl = opener || null;

		$container.attr('data-muted', 'true');
		$container.attr('data-paused', 'false');
		$body.addClass('sbi-qs-scroll-locked');
		$container.addClass('sbi-qs-active');

		currentIndex = Math.max(0, Math.min(startIndex || 0, posts.length - 1));
		slidesViewed.add(currentIndex);
		goToIndex(currentIndex, { smooth: false });

		pollTimer = setInterval(tick, CHROME_POLL_MS);
		// Rule 1.9's first-run coach. After goToIndex(), so the frame the overlay
		// covers is already laid out.
		maybeShowCoach();

		requestAnimationFrame(function () {
			// Rule 1.13's 180ms fade-in. The class has to land in a SEPARATE
			// frame from `.sbi-qs-active`: a transition needs a rendered starting
			// value, and an element that was `display: none` in the same frame
			// has none, so setting both together snaps to full opacity with no
			// fade. The focus move rides this frame for the same reason — the
			// element has to be rendered to be focusable.
			$container.addClass('sbi-qs-visible');
			var closeBtn = $container.find('.sbi-qs-close').get(0);
			if (closeBtn) closeBtn.focus();
		});

		emitAnalytics('swipeview_opened', { index: currentIndex, total: posts.length });
	}

	function close() {
		if (!$container || !$container.length || !$container.hasClass('sbi-qs-active')) return;
		clearInterval(pollTimer);
		pollTimer = null;
		slides.forEach(function (slide) {
			clearWatchdog(slide);
			if (slide.inst && slide.inst.destroy) slide.inst.destroy();
			// §4.4 (SMASH-1979): close() is the outer bound of the warm lifecycle.
			// destroy() above already releases the buffers for warm and activated
			// elements alike — this drops the now-dead references so nothing can read
			// a destroyed instance, and returns every slide to "not instantiated" so a
			// re-open re-evaluates each chain from tier 1.
			//
			// Belt-and-braces rather than load-bearing today: open() calls
			// renderPosts(), which rebuilds `slides` wholesale, so no flag survives a
			// session boundary by this route either. Written anyway because the
			// alternative is a teardown whose correctness depends on a caller two
			// functions away rebuilding the array — and `warm` in particular gates
			// emission isolation, which is not a property to leave resting on that.
			slide.inst = null;
			slide.tier = -1;
			slide.warm = false;
		});
		$container.removeClass('sbi-qs-active sbi-qs-visible');
		$body.removeClass('sbi-qs-scroll-locked');

		// SMASH-1978: the gesture layer's touch listeners stay bound — close()
		// DEACTIVATES the container, it never tears it down — so a finger still on
		// the screen at close time can still deliver a trailing touchend here.
		// Leaving drag state armed means onTouchEnd's `touchStartY === null` bail
		// does not fire, and the release runs its full commit path: navigate() on a
		// viewer that is already closed, emitting a swipeview_next AFTER this
		// function's own swipeview_closed. navigate() has no active-state guard of
		// its own (deliberately — every other caller is reached only while open),
		// so the reset has to happen here.
		//
		// The realistic trigger is two fingers: one mid-drag, a second tapping
		// close. open() already resets for the NEXT session, but that only covers
		// state leaking ACROSS sessions — this closes the window inside the current
		// one, where the stale event is still in flight.
		//
		// State only, no settleBack(): the track's rest position is re-established
		// by open()'s goToIndex(currentIndex, { smooth: false }), and animating a
		// container that was just deactivated would be work nobody can see.
		resetDrag();
		// Every one of these timers OUTLIVES the container — close() deactivates,
		// it never tears the DOM down — so anything still pending would fire its
		// callback into a closed viewer and, worse, leave visible state parked
		// for the next open() to inherit: a half-dissolved pause glyph, a toast,
		// an expanded mute label, or a coach overlay.
		clearFlash();
		stopSoundHint();
		dismissCoach();
		resetWheel();

		emitAnalytics('swipeview_closed', { index: currentIndex, slides_viewed: slidesViewed ? slidesViewed.size : 0 });

		if (openerEl && typeof openerEl.focus === 'function') openerEl.focus();
		openerEl = null;
	}

	// §6.1: play/pause + progress chrome refreshed at least every 250ms.
	function tick() {
		var slide = slides[currentIndex];
		// A slide with no adapter has no position to report. JUMP rather than
		// interpolate: easing a bar back to zero would animate a rewind that never
		// happened.
		if (!slide || !slide.inst) { setProgress(0, true); return; }

		if (slide.inst.progress) {
			var p = slide.inst.progress();
			var frac = (p && p.duration > 0) ? (p.current / p.duration) : 0;
			setProgress(frac);
			$progressBar.attr('aria-valuenow', String(Math.round(frac * 100)));
		} else {
			setProgress(0, true);
		}

		// Defensive backstop alongside the volumechange listener — see
		// updateMuteChrome()'s docblock.
		updateMuteChrome();

		// §6.1's 250ms cadence, now feeding the live region rather than the
		// removed button. announcePlayState() dedupes, so this poll does not
		// re-announce an unchanged state four times a second.
		syncPlayState();

		// The RESIZE path for the one thing that is measured rather than derived
		// in CSS: rule IG-5's "more" reveal, which depends on whether the
		// one-line caption overflows at the CURRENT width. This file binds no
		// resize listener at all — everything else it positions is
		// viewport-relative CSS that reflows on its own — so riding the existing
		// poll avoids a listener plus a debounce for a value that is cheap to
		// re-measure and only changes when the window does. It also backstops the
		// poster tier, whose <img> decode this file has no event bound to.
		syncCaptionExpansion(currentIndex);
	}

	// ── Bootstrap ───────────────────────────────────────────────────────────
	$(function () {
		$body = $('body');
		var enabled = (window.sbiQuickScroll && window.sbiQuickScroll.enabled) || $body.hasClass('sbi-qs-enabled');
		if (!enabled) return;
		log('active — intercepting Reels clicks');

		document.addEventListener('keydown', onKeydown, true);

		// Capture-phase so this fires before the Lightbox2 bubble handler AND
		// before the shoppable/moderation code that also owns tile clicks.
		document.addEventListener('click', function (e) {
			var a = e.target && e.target.closest ? e.target.closest('a.sbi_link_area[data-lightbox-sbi]') : null;
			if (!a) return;
			var $a = $(a);
			if (!isReelAnchor($a)) return;
			var $feed = $a.closest('.sbi');
			if (!$feed.length) return;
			if (isDispatchSuppressed($a, $feed)) return; // §2.2: fall through to the existing lightbox untouched.

			var reels = collectReelsFromFeed($feed);
			if (!reels.length) return; // No eligible Reels survived the guards — let the lightbox handle it.

			var clickedId = $a.attr('data-id');
			var index = 0;
			for (var i = 0; i < reels.length; i++) {
				if (reels[i].id === clickedId) { index = i; break; }
			}
			// The clicked post itself may have been filtered out of `reels` by a
			// guard that only applies to it (shouldn't happen given the guards are
			// feed/anchor-level, but stay defensive rather than opening on the
			// wrong post).
			if (reels[index] && reels[index].id !== clickedId) return;

			e.preventDefault();
			e.stopImmediatePropagation();
			log('opening viewer', clickedId, 'at', index, '/', reels.length);
			open(reels, index, a, feedSuppressesEmbedTier($feed));
		}, true);
	});
})(jQuery);
