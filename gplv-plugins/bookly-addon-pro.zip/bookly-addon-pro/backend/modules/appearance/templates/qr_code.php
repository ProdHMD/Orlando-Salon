<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly
use BooklyPro\Lib\Plugin;
?>
<div class="bookly-js-qr">
    <div class="bookly-image-box">
        <img src="<?php echo plugins_url( 'backend/modules/appearance/resources/images/qr.png', Plugin::getMainFile() ) ?>" alt="">
    </div>
</div>