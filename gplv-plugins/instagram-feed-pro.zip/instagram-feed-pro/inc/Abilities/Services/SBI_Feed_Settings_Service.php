<?php

namespace InstagramFeed\Abilities\Services;

use InstagramFeed\Builder\SBI_Db;
use InstagramFeed\Builder\SBI_Feed_Saver;
use InstagramFeed\Builder\SBI_Feed_Saver_Manager;
use SB_Instagram_Cache;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Reads Feed Builder feeds for the Abilities API.
 *
 * Wraps SBI_Db / SBI_Feed_Saver and REDACTS everything an agent must not see:
 * SBI_Feed_Saver::get_feed_settings() hydrates connected sources with the
 * decrypted access token, so this service never returns raw source rows.
 *
 * @since INSTA_FEED_PRO_SINCE
 */
class SBI_Feed_Settings_Service
{
	const MAX_PER_PAGE = 50;

	/**
	 * Per-feed keys whose change alters which posts are fetched from Instagram.
	 *
	 * @var string[]
	 */
	const RETRIEVAL_KEYS = array('num', 'nummobile', 'sortby', 'imageres', 'stories');

	/**
	 * @param int $page 1-based.
	 * @param int $per_page
	 * @param string $status publish|draft|trash|all (default publish, matching WPForms list-forms).
	 * @return array{feeds: array, total: int, page: int, per_page: int, total_pages: int}
	 */
	public function list_feeds($page = 1, $per_page = 20, $status = 'publish')
	{
		global $wpdb;

		$page     = max(1, (int) $page);
		$per_page = min(self::MAX_PER_PAGE, max(1, (int) $per_page));
		$offset   = ($page - 1) * $per_page;
		$table    = $wpdb->prefix . 'sbi_feeds';

		$status = in_array($status, array('publish', 'draft', 'trash', 'all'), true) ? $status : 'publish';
		if ($status === 'all') {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name is $wpdb->prefix + constant.
			$sql = $wpdb->prepare(
				"SELECT id, feed_name, feed_title, settings, status, last_modified
				FROM {$table} ORDER BY id ASC LIMIT %d OFFSET %d",
				$per_page,
				$offset
			);
		} else {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name is $wpdb->prefix + constant.
			$sql = $wpdb->prepare(
				"SELECT id, feed_name, feed_title, settings, status, last_modified
				FROM {$table} WHERE status = %s ORDER BY id ASC LIMIT %d OFFSET %d",
				$status,
				$per_page,
				$offset
			);
		}
		$rows = $wpdb->get_results($sql, ARRAY_A);

		$feeds = array();
		foreach ((array) $rows as $row) {
			$settings = json_decode($row['settings'], true);
			$settings = is_array($settings) ? $settings : array();
			$feeds[]  = array(
				'id'            => (int) $row['id'],
				'feed_name'     => (string) $row['feed_name'],
				'feed_title'    => (string) $row['feed_title'],
				'type'          => isset($settings['type']) ? (string) $settings['type'] : 'user',
				'layout'        => isset($settings['layout']) ? (string) $settings['layout'] : 'grid',
				'status'        => (string) $row['status'],
				'last_modified' => (string) $row['last_modified'],
				'shortcode'     => '[instagram-feed feed=' . (int) $row['id'] . ']',
			);
		}

		if ($status === 'all') {
			$total = SBI_Db::feeds_count();
		} else {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name is $wpdb->prefix + constant.
			$total = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE status = %s", $status));
		}

		return array(
			'feeds'       => $feeds,
			'total'       => $total,
			'page'        => $page,
			'per_page'    => $per_page,
			'total_pages' => (int) ceil($total / $per_page),
		);
	}

	/**
	 * @param int $feed_id
	 * @return array|null Null when the feed does not exist.
	 */
	public function get_feed($feed_id)
	{
		$feed_id = (int) $feed_id;
		if ($feed_id <= 0) {
			return null;
		}

		$saver    = new SBI_Feed_Saver($feed_id);
		$settings = $saver->get_feed_settings();
		if (!is_array($settings)) {
			return null;
		}
		$db = $saver->get_feed_db_data();

		$defaults = SBI_Feed_Saver::settings_defaults();
		// settings_defaults() stores '' (not the real 5000ms default) for
		// storiestime — the plugin resolves that empty sentinel to 5000 at
		// render/customizer time (see SBI_Display_Elements_Pro::get_stories_time()
		// and builder.js's own checkNotEmpty(...) ? ... : 5000 fallback). cast_out()
		// clamps a non-numeric default to its schema minimum (500) rather than the
		// plugin's real default, so a fresh feed with no explicit storiestime was
		// reported as 500ms instead of 5000ms. Resolve the real default here so it
		// matches what the plugin actually renders, without hardcoding it in
		// cast_out() itself.
		if (!isset($defaults['storiestime']) || $defaults['storiestime'] === '') {
			$defaults['storiestime'] = 5000;
		}
		// Same reasoning, same AgDR-0504 requirement-1 fix (finding B1): both keys
		// store '' in settings_defaults(), but every feed template
		// (SBI_Feed_Template_Settings) sets captionlength=50 / captionsize=12 on
		// creation, and that IS what a customer sees on a feed that never
		// overrode them. cast_out()'s non-numeric-default fallback would otherwise
		// report a stored-empty as 0 — a legal, in-range value indistinguishable
		// from an agent's deliberate "0" (captionlength: truncate immediately;
		// captionsize: inherit, no font-size override).
		if (!isset($defaults['captionlength']) || $defaults['captionlength'] === '') {
			$defaults['captionlength'] = 50;
		}
		if (!isset($defaults['captionsize']) || $defaults['captionsize'] === '') {
			$defaults['captionsize'] = 12;
		}
		$schema   = SBI_Settings_Schema::feed_settings();
		$out      = array();
		foreach ($schema as $key => $def) {
			$out[$key] = SBI_Settings_Schema::cast_out(
				$def,
				isset($settings[$key]) ? $settings[$key] : null,
				isset($defaults[$key]) ? $defaults[$key] : null
			);
		}
		$out['feed_name'] = isset($db['feed_name']) ? (string) $db['feed_name'] : $out['feed_name'];

		return array(
			'id'            => $feed_id,
			'feed_title'    => isset($db['feed_title']) ? (string) $db['feed_title'] : '',
			'type'          => isset($settings['type']) ? (string) $settings['type'] : 'user',
			'status'        => isset($db['status']) ? (string) $db['status'] : '',
			'last_modified' => isset($db['last_modified']) ? (string) $db['last_modified'] : '',
			'shortcode'     => '[instagram-feed feed=' . $feed_id . ']',
			'sources'       => $this->redact_sources(isset($settings['sources']) ? $settings['sources'] : array()),
			'settings'      => $out,
		);
	}

	/**
	 * Keep only what identifies the account. Never tokens, `info`, or errors.
	 *
	 * @param array $sources
	 * @return array<int, array{username: string, account_type: string}>
	 */
	private function redact_sources($sources)
	{
		$out = array();
		foreach ((array) $sources as $source) {
			if (!is_array($source)) {
				continue;
			}
			$out[] = array(
				'username'     => isset($source['username']) ? (string) $source['username'] : '',
				'account_type' => isset($source['type']) ? (string) $source['type'] : '',
			);
		}
		return $out;
	}

	/**
	 * Re-wrap `source_details` before every set_data() call that merges into a
	 * feed's raw stored settings.
	 *
	 * SBI_Feed_Saver::format_settings() collapses a one-element list to its
	 * single element on save, so a single-source feed stores `source_details`
	 * as a flat {id, username} map. Replaying that flat map through
	 * sanitize_and_sort_data() would turn it into a positional [id, username]
	 * list and break the username-based source-recovery fallback in
	 * get_feed_settings(). Re-wrap it so the round-trip is lossless.
	 *
	 * Shared by every write path that merges into raw stored settings
	 * (update_feed, set_highlight_source, set_color_palette) — AgDR-0504
	 * requirement 4 (side-effect parity): a partial write must not corrupt
	 * state the plugin's own save path leaves intact.
	 *
	 * @param array $merged Stored settings merged with a partial write.
	 * @return array
	 */
	private static function rewrap_single_source_details(array $merged)
	{
		if (
			isset($merged['source_details']) && is_array($merged['source_details'])
			&& isset($merged['source_details']['id']) && isset($merged['source_details']['username'])
		) {
			$merged['source_details'] = array($merged['source_details']);
		}
		return $merged;
	}

	/**
	 * Warn when layout is "highlight" but no complete highlight source is
	 * configured — the state update-feed-settings and create_feed can reach
	 * because `layout` stays generic-writable while its highlight companions
	 * are read-only (AgDR-0504 requirement 2). Without this, layout=highlight
	 * "succeeds" and silently renders no highlighted posts (finding A3).
	 *
	 * @param array $settings Merged/effective feed settings.
	 * @return string|null
	 */
	private function highlight_source_warning(array $settings)
	{
		if (!isset($settings['layout']) || $settings['layout'] !== 'highlight') {
			return null;
		}
		$type = isset($settings['highlighttype']) ? $settings['highlighttype'] : 'pattern';
		switch ($type) {
			case 'id':
				$complete = !empty($settings['highlightids']);
				break;
			case 'hashtag':
				$complete = !empty($settings['highlighthashtag']);
				break;
			case 'pattern':
			default:
				$complete = !empty($settings['highlightpattern']);
				break;
		}
		return $complete ? null : 'layout is "highlight" but no highlight source is configured — use '
			. 'set-highlight-source to choose which posts to highlight, or the feed will show none.';
	}

	/**
	 * Apply a partial update to one feed's settings.
	 *
	 * SBI_Feed_Saver::update() REPLACES the stored settings JSON with whatever
	 * was passed to set_data(), so we merge into the RAW stored row (never the
	 * token-hydrated get_feed_settings() array), run the same saver the Feed
	 * Builder uses, and clear the feed cache exactly like builder_update().
	 *
	 * @param int      $feed_id
	 * @param array    $partial key => value, already schema-validated by core.
	 * @param callable $tier_available fn(string $feature): bool
	 * @return array{feed_id: int, updated: string[], ignored: object, warnings: string[]}|\WP_Error|null
	 *         Null when the feed does not exist.
	 */
	public function update_feed($feed_id, array $partial, $tier_available)
	{
		$feed_id = (int) $feed_id;
		if ($feed_id <= 0) {
			return null;
		}
		$rows = SBI_Db::feeds_query(array('id' => $feed_id));
		if (empty($rows)) {
			return null;
		}
		$row    = $rows[0];
		$stored = json_decode($row['settings'], true);
		$stored = is_array($stored) ? $stored : array();

		$schema   = SBI_Settings_Schema::feed_settings();
		$writable = SBI_Settings_Schema::writable($schema);
		$updated  = array();
		$ignored  = array();
		$clean    = array();
		$new_name = null;

		foreach ($partial as $key => $value) {
			if (!isset($schema[$key])) {
				$ignored[$key] = 'unknown_setting';
				continue;
			}
			if (!isset($writable[$key])) {
				$ignored[$key] = 'read_only';
				continue;
			}
			if (isset($schema[$key]['tier']) && !call_user_func($tier_available, $schema[$key]['tier'])) {
				$ignored[$key] = 'feature_unavailable';
				continue;
			}
			$v = SBI_Settings_Schema::validate_in($schema[$key], $value, $key);
			if (is_wp_error($v)) {
				return $v;
			}
			if ($key === 'feed_name') {
				$new_name = $v;
				$updated[] = $key;
				continue;
			}
			// The builder stores scalars as strings and booleans as booleans.
			$clean[$key] = is_bool($v) ? $v : (string) $v;
		}

		if (empty($clean) && $new_name === null) {
			return array(
				'feed_id'  => $feed_id,
				'updated'  => array(),
				'ignored'  => (object) $ignored,
				'warnings' => array(),
			);
		}

		$merged = array_merge($stored, $clean);
		unset($merged['sources']); // never persisted; builder_update() unsets it too.
		$merged = self::rewrap_single_source_details($merged);

		$saver = new SBI_Feed_Saver($feed_id);
		$saver->set_feed_name($new_name !== null ? $new_name : (string) $row['feed_name']);
		$saver->set_data($merged);
		// SBI_Db::feeds_update() returns $wpdb->update(): rows changed, or false on
		// error. An idempotent replay can legitimately change 0 rows.
		if ($saver->update_or_insert() === false) {
			return new \WP_Error(
				'sbi_feed_save_failed',
				__('The feed could not be saved.', 'instagram-feed'),
				array('status' => 500)
			);
		}
		$updated = array_merge($updated, array_keys($clean));

		if (class_exists('SB_Instagram_Cache')) {
			$cache = new SB_Instagram_Cache($feed_id);
			// 'all' only empties the rendered/header cache rows (local, cheap) so the
			// change shows immediately. 'posts' forces an Instagram API refetch, so it
			// is limited to keys that change WHAT is fetched — otherwise an agent
			// looping over cosmetic keys would burn Graph API quota.
			$cache->clear('all');
			if (array_intersect(self::RETRIEVAL_KEYS, array_keys($clean))) {
				$cache->clear('posts');
			}
		}

		/**
		 * Fires after an AI agent updated a feed through the Abilities API.
		 *
		 * @param int      $feed_id
		 * @param string[] $updated Keys that were written.
		 */
		do_action('sbi_abilities_feed_settings_updated', $feed_id, $updated);

		// AgDR-0504 requirement 3: signal accepted-but-inert instead of a bare
		// success (finding A3) — this fires only when THIS write set layout to
		// "highlight" without a complete source already in place.
		$warnings = array();
		if (in_array('layout', $updated, true)) {
			$warning = $this->highlight_source_warning($merged);
			if ($warning !== null) {
				$warnings[] = $warning;
			}
		}

		return array(
			'feed_id'  => $feed_id,
			'updated'  => $updated,
			'ignored'  => (object) $ignored,
			'warnings' => $warnings,
		);
	}

	/**
	 * Feed templates the builder ships (SBI_Feed_Template_Settings).
	 *
	 * @var string[]
	 */
	const FEED_TEMPLATES = array(
		'ft_simple_grid',
		'ft_simple_grid_xl',
		'ft_simple_row',
		'ft_simple_carousel',
		'ft_masonry_cards',
		'ft_card_grid',
		'ft_highlight',
		'ft_single_post',
		'ft_single_post_carousel',
	);

	/**
	 * Create a feed the way the builder's new_insert path does: template
	 * defaults + validated quick settings + resolved sources.
	 *
	 * @param array    $input {feed_name?, feedtemplate?, sources?, settings?}
	 * @param callable $tier_available fn(string $feature): bool
	 * @return array|\WP_Error
	 */
	public function create_feed(array $input, $tier_available)
	{
		$settings_data = array(
			'type'  => 'user',
			'order' => 'recent',
		);

		if (!empty($input['feedtemplate'])) {
			$settings_data['feedtemplate'] = (string) $input['feedtemplate'];
		}
		// Same template expansion the builder applies on new_insert.
		$settings_data = SBI_Feed_Saver_Manager::get_feed_settings_by_feed_templates($settings_data);

		$ignored = array();
		$updated = array();
		if (!empty($input['settings']) && is_array($input['settings'])) {
			$schema   = SBI_Settings_Schema::feed_settings();
			$writable = SBI_Settings_Schema::writable($schema);
			foreach ($input['settings'] as $key => $value) {
				if ($key === 'feed_name' || !isset($writable[$key])) {
					$ignored[$key] = isset($schema[$key]) ? 'read_only' : 'unknown_setting';
					continue;
				}
				if (isset($schema[$key]['tier']) && !call_user_func($tier_available, $schema[$key]['tier'])) {
					$ignored[$key] = 'feature_unavailable';
					continue;
				}
				$v = SBI_Settings_Schema::validate_in($schema[$key], $value, $key);
				if (is_wp_error($v)) {
					return $v;
				}
				$settings_data[$key] = is_bool($v) ? $v : (string) $v;
				$updated[]           = $key;
			}
		}

		$source_usernames = array();
		if (!empty($input['sources']) && is_array($input['sources'])) {
			$resolved = (new SBI_Source_Service())->resolve_sources($input['sources']);
			if (!empty($resolved['missing'])) {
				return new \WP_Error(
					'sbi_source_not_found',
					sprintf(
						/* translators: %s: comma-separated account names */
						__(
							'These accounts are not connected to this site: %s. '
							. 'Use get-connect-url to connect one first.',
							'instagram-feed'
						),
						implode(', ', $resolved['missing'])
					),
					array('status' => 404)
				);
			}
			$settings_data['id']             = $resolved['ids'];
			$settings_data['source_details'] = $resolved['details'];
			foreach ($resolved['details'] as $d) {
				$source_usernames[] = $d['username'];
			}
		}

		$feed_name = !empty($input['feed_name'])
			? sanitize_text_field((string) $input['feed_name'])
			: SBI_Db::feeds_query_name(
				!empty($source_usernames) ? $source_usernames[0] : __('Instagram Feed', 'instagram-feed')
			);

		$saver = new SBI_Feed_Saver(false);
		$saver->set_feed_name($feed_name);
		$saver->set_data($settings_data);
		if (!$saver->update_or_insert()) {
			return new \WP_Error(
				'sbi_feed_save_failed',
				__('The feed could not be created.', 'instagram-feed'),
				array('status' => 500)
			);
		}
		$feed_id = (int) $saver->get_feed_id();

		/** This action is documented in SBI_Feed_Settings_Service::update_feed(). */
		do_action('sbi_abilities_feed_settings_updated', $feed_id, $updated);

		// AgDR-0504 requirement 3 (finding A3): a feed created straight into
		// layout="highlight" with no complete source (a bare quick-setting, not
		// the ft_highlight template) would otherwise "succeed" and show nothing.
		$warnings = array();
		$warning  = $this->highlight_source_warning($settings_data);
		if ($warning !== null) {
			$warnings[] = $warning;
		}

		return array(
			'feed_id'   => $feed_id,
			'feed_name' => $feed_name,
			'shortcode' => '[instagram-feed feed=' . $feed_id . ']',
			'updated'   => $updated,
			'ignored'   => (object) $ignored,
			'warnings'  => $warnings,
		);
	}

	/**
	 * Attach already-connected accounts to a feed (replaces the source list).
	 *
	 * @param int      $feed_id
	 * @param string[] $handles usernames or account ids.
	 * @return array|\WP_Error|null Null when the feed does not exist.
	 */
	public function set_feed_sources($feed_id, array $handles)
	{
		$feed_id = (int) $feed_id;
		$rows    = SBI_Db::feeds_query(array('id' => $feed_id));
		if ($feed_id <= 0 || empty($rows)) {
			return null;
		}
		$resolved = (new SBI_Source_Service())->resolve_sources($handles);
		if (!empty($resolved['missing'])) {
			return new \WP_Error(
				'sbi_source_not_found',
				sprintf(
					/* translators: %s: comma-separated account names */
					__(
						'These accounts are not connected to this site: %s. '
						. 'Use get-connect-url to connect one first.',
						'instagram-feed'
					),
					implode(', ', $resolved['missing'])
				),
				array('status' => 404)
			);
		}
		if (empty($resolved['ids'])) {
			return new \WP_Error(
				'sbi_invalid_value',
				__('At least one connected account is required.', 'instagram-feed'),
				array('status' => 400)
			);
		}

		$stored = json_decode($rows[0]['settings'], true);
		$stored = is_array($stored) ? $stored : array();
		$stored['id']             = $resolved['ids'];
		$stored['source_details'] = $resolved['details'];
		unset($stored['sources']);

		$saver = new SBI_Feed_Saver($feed_id);
		$saver->set_feed_name((string) $rows[0]['feed_name']);
		$saver->set_data($stored);
		if ($saver->update_or_insert() === false) {
			return new \WP_Error(
				'sbi_feed_save_failed',
				__('The feed could not be saved.', 'instagram-feed'),
				array('status' => 500)
			);
		}

		if (class_exists('SB_Instagram_Cache')) {
			$cache = new SB_Instagram_Cache($feed_id);
			$cache->clear('all');
			$cache->clear('posts'); // source change always alters what is fetched.
		}

		/** This action is documented in SBI_Feed_Settings_Service::update_feed(). */
		do_action('sbi_abilities_feed_settings_updated', $feed_id, array('sources'));

		return array(
			'feed_id' => $feed_id,
			'sources' => array_map(
				function ($d) {
					return $d['username'];
				},
				$resolved['details']
			),
		);
	}

	/**
	 * Set a feed's highlight source (layout "highlight") — the validating
	 * ability for the companions AgDR-0504 requirement 2 made read-only in the
	 * generic setter (finding A3). Refuses a highlighttype with no matching
	 * value rather than saving a state the feed can't complete, and clears
	 * only the OTHER types' values so switching type doesn't leave a stale
	 * pattern/ids/hashtag combination that a later type switch could revive.
	 *
	 * @param int    $feed_id       Feed id.
	 * @param string $highlighttype pattern|id|hashtag.
	 * @param array  $values        {highlightpattern?, highlightoffset?, highlightids?, highlighthashtag?}.
	 * @return array{feed_id: int, updated: string[], ignored: object, warnings: string[]}|\WP_Error|null
	 *         Null when the feed does not exist.
	 */
	public function set_highlight_source($feed_id, $highlighttype, array $values)
	{
		$feed_id = (int) $feed_id;
		$rows    = SBI_Db::feeds_query(array('id' => $feed_id));
		if ($feed_id <= 0 || empty($rows)) {
			return null;
		}

		$schema = SBI_Settings_Schema::feed_settings();
		$type   = SBI_Settings_Schema::validate_in($schema['highlighttype'], $highlighttype, 'highlighttype');
		if (is_wp_error($type)) {
			return $type;
		}

		// Every OTHER type's value is reset to its default so a later type switch
		// never silently revives a stale pattern/ids/hashtag combination left
		// over from before this write.
		$clean = array(
			'highlighttype'    => $type,
			'highlightpattern' => '',
			'highlightoffset'  => 0,
			'highlightids'     => '',
			'highlighthashtag' => '',
		);

		switch ($type) {
			case 'pattern':
				if (!isset($values['highlightpattern']) || $values['highlightpattern'] === '') {
					return new \WP_Error(
						'sbi_invalid_value',
						__('highlightpattern is required when highlighttype is "pattern".', 'instagram-feed'),
						array('status' => 400)
					);
				}
				$pattern = SBI_Settings_Schema::validate_in(
					$schema['highlightpattern'],
					$values['highlightpattern'],
					'highlightpattern'
				);
				if (is_wp_error($pattern)) {
					return $pattern;
				}
				$clean['highlightpattern'] = $pattern;
				if (isset($values['highlightoffset']) && $values['highlightoffset'] !== '') {
					$offset = SBI_Settings_Schema::validate_in(
						$schema['highlightoffset'],
						$values['highlightoffset'],
						'highlightoffset'
					);
					if (is_wp_error($offset)) {
						return $offset;
					}
					$clean['highlightoffset'] = $offset;
				}
				break;

			case 'id':
				if (empty($values['highlightids'])) {
					return new \WP_Error(
						'sbi_invalid_value',
						__('highlightids is required when highlighttype is "id".', 'instagram-feed'),
						array('status' => 400)
					);
				}
				$ids = SBI_Settings_Schema::validate_in(
					$schema['highlightids'],
					$values['highlightids'],
					'highlightids'
				);
				if (is_wp_error($ids)) {
					return $ids;
				}
				$clean['highlightids'] = $ids;
				break;

			case 'hashtag':
				if (empty($values['highlighthashtag'])) {
					return new \WP_Error(
						'sbi_invalid_value',
						__('highlighthashtag is required when highlighttype is "hashtag".', 'instagram-feed'),
						array('status' => 400)
					);
				}
				$hashtag = SBI_Settings_Schema::validate_in(
					$schema['highlighthashtag'],
					$values['highlighthashtag'],
					'highlighthashtag'
				);
				if (is_wp_error($hashtag)) {
					return $hashtag;
				}
				$clean['highlighthashtag'] = $hashtag;
				break;
		}

		$row    = $rows[0];
		$stored = json_decode($row['settings'], true);
		$stored = is_array($stored) ? $stored : array();
		$merged = array_merge($stored, $clean);
		unset($merged['sources']);
		$merged = self::rewrap_single_source_details($merged);

		$saver = new SBI_Feed_Saver($feed_id);
		$saver->set_feed_name((string) $row['feed_name']);
		$saver->set_data($merged);
		if ($saver->update_or_insert() === false) {
			return new \WP_Error(
				'sbi_feed_save_failed',
				__('The feed could not be saved.', 'instagram-feed'),
				array('status' => 500)
			);
		}

		if (class_exists('SB_Instagram_Cache')) {
			$cache = new SB_Instagram_Cache($feed_id);
			$cache->clear('all');
			$cache->clear('posts'); // the highlight source changes which posts qualify.
		}

		/** This action is documented in SBI_Feed_Settings_Service::update_feed(). */
		do_action('sbi_abilities_feed_settings_updated', $feed_id, array_keys($clean));

		// AgDR-0504 requirement 3: this ability can only ever configure a
		// COMPLETE source, but the feed can still be sitting on a non-highlight
		// layout — say so rather than a bare success that looks like it did
		// nothing.
		$warnings = array();
		if (!isset($merged['layout']) || $merged['layout'] !== 'highlight') {
			$warnings[] = 'This feed\'s layout is not "highlight" — the highlight source is saved but will not '
				. 'be used until layout is changed via update-feed-settings.';
		}

		return array(
			'feed_id'  => $feed_id,
			'updated'  => array_keys($clean),
			'ignored'  => (object) array(),
			'warnings' => $warnings,
		);
	}

	/**
	 * Set a feed's color palette — the validating ability for the custom*color
	 * companions AgDR-0504 requirement 2 made read-only in the generic setter
	 * (finding A4). "custom" with no colour supplied is refused rather than
	 * saved as a palette that renders blank.
	 *
	 * @param int    $feed_id      Feed id.
	 * @param string $colorpalette inherit|light|dark|custom.
	 * @param array  $colors       key => hex value, any of the six custom*color keys.
	 * @return array{feed_id: int, updated: string[], ignored: object, warnings: string[]}|\WP_Error|null
	 *         Null when the feed does not exist.
	 */
	public function set_color_palette($feed_id, $colorpalette, array $colors)
	{
		$feed_id = (int) $feed_id;
		$rows    = SBI_Db::feeds_query(array('id' => $feed_id));
		if ($feed_id <= 0 || empty($rows)) {
			return null;
		}

		$schema  = SBI_Settings_Schema::feed_settings();
		$palette = SBI_Settings_Schema::validate_in($schema['colorpalette'], $colorpalette, 'colorpalette');
		if (is_wp_error($palette)) {
			return $palette;
		}

		$custom_keys = array(
			'custombgcolor1',
			'customtextcolor1',
			'customtextcolor2',
			'customlinkcolor1',
			'custombuttoncolor1',
			'custombuttoncolor2',
		);

		$clean    = array('colorpalette' => $palette);
		$ignored  = array();
		$warnings = array();

		if ($palette === 'custom') {
			$any = false;
			foreach ($custom_keys as $key) {
				if (!isset($colors[$key]) || $colors[$key] === '') {
					continue;
				}
				$v = SBI_Settings_Schema::validate_in($schema[$key], $colors[$key], $key);
				if (is_wp_error($v)) {
					return $v;
				}
				$clean[$key] = $v;
				$any         = true;
			}
			if (!$any) {
				return new \WP_Error(
					'sbi_invalid_value',
					__(
						'At least one custom*color value is required when colorpalette is "custom".',
						'instagram-feed'
					),
					array('status' => 400)
				);
			}
		} elseif (!empty($colors)) {
			// Accepted-but-inert (AgDR-0504 requirement 3): the values are valid
			// hex colours, just unused while the palette isn't "custom".
			foreach (array_keys($colors) as $key) {
				$ignored[$key] = 'feature_unavailable';
			}
			$warnings[] = 'colorpalette is "' . $palette . '", not "custom" — the supplied custom*color '
				. 'values were not saved.';
		}

		$row    = $rows[0];
		$stored = json_decode($row['settings'], true);
		$stored = is_array($stored) ? $stored : array();
		$merged = array_merge($stored, $clean);
		unset($merged['sources']);
		$merged = self::rewrap_single_source_details($merged);

		$saver = new SBI_Feed_Saver($feed_id);
		$saver->set_feed_name((string) $row['feed_name']);
		$saver->set_data($merged);
		if ($saver->update_or_insert() === false) {
			return new \WP_Error(
				'sbi_feed_save_failed',
				__('The feed could not be saved.', 'instagram-feed'),
				array('status' => 500)
			);
		}

		if (class_exists('SB_Instagram_Cache')) {
			$cache = new SB_Instagram_Cache($feed_id);
			$cache->clear('all'); // cosmetic only — never touches what is fetched.
		}

		/** This action is documented in SBI_Feed_Settings_Service::update_feed(). */
		do_action('sbi_abilities_feed_settings_updated', $feed_id, array_keys($clean));

		return array(
			'feed_id'  => $feed_id,
			'updated'  => array_keys($clean),
			'ignored'  => (object) $ignored,
			'warnings' => $warnings,
		);
	}
}
