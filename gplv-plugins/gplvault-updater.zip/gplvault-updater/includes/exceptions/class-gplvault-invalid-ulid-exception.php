<?php

class GPLVault_Invalid_Ulid_Exception extends InvalidArgumentException {}
