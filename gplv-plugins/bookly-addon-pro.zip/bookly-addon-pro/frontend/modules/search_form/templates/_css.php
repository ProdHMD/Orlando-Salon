<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly
use Bookly\Lib as BooklyLib;
use Bookly\Lib\Utils\Common;
use BooklyPro\Frontend\Modules\ModernBookingForm;

$color = isset( $appearance['main_color'] ) ? $appearance['main_color'] : get_option( 'bookly_app_color', '#f4662f' );
// Theme option values are printed as custom properties (manifest defaults as fallback),
// theme stylesheets consume them via var() without fallbacks.
$theme_vars = ModernBookingForm\Form::getCssVars( $appearance );
/** @var string $form_id */
?>
<style>
    .<?php echo esc_attr( $form_id ) ?> {
        --bookly-color: <?php echo esc_attr( $color ) ?>;
        --bookly-card-width: <?php echo (int) ( isset( $appearance['service_card_width'] ) ? $appearance['service_card_width'] : 260 ) ?>px;
        --bookly-header-height: <?php echo (int) ( isset( $appearance['service_header_height'] ) ? $appearance['service_header_height'] : 120 ) ?>px;
<?php foreach ( $theme_vars as $name => $value ) : ?>
        <?php echo esc_attr( $name ) ?>: <?php echo esc_attr( $value ) ?>;
<?php endforeach ?>
    }

    :root {
        --bookly-flags-url: url(<?php echo plugins_url( 'frontend/resources/images/flags.png', BooklyLib\Plugin::getMainFile() ) ?>);
        --bookly-flags2x-url: url(<?php echo plugins_url( 'frontend/resources/images/flags@2x.png', BooklyLib\Plugin::getMainFile() ) ?>);
        --rtl-phone-align: <?php echo is_rtl() ? 'right !important' : 'left' ?>;
    }
</style>
<?php if ( isset( $appearance['custom_css'] ) && $appearance['custom_css'] != '' ) : ?>
    <style>
        <?php echo Common::css( $appearance['custom_css'] ) ?>
    </style>
<?php endif ?>
