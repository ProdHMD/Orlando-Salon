<?php

namespace InstagramFeed\Abilities\Abilities;

use InstagramFeed\Abilities\SBI_Ability_Response;
use InstagramFeed\Abilities\Services\SBI_Feed_Settings_Service;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * instagram-feed/set-highlight-source
 *
 * The "layout: highlight" companions (highlighttype, highlightpattern,
 * highlightoffset, highlightids, highlighthashtag) are read-only in
 * update-feed-settings (AgDR-0504 requirement 2) because they only work as a
 * set: a highlighttype with no matching value is a state the feed can't
 * complete (finding A3 — layout=highlight succeeded while blanking a feed to
 * zero posts). This ability validates the whole set together and refuses an
 * incomplete pair, mirroring Custom Twitter Feeds' set-feed-type-and-terms.
 *
 * Destructive by annotation: switching the source can blank what a
 * "highlight" feed shows, same as set-feed-sources, so MCP clients that
 * honour annotations (WPVibe) show their approval panel.
 *
 * @since INSTA_FEED_PRO_SINCE
 */
class SBI_Set_Highlight_Source extends SBI_Ability
{
	public function slug()
	{
		return 'set-highlight-source';
	}

	public function args()
	{
		return array(
			'label'               => __('Set what an Instagram highlight feed shows', 'instagram-feed'),
			'description'         => __('Sets the highlight source for a feed with layout "highlight": pattern (every Nth post, with an optional starting offset), id (comma-separated post IDs) or hashtag (comma-separated hashtags). Only the value matching the chosen type is required; the other types\' stored values are cleared. Requires AI write access.', 'instagram-feed'), // phpcs:ignore Generic.Files.LineLength.TooLong -- single literal for make-pot
			'input_schema'        => array(
				'type'                 => 'object',
				'properties'           => array(
					'feed_id'          => array(
						'type'        => 'integer',
						'minimum'     => 1,
						'description' => 'Feed id from list-feeds.',
					),
					'highlighttype'    => array(
						'type' => 'string',
						'enum' => array('pattern', 'id', 'hashtag'),
					),
					'highlightpattern' => array(
						'type'        => 'integer',
						'minimum'     => 1,
						'description' => 'Highlight every Nth post. Required when highlighttype is "pattern".',
					),
					'highlightoffset'  => array(
						'type'        => 'integer',
						'minimum'     => 0,
						'description' => 'Pattern starting offset. Only used when highlighttype is "pattern"; '
							. 'defaults to 0.',
					),
					'highlightids'     => array(
						'type'        => 'string',
						'maxLength'   => 500,
						'description' => 'Comma-separated post IDs. Required when highlighttype is "id".',
					),
					'highlighthashtag' => array(
						'type'        => 'string',
						'maxLength'   => 500,
						'description' => 'Comma-separated hashtags. Required when highlighttype is "hashtag".',
					),
				),
				'required'             => array('feed_id', 'highlighttype'),
				'additionalProperties' => false,
			),
			'output_schema'       => $this->write_output_schema(array('feed_id' => array('type' => 'integer'))),
			'execute_callback'    => array($this, 'execute'),
			'permission_callback' => array($this, 'can_write'),
			'meta'                => $this->write_meta(true, true),
		);
	}

	public function execute($input = null)
	{
		$input   = $this->normalize_input($input);
		$feed_id = isset($input['feed_id']) ? (int) $input['feed_id'] : 0;
		if ($feed_id <= 0) {
			return SBI_Ability_Response::invalid_feed_id();
		}
		$type   = isset($input['highlighttype']) ? (string) $input['highlighttype'] : '';
		$values = array_intersect_key(
			$input,
			array_flip(array('highlightpattern', 'highlightoffset', 'highlightids', 'highlighthashtag'))
		);

		$result = (new SBI_Feed_Settings_Service())->set_highlight_source($feed_id, $type, $values);

		return $result === null ? SBI_Ability_Response::feed_not_found($feed_id) : $result;
	}
}
