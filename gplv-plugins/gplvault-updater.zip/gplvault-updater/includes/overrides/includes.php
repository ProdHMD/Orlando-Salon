<?php

defined( 'ABSPATH' ) || exit;

require_once __DIR__ . '/mts-overrides.php';
