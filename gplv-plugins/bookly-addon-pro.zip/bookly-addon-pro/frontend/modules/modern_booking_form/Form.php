<?php
namespace BooklyPro\Frontend\Modules\ModernBookingForm;

use BooklyPro\Lib;
use Bookly\Lib as BooklyLib;
use Bookly\Frontend\Modules\ModernBookingForm\Proxy;
use Bookly\Frontend\Modules\Booking\Proxy as BookingProxy;

class Form extends BooklyLib\Base\Component
{
    public static function render()
    {
        $tel_input_enabled = get_option( 'bookly_cst_phone_default_country' ) !== 'disabled';

        self::enqueueScripts( array(
            'backend' => array(
                'js/common.js' => array( 'jquery' ),
            ),
            'module' => array(
                'js/modern-booking-form.js' => array( 'bookly-qrcode.js', 'bookly-frontend-globals', 'bookly-daterangepicker.js' ),
            ),
            'bookly' => array(
                'frontend/resources/js/qrcode.js' => array()
            ),
        ) );
        self::enqueueStyles( array(
            'module' => array( 'css/modern-booking-form.css' ),
            'bookly' => array( 'backend/resources/tailwind/tailwind.css' ),
        ) );
        if ( $tel_input_enabled ) {
            self::enqueueStyles( array(
                'bookly' => array( 'frontend/resources/css/intlTelInput.css' ),
            ) );
            self::enqueueScripts( array(
                'bookly' => array( 'frontend/resources/js/intlTelInput.min.js' => array( 'jquery' ) ),
            ) );
        }

        $customer = new BooklyLib\Entities\Customer();
        if ( is_user_logged_in() ) {
            $customer->loadBy( array( 'wp_user_id' => get_current_user_id() ) );
            if ( ! $customer->getId() ) {
                $customer->setFirstName( wp_get_current_user()->first_name );
                $customer->setLastName( wp_get_current_user()->last_name );
                $customer->setFullName( wp_get_current_user()->display_name );
                $customer->setEmail( wp_get_current_user()->user_email );
            }
        } elseif ( get_option( 'bookly_cst_remember_in_cookie' ) ) {
            if ( isset( $_COOKIE['bookly-customer-email'] ) ) {
                $customer->setEmail( BooklyLib\Utils\Common::stripWpKses( $_COOKIE['bookly-customer-email'] ) );
            }
            if ( isset( $_COOKIE['bookly-customer-phone'] ) ) {
                $customer->setPhone( BooklyLib\Utils\Common::stripWpKses( $_COOKIE['bookly-customer-phone'] ) );
            }
            if ( isset( $_COOKIE['bookly-customer-full-name'] ) ) {
                $customer->setFullName( BooklyLib\Utils\Common::stripWpKses( $_COOKIE['bookly-customer-full-name'] ) );
            }
            if ( isset( $_COOKIE['bookly-customer-first-name'] ) ) {
                $customer->setFirstName( BooklyLib\Utils\Common::stripWpKses( $_COOKIE['bookly-customer-first-name'] ) );
            }
            if ( isset( $_COOKIE['bookly-customer-last-name'] ) ) {
                $customer->setLastName( BooklyLib\Utils\Common::stripWpKses( $_COOKIE['bookly-customer-last-name'] ) );
            }
        }

        wp_localize_script(
            'bookly-modern-booking-form.js', 'BooklyL10nModernBookingForm', Proxy\Shared::prepareFormOptions( array(
            'session_id' => BooklyLib\FormSession::createSession(),
            'customer' => array(
                'id' => $customer->getId(),
                'first_name' => $customer->getFirstName(),
                'last_name' => $customer->getLastName(),
                'full_name' => $customer->getFullName(),
                'email' => $customer->getEmail(),
                'phone' => $customer->getPhone(),
                'country' => $customer->getCountry(),
                'state' => $customer->getState(),
                'postcode' => $customer->getPostcode(),
                'city' => $customer->getCity(),
                'street' => $customer->getStreet(),
                'street_number' => $customer->getStreetNumber(),
                'additional_address' => $customer->getAdditionalAddress(),
                'full_address' => $customer->getFullAddress(),
            ),
            'complex_services' => array(),
            'gift_cards' => array(),
            'format_price' => BooklyLib\Utils\Price::formatOptions(),
            'datePicker' => BooklyLib\Utils\DateTime::datePickerOptions(),
            'maxDaysForBooking' => BooklyLib\Config::getMaximumAvailableDaysForBooking(),
            'moment_format_date' => BooklyLib\Utils\DateTime::convertFormat( 'date', BooklyLib\Utils\DateTime::FORMAT_MOMENT_JS ),
            'moment_format_time' => BooklyLib\Utils\DateTime::convertFormat( 'time', BooklyLib\Utils\DateTime::FORMAT_MOMENT_JS ),
            'casest' => BooklyLib\Config::getCaSeSt(),
            'use_client_timezone' => BooklyLib\Config::useClientTimeZone(),
            'timezones' => BooklyLib\Utils\DateTime::getTimeZoneOptions(),
            'images' => plugins_url( 'frontend/resources/images/', BooklyLib\Plugin::getMainFile() ),
            'payment_disabled' => BooklyLib\Config::paymentStepDisabled() || BookingProxy\CustomerGroups::getSkipPayment( $customer ),
            'intlTelInput' => array(
                'enabled' => $tel_input_enabled,
                'country' => get_option( 'bookly_cst_phone_default_country' ),
            ),
            'l10n' => array(
                'prev' => __( 'Previous', 'bookly' ),
                'next' => __( 'Next', 'bookly' ),
                'cart' => __( 'Cart', 'bookly' ),
            ),
        ) )
        );
    }

    /**
     * Enqueue the stylesheet of the form theme (if any).
     * Only the active theme file is loaded on the frontend; delivery honors
     * the enqueue/print assets option like any other form stylesheet.
     *
     * @param array $appearance
     */
    public static function enqueueTheme( $appearance )
    {
        $theme = self::getThemeName( $appearance );
        if ( $theme && file_exists( self::themesDirectory() . '/' . $theme . '.css' ) ) {
            self::enqueueStyles( array(
                'frontend' => array( 'css/themes/' . $theme . '.css' => array() ),
            ) );
        }
        if ( ! empty( $appearance['adaptive_grid'] ) && file_exists( dirname( self::themesDirectory() ) . '/mods/adaptive-grid.css' ) ) {
            self::enqueueStyles( array(
                'frontend' => array( 'css/mods/adaptive-grid.css' => array() ),
            ) );
        }
        if ( ! empty( $appearance['transparent_bg'] ) && file_exists( dirname( self::themesDirectory() ) . '/mods/transparent-bg.css' ) ) {
            self::enqueueStyles( array(
                'frontend' => array( 'css/mods/transparent-bg.css' => array() ),
            ) );
        }
        if ( isset( $appearance['shadows'] ) && in_array( $appearance['shadows'], array( 'medium', 'large' ), true ) && file_exists( dirname( self::themesDirectory() ) . '/mods/card-shadow.css' ) ) {
            self::enqueueStyles( array(
                'frontend' => array( 'css/mods/card-shadow.css' => array() ),
            ) );
        }
    }

    /**
     * All CSS custom properties the form prints for its container: theme option
     * values plus appearance-level token overrides (corner radius).
     *
     * @param array $appearance
     * @return array key => value, keys are full custom property names
     */
    public static function getCssVars( $appearance )
    {
        return self::getThemeCssVars( $appearance ) + self::getCornerRadiusCssVars( $appearance );
    }

    /**
     * CSS custom properties for theme options: values come from the form settings
     * with manifest defaults as a fallback, so the full set is always printed and
     * theme stylesheets can use var() without fallbacks.
     *
     * @param array $appearance
     * @return array key => value, keys are full custom property names
     */
    public static function getThemeCssVars( $appearance )
    {
        $vars = array();
        $manifest = self::getThemeManifest( $appearance );
        if ( $manifest && isset( $manifest['options'] ) ) {
            $settings = isset( $appearance['theme_settings'] ) && is_array( $appearance['theme_settings'] ) ? $appearance['theme_settings'] : array();
            foreach ( $manifest['options'] as $option ) {
                if ( ! isset( $option['key'] ) ) {
                    continue;
                }
                $value = isset( $settings[ $option['key'] ] ) ? $settings[ $option['key'] ] : ( isset( $option['default'] ) ? $option['default'] : '' );
                if ( $value !== '' ) {
                    $vars[ '--bookly-theme-' . str_replace( '_', '-', $option['key'] ) ] = $value;
                }
            }
        }

        return $vars;
    }

    /**
     * CSS custom properties overriding the corner radius tokens: the compiled
     * utilities reference the tokens via var(), so the whole form follows.
     * The default value (medium) prints nothing and keeps the stock look.
     *
     * @param array $appearance
     * @return array key => value, keys are full custom property names
     */
    public static function getCornerRadiusCssVars( $appearance )
    {
        $radius = isset( $appearance['corner_radius'] ) ? $appearance['corner_radius'] : 'medium';
        switch ( $radius ) {
            case 'none':
                $sizes = array( '' => '0', 'xs' => '0', 'sm' => '0', 'md' => '0', 'lg' => '0', 'xl' => '0', '2xl' => '0', '3xl' => '0' );
                break;
            case 'large':
                $sizes = array( '' => '14px', 'xs' => '4px', 'sm' => '8px', 'md' => '10px', 'lg' => '14px', 'xl' => '18px', '2xl' => '22px', '3xl' => '28px' );
                break;
            default:
                return array();
        }
        $vars = array();
        foreach ( $sizes as $suffix => $value ) {
            $vars[ '--bookly-radius' . ( $suffix === '' ? '' : '-' . $suffix ) ] = $value;
        }

        return $vars;
    }

    /**
     * Wrapper CSS classes scoping the theme rules (theme + modifiers).
     *
     * @param array $appearance
     * @return string
     */
    public static function getThemeWrapperClasses( $appearance )
    {
        $classes = array();
        $theme = self::getThemeName( $appearance );
        if ( $theme ) {
            $classes[] = 'bookly-theme-' . $theme;
            // Checkbox options of the theme become modifier classes so theme
            // stylesheets can key optional blocks on them.
            $manifest = self::getThemeManifest( $appearance );
            if ( $manifest && isset( $manifest['options'] ) ) {
                $settings = isset( $appearance['theme_settings'] ) && is_array( $appearance['theme_settings'] ) ? $appearance['theme_settings'] : array();
                foreach ( $manifest['options'] as $option ) {
                    if ( isset( $option['key'], $option['type'] ) && $option['type'] === 'checkbox' ) {
                        $enabled = isset( $settings[ $option['key'] ] ) ? $settings[ $option['key'] ] : ( isset( $option['default'] ) ? $option['default'] : false );
                        if ( $enabled ) {
                            $classes[] = 'bookly-mod-' . str_replace( '_', '-', $option['key'] );
                        }
                    }
                }
            }
        }
        if ( ! empty( $appearance['adaptive_grid'] ) ) {
            $classes[] = 'bookly-mod-adaptive-grid';
        }
        if ( ! empty( $appearance['transparent_bg'] ) ) {
            $classes[] = 'bookly-mod-transparent-bg';
        }
        if ( isset( $appearance['shadows'] ) && in_array( $appearance['shadows'], array( 'medium', 'large' ), true ) ) {
            $classes[] = 'bookly-mod-shadow-' . $appearance['shadows'];
        }

        return implode( ' ', $classes );
    }

    /**
     * @param array $appearance
     * @return array|null
     */
    public static function getThemeManifest( $appearance )
    {
        $theme = self::getThemeName( $appearance );
        if ( $theme && is_readable( self::themesDirectory() . '/' . $theme . '.json' ) ) {
            $manifest = json_decode( file_get_contents( self::themesDirectory() . '/' . $theme . '.json' ), true );

            return is_array( $manifest ) ? $manifest : null;
        }

        return null;
    }

    /**
     * Sanitized theme name from the form settings.
     *
     * @param array $appearance
     * @return string|null
     */
    protected static function getThemeName( $appearance )
    {
        if ( ! empty( $appearance['theme'] ) && preg_match( '/^[a-z0-9\-]+$/', $appearance['theme'] ) ) {
            return $appearance['theme'];
        }

        return null;
    }

    /**
     * @return string
     */
    protected static function themesDirectory()
    {
        return \BooklyPro\Lib\Plugin::getDirectory() . '/frontend/resources/css/themes';
    }
}