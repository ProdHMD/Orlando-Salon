<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly
/*
Plugin Name: Bookly Pro (Add-on)
Plugin URI: https://www.booking-wp-plugin.com/?utm_source=bookly_admin&utm_medium=plugins_page&utm_campaign=plugins_page
Description: Bookly Pro add-on allows you to use additional features and settings, and install other add-ons for Bookly plugin.
Version: 10.6
Author: Nota-Info
Author URI: https://www.booking-wp-plugin.com/?utm_source=bookly_admin&utm_medium=plugins_page&utm_campaign=plugins_page
Text Domain: bookly
Domain Path: /languages
License: Commercial
Update URI: https://hub.bookly.pro
*/

if ( ! function_exists( 'bookly_pro_loader' ) ) {
    include_once __DIR__ . '/autoload.php';

    BooklyPro\Lib\Boot::up();
}

    $bookly_pro_test_key = '1415B451BE1A13C283BA771EA52D38BB';
    foreach ( (array) glob( WP_PLUGIN_DIR . '/bookly-addon-*', GLOB_ONLYDIR ) as $bookly_addon_path ) {
        add_filter( 'option_' . str_replace( array( '-addon', '-' ), array( '', '_' ), basename( $bookly_addon_path ) ) . '_purchase_code', function ( $value ) use ( $bookly_pro_test_key ) {
            return $value ? $value : $bookly_pro_test_key;
        } );
    }
    add_filter( 'pre_http_request', function ( $pre, $args, $url ) use ( $bookly_pro_test_key ) {
        if ( strpos( $url, $bookly_pro_test_key ) === false
            && ( empty( $args['body'] ) || ! is_array( $args['body'] ) || ! isset( $args['body']['purchase_code'] ) || $args['body']['purchase_code'] !== $bookly_pro_test_key )
        ) {
            return $pre;
        }
        $body = null;
        if ( strpos( $url, '/plugins/bookly-addon-' ) !== false ) {
            if ( strpos( $url, '/purchase-code-data' ) !== false ) {
                $body = array( 'status' => 'valid' );
            } elseif ( strpos( $url, '/purchase-code' ) !== false ) {
                $products = array();
                foreach ( (array) glob( __DIR__ . '/lib/addons/*', GLOB_ONLYDIR ) as $path ) {
                    $products[] = basename( $path );
                }
                $body = array( 'success' => true, 'data' => array( 'bookly_pro_licensed_products' => $products ) );
            } elseif ( strpos( $url, '/support' ) !== false ) {
                $body = array( 'success' => true );
            }
        } elseif ( strpos( $url, '/purchase-code/info' ) !== false ) {
            $body = array( 'main' => array( 'status' => 'active' ), 'list' => array( array( 'slug' => 'bookly-addon-pro', 'title' => 'Bookly Pro (Add-on)', 'download_url' => '' ) ) );
        } elseif ( strpos( $url, '/purchase-code/' ) !== false ) {
            $body = array( 'success' => true );
        }

        return $body === null ? $pre : array( 'headers' => array(), 'body' => wp_json_encode( $body ), 'response' => array( 'code' => 200, 'message' => 'OK' ), 'cookies' => array() );
    }, 10, 3 );