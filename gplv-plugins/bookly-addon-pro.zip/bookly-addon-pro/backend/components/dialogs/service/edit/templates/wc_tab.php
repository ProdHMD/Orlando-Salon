<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly ?>
<li class="nav-item bookly-js-service bookly-js-service-simple bookly-js-service-collaborative bookly-js-service-compound bookly-js-service-package">
    <a id="bookly-services-wc-tab" class="nav-link" href="#bookly-services-wc" data-toggle="bookly-tab">
        <i class="fas fa-shopping-cart mr-lg-1"></i>
        <span class="d-none d-lg-inline">WooCommerce</span>
    </a>
</li>