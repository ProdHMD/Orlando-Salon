<?php
namespace BooklyPro\Backend\Components\TinyMce\ProxyProviders;

use Bookly\Lib as BooklyLib;
use Bookly\Backend\Components\TinyMce\Proxy;

class Shared extends Proxy\Shared
{
    /**
     * @inheritDoc
     */
    public static function renderMediaButtons( $version )
    {
        // Per-type form buttons (search/services/staff/checkout/cancellation)
        // moved to core Backend\Components\TinyMce\Tools::addButton(), which
        // loops Lib\Entities\Form::getTypes() generically — that already
        // includes these Pro-contributed types (see Local::getFormTypes()).
        // What's left here is genuinely Pro-only: appointments list, calendar.
        if ( $version < 3.5 ) {
            // show button for v 3.4 and below
            echo '<a href="#TB_inline?width=400&inlineId=bookly-tinymce-appointment-popup&amp;height=300" id="add-ap-appointment" title="' . esc_attr__( 'Add Bookly appointments list', 'bookly' ) . '">' . __( 'Add Bookly appointments list', 'bookly' ) . '</a>';
            echo '<a href="#TB_inline?width=400&inlineId=bookly-tinymce-calendar&height=300" id="add-bookly-calendar" title="' . esc_attr__( 'Add Bookly calendar', 'bookly' ) . '">' . __( 'Add Bookly calendar', 'bookly' ) . '</a>';
        } else {
            // display button matching new UI
            $img = '<span class="bookly-media-icon"></span> ';
            echo '<a href="#TB_inline?width=400&inlineId=bookly-tinymce-appointment-popup&amp;height=300" id="add-ap-appointment" class="thickbox button bookly-media-button" title="' . esc_attr__( 'Add Bookly appointments list', 'bookly' ) . '">' . $img . __( 'Add Bookly appointments list', 'bookly' ) . '</a>';
            echo '<a href="#TB_inline?width=400&inlineId=bookly-tinymce-calendar&height=300" id="add-bookly-calendar" class="thickbox button bookly-media-button" title="' . esc_attr__( 'Add Bookly calendar', 'bookly' ) . '">' . $img . __( 'Add Bookly calendar', 'bookly' ) . '</a>';
        }
    }

    /**
     * @inheritDoc
     */
    public static function renderPopup()
    {
        // The per-type 'modern_form' popups (search/services/staff/checkout/
        // cancellation) moved to core Tools::renderPopup(), which loops
        // Lib\Entities\Form::getTypes() generically. What's left here is
        // genuinely Pro-only: appointments list, calendar.
        $casest = BooklyLib\Config::getCaSeSt();
        $custom_fields = BooklyLib\Proxy\CustomFields::getWhichHaveData() ?: array();
        self::renderTemplate( 'appointment_list', compact( 'custom_fields' ) );
        self::renderTemplate( 'calendar', compact( 'casest' ) );
    }
}