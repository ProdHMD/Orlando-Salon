<?php
namespace BooklyPro\Lib\Zoom;

abstract class Authentication
{
    const TYPE_DEFAULT = 'default';
    const TYPE_OAuth   = 'oauth';
}