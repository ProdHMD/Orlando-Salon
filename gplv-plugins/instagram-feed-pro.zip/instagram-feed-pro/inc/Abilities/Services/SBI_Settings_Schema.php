<?php

namespace InstagramFeed\Abilities\Services;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Typed allowlist of the settings exposed through the Abilities API.
 *
 * This is the single source of truth for what an AI agent may read or write.
 * Anything not listed here is never exposed — connected accounts, access
 * tokens, license data, custom CSS/JS and usage tracking are deliberately
 * absent. JSON Schemas for every ability are derived from these tables so the
 * pattern ports to the other feed plugins by swapping the tables only.
 *
 * Per-feed keys map 1:1 onto SBI_Feed_Saver::settings_defaults(); global keys
 * map onto the sb_instagram_settings option (see sbi_defaults()).
 *
 * @since INSTA_FEED_PRO_SINCE
 */
class SBI_Settings_Schema
{
	const MAX_STRING_LENGTH = 500;

	/** Hex colour: #rgb, #rgba, #rrggbb, #rrggbbaa — or empty (plugin default). */
	const COLOR_PATTERN = '^(#([0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8}))?$';

	/**
	 * Per-feed settings. `tier` names the license feature that must be
	 * available for the key to be writable (null = every Pro tier).
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public static function feed_settings()
	{
		return array(
			'feed_name' => array(
				'type' => 'string',
				'description' => 'Internal feed name shown in the Feed Builder list.',
			),
			'layout' => array(
				'type' => 'string',
				'enum' => array('grid', 'carousel', 'masonry', 'highlight'),
				'description' => 'Feed layout.',
			),
			'cols' => array(
				'type' => 'integer',
				'minimum' => 1,
				'maximum' => 10,
				'description' => 'Columns on desktop.',
			),
			'colstablet' => array(
				'type' => 'integer',
				'minimum' => 1,
				'maximum' => 10,
				'description' => 'Columns on tablet.',
			),
			'colsmobile' => array(
				'type' => 'integer',
				'minimum' => 1,
				'maximum' => 10,
				'description' => 'Columns on mobile.',
			),
			'num' => array(
				'type' => 'integer',
				'minimum' => 1,
				'maximum' => 200,
				'description' => 'Number of posts on desktop.',
			),
			'nummobile' => array(
				'type' => 'integer',
				'minimum' => 1,
				'maximum' => 200,
				'description' => 'Number of posts on mobile.',
			),
			'imagepadding' => array(
				'type' => 'integer',
				'minimum' => 0,
				'maximum' => 100,
				'description' => 'Padding around each image, in px.',
			),
			'imageaspectratio' => array(
				'type' => 'string',
				'enum' => array('1:1', '3:4', '4:5'),
				'description' => 'Image aspect ratio.',
			),
			'sortby' => array(
				'type' => 'string',
				'enum' => array('none', 'likes', 'random'),
				'description' => 'Post sort order (none = newest first).',
			),
			'disablelightbox' => array(
				'type' => 'boolean',
				'description' => 'Disable the lightbox popup.',
			),
			'showheader' => array(
				'type' => 'boolean',
				'description' => 'Show the feed header.',
			),
			'headerstyle' => array(
				'type' => 'string',
				'enum' => array('standard', 'boxed', 'centered', 'text'),
				'description' => 'Header style.',
			),
			'headersize' => array(
				'type' => 'string',
				'enum' => array('small', 'medium', 'large'),
				'description' => 'Header size.',
			),
			'showbio' => array(
				'type' => 'boolean',
				'description' => 'Show the account bio in the header.',
			),
			'showfollowers' => array(
				'type' => 'boolean',
				'description' => 'Show the follower count in the header.',
			),
			'showcaption' => array(
				'type' => 'boolean',
				'description' => 'Show post captions.',
			),
			'captionlength' => array(
				'type' => 'integer',
				'minimum' => 0,
				'maximum' => 2200,
				'description' => 'Max caption characters. 0 truncates immediately; an unset feed reads back '
					. 'as 50, the plugin\'s own template default (SBI_Feed_Template_Settings).',
			),
			'showlikes' => array(
				'type' => 'boolean',
				'description' => 'Show like and comment counts.',
			),
			'hovereffect' => array(
				'type' => 'string',
				'description' => 'Hover effect slug (empty for default).',
			),
			'hovercolor' => array(
				'type' => 'string',
				'format' => 'color',
				'description' => 'Hover overlay color as a hex value.',
			),
			'showbutton' => array(
				'type' => 'boolean',
				'description' => 'Show the Load More button.',
			),
			'buttontext' => array(
				'type' => 'string',
				'description' => 'Load More button label.',
			),
			'showfollow' => array(
				'type' => 'boolean',
				'description' => 'Show the Follow button.',
			),
			'followtext' => array(
				'type' => 'string',
				'description' => 'Follow button label.',
			),
			'colorpalette' => array(
				'type' => 'string',
				'enum' => array('inherit', 'light', 'dark', 'custom'),
				'writable' => false,
				'description' => 'Color palette. Read-only here: "custom" needs its six custom*color '
					. 'companions set in the same write or the palette renders blank. Use '
					. 'set-color-palette, which validates the whole set together.',
			),
			'carouselrows' => array(
				'type' => 'integer',
				'minimum' => 1,
				'maximum' => 2,
				'tier' => 'carousel',
				'description' => 'Carousel rows (carousel layout only).',
			),
			'carouselarrows' => array(
				'type' => 'boolean',
				'tier' => 'carousel',
				'description' => 'Show carousel navigation arrows.',
			),
			'carouselautoplay' => array(
				'type' => 'boolean',
				'tier' => 'carousel',
				'description' => 'Autoplay the carousel.',
			),
			// --- Added in SMASH-1997: colours, header extras, layout extras (read + write) ---
			'poststyle' => array(
				'type' => 'string',
				'enum' => array('regular', 'boxed'),
				'description' => 'Post style.',
			),
			'postbgcolor' => array(
				'type' => 'string',
				'format' => 'color',
				'description' => 'Boxed post background colour (hex).',
			),
			'postcorners' => array(
				'type' => 'integer',
				'minimum' => 0,
				'maximum' => 50,
				'description' => 'Boxed post corner radius (px).',
			),
			'boxshadow' => array(
				'type' => 'boolean',
				'description' => 'Boxed post shadow.',
			),
			'imageres' => array(
				'type' => 'string',
				'enum' => array('auto', 'thumb', 'medium', 'full'),
				'description' => 'Image resolution.',
			),
			'autoscroll' => array(
				'type' => 'boolean',
				'description' => 'Load more posts on scroll.',
			),
			'captioncolor' => array(
				'type' => 'string',
				'format' => 'color',
				'description' => 'Caption text colour (hex).',
			),
			'captionsize' => array(
				'type' => 'integer',
				'minimum' => 0,
				'maximum' => 60,
				'description' => 'Caption font size in px. 0 means "inherit" (no font-size override is '
					. 'rendered); an unset feed reads back as 12, the plugin\'s own template default '
					. '(SBI_Feed_Template_Settings).',
			),
			'likescolor' => array(
				'type' => 'string',
				'format' => 'color',
				'description' => 'Likes/comments icon colour (hex).',
			),
			'likessize' => array(
				'type' => 'integer',
				'minimum' => 0,
				'maximum' => 40,
				'description' => 'Likes/comments font size (px).',
			),
			'buttoncolor' => array(
				'type' => 'string',
				'format' => 'color',
				'description' => 'Load More button background (hex).',
			),
			'buttonhovercolor' => array(
				'type' => 'string',
				'format' => 'color',
				'description' => 'Load More button hover background (hex).',
			),
			'buttontextcolor' => array(
				'type' => 'string',
				'format' => 'color',
				'description' => 'Load More button text colour (hex).',
			),
			'followcolor' => array(
				'type' => 'string',
				'format' => 'color',
				'description' => 'Follow button background (hex).',
			),
			'followhovercolor' => array(
				'type' => 'string',
				'format' => 'color',
				'description' => 'Follow button hover background (hex).',
			),
			'followtextcolor' => array(
				'type' => 'string',
				'format' => 'color',
				'description' => 'Follow button text colour (hex).',
			),
			'headercolor' => array(
				'type' => 'string',
				'format' => 'color',
				'description' => 'Header text colour (hex).',
			),
			'headerprimarycolor' => array(
				'type' => 'string',
				'format' => 'color',
				'description' => 'Header primary colour (hex).',
			),
			'headersecondarycolor' => array(
				'type' => 'string',
				'format' => 'color',
				'description' => 'Header secondary colour (hex).',
			),
			'headertext' => array(
				'type' => 'string',
				'description' => 'Text-style header content.',
			),
			'headertextsize' => array(
				'type' => 'string',
				'enum' => array('small', 'medium', 'large'),
				'description' => 'Text-style header size.',
			),
			'headeroutside' => array(
				'type' => 'boolean',
				'description' => 'Place the header outside the feed container.',
			),
			'custombio' => array(
				'type' => 'string',
				'description' => 'Custom bio text shown in the header.',
			),
			'stories' => array(
				'type' => 'boolean',
				'description' => 'Show Instagram Stories in the header (Business accounts).',
			),
			'storiestime' => array(
				'type' => 'integer',
				'minimum' => 500,
				'maximum' => 60000,
				'description' => 'Story slide duration (ms).',
			),
			'carouselloop' => array(
				'type' => 'string',
				'enum' => array('rewind', 'infinity'),
				'tier' => 'carousel',
				'description' => 'Carousel loop behaviour.',
			),
			'carouselpag' => array(
				'type' => 'boolean',
				'tier' => 'carousel',
				'description' => 'Show carousel pagination dots.',
			),
			'carouseltime' => array(
				'type' => 'integer',
				'minimum' => 500,
				'maximum' => 60000,
				'tier' => 'carousel',
				'description' => 'Carousel autoplay interval (ms).',
			),
			// --- Highlight companions (layout "highlight"). Read-only here — AgDR-0504
			// requirement 2: coupled keys are set together through one validating
			// ability (set-highlight-source), never through the generic setter, so an
			// agent can't reach a highlight state it can't complete (finding A3). ---
			'highlighttype' => array(
				'type' => 'string',
				'enum' => array('pattern', 'id', 'hashtag'),
				'writable' => false,
				'description' => 'Highlight source type (layout "highlight" only). Read-only: set with '
					. 'set-highlight-source, which validates the matching companion value too.',
			),
			'highlightpattern' => array(
				'type' => 'integer',
				'minimum' => 1,
				'writable' => false,
				'description' => 'Highlight every Nth post (highlighttype "pattern"). The plugin\'s own '
					. 'control has no upper bound. Read-only: set with set-highlight-source.',
			),
			'highlightoffset' => array(
				'type' => 'integer',
				'minimum' => 0,
				'writable' => false,
				'description' => 'Pattern starting offset (highlighttype "pattern"). The plugin\'s own '
					. 'control has no upper bound. Read-only: set with '
					. 'set-highlight-source.',
			),
			'highlightids' => array(
				'type' => 'string',
				'writable' => false,
				'description' => 'Comma-separated post IDs to highlight (highlighttype "id"). Read-only: '
					. 'set with set-highlight-source.',
			),
			'highlighthashtag' => array(
				'type' => 'string',
				'writable' => false,
				'description' => 'Comma-separated hashtags to highlight (highlighttype "hashtag"). Read-only: '
					. 'set with set-highlight-source.',
			),
			// --- Custom color palette companions (colorpalette "custom"). Read-only
			// here for the same AgDR-0504 requirement-2 reason (finding A4): set
			// together with colorpalette through set-color-palette. ---
			'custombgcolor1' => array(
				'type' => 'string',
				'format' => 'color',
				'writable' => false,
				'description' => 'Custom palette background colour (colorpalette "custom"). Read-only: set '
					. 'with set-color-palette.',
			),
			'customtextcolor1' => array(
				'type' => 'string',
				'format' => 'color',
				'writable' => false,
				'description' => 'Custom palette caption/lightbox text colour (colorpalette "custom"). '
					. 'Read-only: set with set-color-palette.',
			),
			'customtextcolor2' => array(
				'type' => 'string',
				'format' => 'color',
				'writable' => false,
				'description' => 'Custom palette secondary text colour, e.g. bio/meta (colorpalette '
					. '"custom"). Read-only: set with set-color-palette.',
			),
			'customlinkcolor1' => array(
				'type' => 'string',
				'format' => 'color',
				'writable' => false,
				'description' => 'Custom palette link colour (colorpalette "custom"). Read-only: set with '
					. 'set-color-palette.',
			),
			'custombuttoncolor1' => array(
				'type' => 'string',
				'format' => 'color',
				'writable' => false,
				'description' => 'Custom palette Load More button background (colorpalette "custom"). '
					. 'Read-only: set with set-color-palette.',
			),
			'custombuttoncolor2' => array(
				'type' => 'string',
				'format' => 'color',
				'writable' => false,
				'description' => 'Custom palette Follow button background (colorpalette "custom"). '
					. 'Read-only: set with set-color-palette.',
			),
		);
	}

	/**
	 * Global (plugin-wide) settings stored in the sb_instagram_settings option.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public static function global_settings()
	{
		return array(
			'sbi_caching_type' => array(
				'type' => 'string',
				'enum' => array('background', 'page'),
				'description' => 'How feeds are refreshed. Legacy constant: the Settings UI always uses "background"; '
					. 'read-only.',
				'writable' => false,
			),
			'sbi_cache_cron_interval' => array(
				'type' => 'string',
				'enum' => array('30mins', '1hour', '12hours', '24hours'),
				'description' => 'Background cache refresh interval.',
			),
			'sbi_cache_cron_time' => array(
				'type' => 'string',
				'enum' => array('1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'),
				'description' => 'Hour for the daily (24hours) refresh.',
			),
			'sbi_cache_cron_am_pm' => array(
				'type' => 'string',
				'enum' => array('am', 'pm'),
				'description' => 'AM/PM for the daily refresh hour.',
			),
			'gdpr' => array(
				'type' => 'string',
				'enum' => array('auto', 'yes', 'no'),
				'description' => 'GDPR mode. Read-only for AI assistants: it has legal consequences, '
					. 'change it in Settings → Feeds.',
				'writable' => false,
			),
			'sb_instagram_disable_resize' => array(
				'type' => 'boolean',
				'description' => 'Disable local image resizing/storage.',
			),
			'image_format' => array(
				'type' => 'string',
				'enum' => array('webp', 'jpg'),
				'description' => 'Format for locally resized images.',
			),
			'sb_instagram_ajax_theme' => array(
				'type' => 'boolean',
				'description' => 'Load feeds via AJAX (for themes that break the initial load).',
			),
			'sb_ajax_initial' => array(
				'type' => 'boolean',
				'description' => 'Load the initial posts via AJAX.',
			),
			'enqueue_css_in_shortcode' => array(
				'type' => 'boolean',
				'description' => 'Enqueue CSS only where the shortcode is used.',
			),
			'enqueue_js_in_head' => array(
				'type' => 'boolean',
				'description' => 'Enqueue JS in the head instead of the footer.',
			),
			'disable_js_image_loading' => array(
				'type' => 'boolean',
				'description' => 'Disable JavaScript image loading.',
			),
			'disable_admin_notice' => array(
				'type' => 'boolean',
				'description' => 'Hide feed-issue admin notices. Read-only for AI assistants '
					. '(an agent must not silence error notices).',
				'writable' => false,
			),
		);
	}

	/**
	 * Build a JSON Schema `properties` map from a table (drops private keys).
	 *
	 * @param array $table
	 * @return array
	 */
	public static function to_json_properties(array $table)
	{
		$out = array();
		foreach ($table as $key => $def) {
			$prop = array('type' => $def['type']);
			foreach (array('enum', 'minimum', 'maximum', 'description') as $k) {
				if (isset($def[$k])) {
					$prop[$k] = $def[$k];
				}
			}
			if ($def['type'] === 'string' && !isset($def['enum'])) {
				$prop['maxLength'] = self::MAX_STRING_LENGTH;
			}
			if (isset($def['format']) && $def['format'] === 'color') {
				$prop['pattern']     = self::COLOR_PATTERN;
				$prop['description'] = (isset($prop['description']) ? $prop['description'] . ' ' : '')
					. 'Hex colour (#rgb, #rrggbb or #rrggbbaa) or empty for the default.';
			}
			if (isset($def['writable']) && $def['writable'] === false) {
				$prop['readOnly'] = true;
			}
			if (isset($def['tier'])) {
				$prop['x-license-feature'] = $def['tier'];
			}
			$out[$key] = $prop;
		}
		return $out;
	}

	/**
	 * Cast a raw stored value to the declared type for output.
	 *
	 * Stored data is not guaranteed to satisfy the schema (legacy installs,
	 * import/export, a bad save). Core validates our OUTPUT against the schema
	 * and fails the whole ability on one bad value, so anything that does not
	 * satisfy the declared enum / range falls back to $default (the plugin's
	 * own default for that key) rather than being passed through.
	 *
	 * @param array $def     Schema entry for the key.
	 * @param mixed $value   Raw stored value (null when missing).
	 * @param mixed $default Plugin default for the key.
	 * @return mixed
	 */
	public static function cast_out(array $def, $value, $default = null)
	{
		switch ($def['type']) {
			case 'boolean':
				// '' is a legitimate "off" in this plugin (legacy read path writes it for
				// showheader/showbutton/...), so only a MISSING value takes the default.
				if ($value === null) {
					$value = $default;
				}
				return $value === true || $value === 'true' || $value === 1 || $value === '1' || $value === 'on';

			case 'integer':
				if ($value === null || $value === '' || !is_numeric($value)) {
					$value = is_numeric($default) ? $default : 0;
				}
				$int = (int) $value;
				// Clamp so the output always satisfies the declared range even if the
				// plugin default itself is ever out of spec.
				if (isset($def['minimum']) && $int < $def['minimum']) {
					$int = (int) $def['minimum'];
				}
				if (isset($def['maximum']) && $int > $def['maximum']) {
					$int = (int) $def['maximum'];
				}
				return $int;

			default:
				$str = is_scalar($value) ? (string) $value : '';

				// Clamp to the declared hex-colour pattern BEFORE the enum/length
				// checks below: a stored value can predate this schema and not be hex
				// at all. '' always satisfies COLOR_PATTERN (it is optional-empty), so
				// it is always a safe last resort even when $default itself does not
				// match.
				$is_color = isset($def['format']) && $def['format'] === 'color';
				if ($is_color && !preg_match('/' . self::COLOR_PATTERN . '/', $str)) {
					$fallback_str = is_scalar($default) ? (string) $default : '';
					$str          = preg_match('/' . self::COLOR_PATTERN . '/', $fallback_str) ? $fallback_str : '';
				}

				if (isset($def['enum']) && !in_array($str, $def['enum'], true)) {
					$fallback = is_scalar($default) ? (string) $default : '';
					$str      = in_array($fallback, $def['enum'], true) ? $fallback : (string) $def['enum'][0];
				}

				// Same reasoning again for length: to_json_properties() only declares
				// maxLength on plain strings (never on an enum, which is always
				// short), so truncate rather than fail the whole ability on an
				// over-length stored value.
				if (!isset($def['enum']) && mb_strlen($str) > self::MAX_STRING_LENGTH) {
					$str = mb_substr($str, 0, self::MAX_STRING_LENGTH);
				}

				return $str;
		}
	}

	/**
	 * Writable subset of a table (keys not flagged `writable => false`).
	 *
	 * @param array $table
	 * @return array
	 */
	public static function writable(array $table)
	{
		return array_filter(
			$table,
			function ($def) {
				return !isset($def['writable']) || $def['writable'] !== false;
			}
		);
	}

	/**
	 * Validate + normalise ONE incoming value for storage.
	 *
	 * Core has already validated the request against the JSON Schema, so this is
	 * the second, PHP-side line: it never trusts the transport. Returns the
	 * value to store, or a WP_Error (code sbi_invalid_value, status 400).
	 *
	 * @param array  $def
	 * @param mixed  $value
	 * @param string $key
	 * @return mixed|\WP_Error
	 */
	public static function validate_in(array $def, $value, $key)
	{
		$bad = function ($reason) use ($key) {
			return new \WP_Error(
				'sbi_invalid_value',
				sprintf(
					/* translators: 1: setting key, 2: reason */
					__('Invalid value for %1$s: %2$s', 'instagram-feed'),
					$key,
					$reason
				),
				array('status' => 400)
			);
		};

		switch ($def['type']) {
			case 'boolean':
				if (is_bool($value)) {
					return $value;
				}
				if (in_array($value, array('true', '1', 1, 'on'), true)) {
					return true;
				}
				if (in_array($value, array('false', '0', 0, 'off', ''), true)) {
					return false;
				}
				return $bad(__('expected a boolean', 'instagram-feed'));

			case 'integer':
				if (!is_numeric($value) || (float) $value !== (float) (int) $value) {
					return $bad(__('expected an integer', 'instagram-feed'));
				}
				$int = (int) $value;
				if (isset($def['minimum']) && $int < $def['minimum']) {
					return $bad(sprintf(__('minimum is %d', 'instagram-feed'), $def['minimum']));
				}
				if (isset($def['maximum']) && $int > $def['maximum']) {
					return $bad(sprintf(__('maximum is %d', 'instagram-feed'), $def['maximum']));
				}
				return $int;

			default:
				if (!is_scalar($value)) {
					return $bad(__('expected a string', 'instagram-feed'));
				}
				$str = sanitize_text_field((string) $value);
				if (isset($def['enum']) && !in_array($str, $def['enum'], true)) {
					return $bad(sprintf(__('allowed values: %s', 'instagram-feed'), implode(', ', $def['enum'])));
				}
				$is_color = isset($def['format']) && $def['format'] === 'color';
				if ($is_color && !preg_match('/' . self::COLOR_PATTERN . '/', $str)) {
					return $bad(__('expected a hex colour such as #408bd1', 'instagram-feed'));
				}
				if (mb_strlen($str) > self::MAX_STRING_LENGTH) {
					return $bad(
						sprintf(__('maximum length is %d characters', 'instagram-feed'), self::MAX_STRING_LENGTH)
					);
				}
				return $str;
		}
	}
}
