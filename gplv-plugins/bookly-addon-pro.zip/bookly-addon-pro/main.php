<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly
/*
Plugin Name: Bookly Pro (Add-on)
Plugin URI: https://www.booking-wp-plugin.com/?utm_source=bookly_admin&utm_medium=plugins_page&utm_campaign=plugins_page
Description: Bookly Pro add-on allows you to use additional features and settings, and install other add-ons for Bookly plugin.
Version: 9.6
Author: Nota-Info
Author URI: https://www.booking-wp-plugin.com/?utm_source=bookly_admin&utm_medium=plugins_page&utm_campaign=plugins_page
Text Domain: bookly
Domain Path: /languages
License: Commercial
Update URI: https://hub.bookly.pro
*/

update_option( 'bookly_pro_purchase_code', '1415B451-BE1A-13C2-83BA-771EA52D38BB' );
update_option( 'bookly_pro_grace_start', PHP_INT_MAX );
update_option( 'bookly_pro_licensed_products', array() );
update_option( 'bookly_api_server_error_time', '0' );

add_filter( 'pre_http_request', function( $pre, $args, $url ) {
    if ( strpos( $url, '/plugins/bookly-addon-pro/' ) !== false ) {
        if ( strpos( $url, 'purchase-code' ) !== false || strpos( $url, '/update' ) !== false ) {
            return array(
                'response' => array( 'code' => 200 ),
                'body' => json_encode( array(
                    'success' => true,
                    'licensed' => true,
                    'data' => array( 'bookly_pro_licensed_products' => array() )
                ) )
            );
        }
    }
    return $pre;
}, 10, 3 );

if ( ! function_exists( 'bookly_pro_loader' ) ) {
    include_once __DIR__ . '/autoload.php';

    BooklyPro\Lib\Boot::up();
}