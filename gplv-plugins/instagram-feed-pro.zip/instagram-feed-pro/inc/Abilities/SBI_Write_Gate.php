<?php

namespace InstagramFeed\Abilities;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Site-level switch for write abilities (off by default).
 *
 * Mirrors the WPForms pattern: a settings toggle stored in the plugin's option,
 * overridable in both directions by a filter. Read abilities never consult it.
 *
 * @since INSTA_FEED_PRO_SINCE
 */
class SBI_Write_Gate
{
	const OPTION_KEY = 'sb_instagram_ai_write_enabled';
	const FILTER     = 'sbi_abilities_allow_write';

	/**
	 * @return bool
	 */
	public static function is_enabled()
	{
		$settings = get_option('sb_instagram_settings', array());
		$default  = is_array($settings) && !empty($settings[self::OPTION_KEY]);

		return (bool) apply_filters(self::FILTER, $default);
	}

	/**
	 * @return true|\WP_Error
	 */
	public static function check()
	{
		return self::is_enabled() ? true : SBI_Ability_Response::writes_disabled();
	}
}
