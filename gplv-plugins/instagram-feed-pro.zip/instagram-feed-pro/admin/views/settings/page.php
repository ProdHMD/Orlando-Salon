<div id="sbi-settings" class="sbi-settings" :data-app-loaded="appLoaded ? 'true' : 'false'">
	<?php
	InstagramFeed\SBI_View::render('sections.header');
	InstagramFeed\SBI_View::render('settings.content');
	?>
	<div class="sb-control-elem-tltp-content" v-show="tooltip.hover" @mouseover.prevent.default="hoverTooltip(true)"
		 @mouseleave.prevent.default="hoverTooltip(false)">
		<div class="sb-control-elem-tltp-txt" v-html="tooltip.text"></div>
	</div>

	<?php
	include_once SBI_BUILDER_DIR . 'templates/sections/popup/license-learn-more.php';
	include_once SBI_BUILDER_DIR . 'templates/sections/popup/why-renew-license-popup.php';
	?>
</div>
